@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY_OWNER_ACCOUNT.ps1"
if errorlevel 1 (
  echo.
  echo Owner account patch failed.
  exit /b 1
)
echo.
echo Owner account patch applied.
