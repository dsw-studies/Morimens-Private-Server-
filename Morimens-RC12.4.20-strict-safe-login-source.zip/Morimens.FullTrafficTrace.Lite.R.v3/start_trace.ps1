$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here

Write-Host "Morimens FullTrafficTrace Lite v3" -ForegroundColor Cyan
Write-Host "Отключи приватный режим, hosts-редирект и Morimens.Server." -ForegroundColor Yellow
Write-Host "Запись стартует выключенной. В игре R = включить/выключить запись." -ForegroundColor Green
Write-Host "Включи R только перед кликами по валютам и выключи после истории." -ForegroundColor Green
Write-Host ""

if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
    throw "Не найден Python launcher 'py'. Установи Python 3 и включи Add Python to PATH."
}

py -c "import frida" 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "Устанавливаю Frida..." -ForegroundColor Yellow
    py -m pip install --upgrade frida frida-tools
}

py "$here\watcher.py"
