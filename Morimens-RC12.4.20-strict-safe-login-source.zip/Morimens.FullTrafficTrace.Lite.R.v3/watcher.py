import frida
import json
import threading
import time
from datetime import datetime
from pathlib import Path

DEVICE = frida.get_local_device()
BASE = Path(__file__).resolve().parent / "Results"
RUN = BASE / datetime.now().strftime("%Y%m%d-%H%M%S")
RUN.mkdir(parents=True, exist_ok=True)
HOOK = Path(__file__).with_name("hook.js").read_text(encoding="utf-8")

sessions = {}
scripts = {}
lock = threading.Lock()
stop_event = threading.Event()
MAX_TOTAL_BYTES = 768 * 1024 * 1024


def log(text: str) -> None:
    print(text, flush=True)
    with (RUN / "console.log").open("a", encoding="utf-8") as f:
        f.write(text + "\n")


def attach_pid(pid: int) -> None:
    proc_dir = RUN / f"pid-{pid}"
    proc_dir.mkdir(parents=True, exist_ok=True)
    event_file = proc_dir / "events.jsonl"
    blob_file = proc_dir / "blobs.bin"
    counter = {"n": 0, "bytes": 0}

    def on_message(message, data):
        if message.get("type") == "error":
            log(f"[PID {pid}] [JS ERROR] {message.get('stack') or message}")
            return
        payload = message.get("payload", {})
        if payload.get("type") == "log":
            log(f"[PID {pid}] {payload.get('text', '')}")
            return

        counter["n"] += 1
        payload["event_number"] = counter["n"]
        payload["pid"] = pid
        payload["host_ts"] = time.time()

        if data is not None:
            raw = bytes(data)
            payload["captured_size"] = len(raw)
            if counter["bytes"] + len(raw) <= MAX_TOTAL_BYTES:
                with blob_file.open("ab") as f:
                    offset = f.tell()
                    f.write(raw)
                payload["blob_file"] = "blobs.bin"
                payload["blob_offset"] = offset
                payload["blob_length"] = len(raw)
                counter["bytes"] += len(raw)
            else:
                payload["blob_skipped"] = "total_run_limit"

        with event_file.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False) + "\n")

        if counter["n"] % 100 == 0:
            log(f"[PID {pid}] captured={counter['n']} blobs, size={counter['bytes'] // 1024} KiB")

    for attempt in range(1, 16):
        try:
            session = DEVICE.attach(pid)
            script = session.create_script(HOOK)
            script.on("message", on_message)
            script.load()
            with lock:
                sessions[pid] = session
                scripts[pid] = script
            log(f"[PID {pid}] [+] attached. Запись выключена; R включает/выключает.")
            return
        except Exception as exc:
            if attempt == 15:
                log(f"[PID {pid}] [!] attach failed: {exc}")
                return
            time.sleep(0.35)


def watch() -> None:
    seen = set()
    while not stop_event.is_set():
        try:
            for proc in DEVICE.enumerate_processes():
                if proc.name.lower() == "morimens.exe" and proc.pid not in seen:
                    seen.add(proc.pid)
                    log(f"[+] PID={proc.pid}, name={proc.name}")
                    threading.Thread(target=attach_pid, args=(proc.pid,), daemon=True).start()
        except Exception as exc:
            log(f"[!] watcher error: {exc}")
        time.sleep(0.35)


log("Morimens FullTrafficTrace Lite v3")
log(f"Frida: {frida.__version__}")
log(f"Result: {RUN}")
log("Запись начинается ВЫКЛЮЧЕННОЙ. В игре нажми R перед кликами и R после истории.")
threading.Thread(target=watch, daemon=True).start()

try:
    input("Запусти официальную игру. После завершения закрой игру и нажми Enter здесь.\n")
finally:
    stop_event.set()
    with lock:
        for session in list(sessions.values()):
            try:
                session.detach()
            except Exception:
                pass
    log(f"Done: {RUN}")
