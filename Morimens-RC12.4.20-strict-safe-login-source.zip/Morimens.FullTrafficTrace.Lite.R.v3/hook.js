'use strict';

const MIN_BLOB = 128;
const MAX_BLOB = 2 * 1024 * 1024;
const installed = new Set();
let captureEnabled = false;
let lastRDown = false;
let capturedCount = 0;

function log(text) { send({ type: 'log', text }); }

function readable(p, n) {
  if (!p || p.isNull() || n < MIN_BLOB || n > MAX_BLOB) return false;
  try {
    const r = Process.findRangeByAddress(p);
    return !!r && r.protection.indexOf('r') !== -1;
  } catch (_) { return false; }
}

function classify(p, n) {
  try {
    const sample = new Uint8Array(p.readByteArray(Math.min(n, 256)));
    let printable = 0;
    for (const b of sample) {
      if ((b >= 32 && b <= 126) || b === 9 || b === 10 || b === 13) printable++;
    }
    const ratio = sample.length ? printable / sample.length : 0;
    return ratio > 0.90 ? 'text' : (ratio > 0.55 ? 'mixed' : 'binary');
  } catch (_) { return 'unknown'; }
}

function emitBlob(type, api, p, n, extra) {
  if (!captureEnabled || !readable(p, n)) return;
  try {
    capturedCount++;
    send(Object.assign({
      type,
      api,
      size: n,
      stage: classify(p, n),
      tid: Process.getCurrentThreadId(),
      target_ts_ms: Date.now(),
      sequence: capturedCount
    }, extra || {}), p.readByteArray(n));
  } catch (_) {}
}

function hookOnce(key, address, callbacks) {
  if (!address || installed.has(key)) return;
  try {
    Interceptor.attach(address, callbacks);
    installed.add(key);
    log('[+] hook ' + key + ' @ ' + address);
  } catch (e) {
    log('[!] hook failed ' + key + ': ' + e);
  }
}

function hookLua(m) {
  const baseKey = m.name + '@' + m.base;

  const push = m.findExportByName('lua_pushlstring');
  hookOnce(baseKey + ':lua_pushlstring', push, {
    onEnter(args) {
      let n = 0;
      try { n = Number(args[2].toUInt64()); } catch (_) {
        try { n = Number(args[2].toUInt32()); } catch (_) {}
      }
      emitBlob('lua_blob', 'lua_pushlstring', args[1], n, { module: m.name });
    }
  });

  const tol = m.findExportByName('lua_tolstring');
  hookOnce(baseKey + ':lua_tolstring', tol, {
    onEnter(args) { this.lenp = args[1]; },
    onLeave(retval) {
      if (retval.isNull()) return;
      let n = 0;
      try { if (this.lenp && !this.lenp.isNull()) n = Number(this.lenp.readU64()); } catch (_) {
        try { n = Number(this.lenp.readU32()); } catch (_) {}
      }
      emitBlob('lua_blob', 'lua_tolstring', retval, n, { module: m.name });
    }
  });

  const loadbuf = m.findExportByName('luaL_loadbufferx') || m.findExportByName('luaL_loadbuffer');
  hookOnce(baseKey + ':luaL_loadbuffer', loadbuf, {
    onEnter(args) {
      let n = 0;
      try { n = Number(args[2].toUInt64()); } catch (_) {
        try { n = Number(args[2].toUInt32()); } catch (_) {}
      }
      emitBlob('lua_blob', 'luaL_loadbuffer', args[1], n, { module: m.name });
    }
  });
}

function hookCompression(m) {
  const baseKey = m.name + '@' + m.base;
  for (const name of ['LZ4_decompress_safe', 'LZ4_decompress_safe_partial', 'LZ4_decompress_fast']) {
    let p = null;
    try { p = m.findExportByName(name); } catch (_) {}
    hookOnce(baseKey + ':' + name, p, {
      onEnter(args) { this.dst = args[1]; },
      onLeave(retval) {
        const n = retval.toInt32();
        if (n > 0) emitBlob('decompressed_blob', name, this.dst, n, { module: m.name });
      }
    });
  }
}

function scanModules() {
  for (const m of Process.enumerateModules()) {
    const lower = m.name.toLowerCase();
    if (lower.indexOf('xlua') !== -1 || lower.indexOf('lua') !== -1) hookLua(m);
    if (lower.indexOf('lz4') !== -1 || lower.indexOf('gameassembly') !== -1 || lower === 'gs.dll') hookCompression(m);
  }
}

function installRToggle() {
  try {
    const p = Module.findGlobalExportByName('GetAsyncKeyState');
    if (!p) { log('[!] GetAsyncKeyState not found; use console commands r/s.'); return; }
    const getKey = new NativeFunction(p, 'int16', ['int']);
    setInterval(function () {
      const down = (getKey(0x52) & 0x8000) !== 0; // VK_R
      if (down && !lastRDown) {
        captureEnabled = !captureEnabled;
        log(captureEnabled ? '[REC] ON — запись включена' : '[REC] OFF — запись выключена');
      }
      lastRDown = down;
    }, 80);
    log('[+] R toggle installed. Recording starts OFF.');
  } catch (e) { log('[!] R toggle failed: ' + e); }
}

rpc.exports = {
  startcapture() { captureEnabled = true; log('[REC] ON — запись включена'); return true; },
  stopcapture() { captureEnabled = false; log('[REC] OFF — запись выключена'); return true; },
  status() { return { enabled: captureEnabled, capturedCount }; }
};

scanModules();
setInterval(scanModules, 1000);
installRToggle();
log('[+] Morimens FullTrafficTrace Lite v3 installed. Нажми R перед нужными действиями.');
