Morimens Gacha + Currency Patch v1

Что меняет:
- Gold: 99 999 при регистрации и каждом входе.
- Premium/gacha currency: 99 999 при регистрации и каждом входе.
- Новый backend-баннер: tomorrow-limited.
- Одиночная и десятикратная крутка в этом баннере всегда выдают героя 1007.
- Стоимость реально списывается из PremiumCurrency: 160 / 1600.
- Результат сохраняется в существующей таблице GachaPulls и виден в истории admin API.
- Исправлены byte-cast выражения в CapturedInitialGameStreamBuilder.

Установка:
1) Распаковать архив в корень Morimens-ReServer.
2) PowerShell:
   Set-ExecutionPolicy -Scope Process Bypass -Force
   .\morimens_gacha_currency_patch_v1\apply-patch.ps1 -ProjectRoot D:\Morimens-ReServer
3) Запустить .\build-portable.cmd

Важно:
Этот патч завершает backend-логику. Отображение официального баннера внутри игрового клиента зависит от точных protocol RPC/ID клиента и может потребовать отдельного protocol fixture-патча.
