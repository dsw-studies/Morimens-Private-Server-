# Morimens-ReServer

> Work in progress.

## Overview

Morimens-ReServer is a personal research project focused on building a compatible server implementation for the Morimens game client.

The goal is to understand the client-server communication and recreate the required server behavior for educational purposes and experimentation.

## Project Status

🚧 Early research stage

## Goals

- [ ] Analyze client networking
- [ ] Identify API endpoints
- [ ] Implement authentication
- [ ] Load player profile
- [ ] Support inventory
- [ ] Support character data
- [ ] Implement gacha mechanics
- [ ] Support story progression

## Project Structure

```text
docs/        Documentation
research/    Research notes
server/      Server implementation
tools/       Utilities

Tech Stack
Python (FastAPI)
SQLite (temporary)
Git
Unity IL2CPP research
Disclaimer

This repository contains only original code and documentation created during the project. No game assets or proprietary files are included.

## Solution and launcher

Open `Morimens.sln` in Visual Studio 2022 or run:

```powershell
dotnet build Morimens.sln
dotnet run --project Morimens.Server --urls http://localhost:5000
dotnet run --project Morimens.Launcher
```

To create a standalone launcher executable, run `build-launcher.cmd`.
