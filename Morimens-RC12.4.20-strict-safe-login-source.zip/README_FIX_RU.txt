Исправление двух ошибок CS0221 и запуск owner-account скрипта при запрещенной ExecutionPolicy.

1. Скопируйте содержимое этой папки в D:\Morimens-ReServer с заменой.
2. Запустите из PowerShell:

   cd D:\Morimens-ReServer
   .\APPLY_OWNER_ACCOUNT.cmd

3. Затем очистите и пересоберите:

   Get-Process Morimens.Server -ErrorAction SilentlyContinue | Stop-Process -Force
   Get-Process Morimens.Launcher -ErrorAction SilentlyContinue | Stop-Process -Force
   Remove-Item .\Morimens.Server\bin -Recurse -Force -ErrorAction SilentlyContinue
   Remove-Item .\Morimens.Server\obj -Recurse -Force -ErrorAction SilentlyContinue
   Remove-Item .\publish -Recurse -Force -ErrorAction SilentlyContinue
   .\build-portable.cmd

Не запускайте старый APPLY_OWNER_ACCOUNT.ps1 напрямую: используйте CMD-файл.
