namespace Morimens.Common.Models;

public sealed record ServerHealth(bool Ok, string? Service, DateTimeOffset Utc);
