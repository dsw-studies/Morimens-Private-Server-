# Login session audit

Scanned root: `/mnt/data/111/Morimens-ReServer/Morimens.Server/Dumps`

- traffic sessions found: 41
- non-empty sessions with valid open handshake: 41
- output table: `login_sessions.csv`

## Confirmed format

Each direction starts with one plaintext frame using a 2-byte big-endian length.
The client handshake contains protocol version, 8-byte DH public key (Base64), server name, flags and `>lz4`.
The server handshake contains challenge, 8-byte DH public key (Base64) and `>lz4`.

## Critical cryptographic result

The old proxy captures both DH **public** keys, but it does not store either endpoint's DH **private** key or the derived shared secret/hashkey.
Therefore historical encrypted payloads cannot be deterministically decrypted from these files alone without solving a discrete-log problem in the 64-bit DH group.

The sessions remain highly useful for:

- exact timing and packet-boundary comparisons;
- identifying baseline versus profile/inventory actions;
- validating a decoder after a key is captured;
- replay-shape and required-response ordering;
- checking sizes and cadence of the post-login RPC sequence.

For plaintext LoginRequest/LoginResponse, the next capture must record the derived 8-byte hashkey (or plaintext immediately before DES encode / after DES decode) from the live client. This can be done with a small crypto-only hook and does not require Lua dumping.
