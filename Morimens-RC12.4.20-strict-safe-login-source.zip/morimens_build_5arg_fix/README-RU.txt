Исправляет CS1501 в DevelopmentRpcDispatcher.cs: Build принимает 4 аргумента, а вызов передавал 5.

Запуск из PowerShell:
  cd D:\Morimens-ReServer
  Set-ExecutionPolicy -Scope Process Bypass -Force
  .\morimens_build_5arg_fix\apply-fix.ps1 -ProjectRoot D:\Morimens-ReServer
  .\build-portable.cmd

Скрипт создаёт резервную копию исходного файла.
