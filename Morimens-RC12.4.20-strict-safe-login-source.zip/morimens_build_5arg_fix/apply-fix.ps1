param([string]$ProjectRoot = 'D:\Morimens-ReServer')
$ErrorActionPreference = 'Stop'
$file = Join-Path $ProjectRoot 'Morimens.Server\Protocol\Rpc\DevelopmentRpcDispatcher.cs'
if (!(Test-Path $file)) { throw "File not found: $file" }
$backup = "$file.bak-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
Copy-Item $file $backup -Force
$text = Get-Content $file -Raw
$patterns = @(
  '(?ms)(CapturedInitialGameStreamBuilder\.Build\(\s*selected\.Uid\s*,\s*selected\.Stamina\s*,\s*selected\.Gold\s*,)\s*selected\.PremiumCurrency\s*,\s*(gameLogin\.Sequence\s*\))',
  '(?ms)(CapturedInitialGameStreamBuilder\.Build\(\s*selected\.Uid\s*,\s*selected\.Stamina\s*,\s*selected\.Gold\s*,)\s*[^,\r\n]+\s*,\s*(gameLogin\.Sequence\s*\))'
)
$changed = $false
foreach ($p in $patterns) {
  $new = [regex]::Replace($text, $p, '$1`r`n                    $2', 1)
  if ($new -ne $text) { $text = $new; $changed = $true; break }
}
if (!$changed) {
  throw "Expected 5-argument Build call was not found. Open line 44 and remove the fourth argument before gameLogin.Sequence. Backup: $backup"
}
Set-Content -Path $file -Value $text -Encoding UTF8
Write-Host "Fixed: CapturedInitialGameStreamBuilder.Build now receives 4 arguments." -ForegroundColor Green
Write-Host "Backup: $backup" -ForegroundColor DarkGray
Write-Host "Run: .\build-portable.cmd" -ForegroundColor Cyan
