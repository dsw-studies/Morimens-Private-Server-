# Morimens Launcher Private Redirect v1.1.2

Это полный архив, а не отдельный patch.

Предыдущая ошибка `BG1002` означает, что в рабочей папке отсутствовали
`App.xaml` и `MainWindow.xaml`. Один только новый `.csproj` не мог это исправить.

## Установка

1. Распакуй архив в отдельную папку.
2. Открой PowerShell от имени администратора.
3. Перейди именно в распакованную папку, где видны:
   `App.xaml`, `MainWindow.xaml`, `install_clean.ps1`.
4. Выполни:

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\install_clean.ps1
```

Скрипт заменит старую папку лаунчера полной чистой копией и проверит наличие
обязательных файлов перед сборкой.

После успешной сборки:

```powershell
cd C:\MorimensPrivateServer\Morimens.Launcher
dotnet run
```


## Что изменено в v1.2-icon
- Добавлена иконка лаунчера в стиле Morimens.
- Иконка подключена и к окну WPF, и к EXE через `ApplicationIcon`.
- В папке `Assets` лежат `launcher_icon.ico` и исходный `launcher_icon.png`.
