# Morimens Launcher

Первый прототип лаунчера для Windows.

## Возможности

- проверяет `GET /health` у Morimens.Server;
- пытается найти установленную Steam-игру;
- позволяет вручную выбрать `.exe`;
- сохраняет настройки в `launcher.json`;
- запускает оригинальный игровой клиент.

## Запуск

```powershell
dotnet restore
dotnet run
```

## Сборка одного EXE

```powershell
dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
```

Результат будет в:

```text
bin\Release\net8.0-windows\win-x64\publish\
```

## Важно

Этот прототип пока только запускает оригинальный клиент. Перенаправление сетевых запросов на приватный сервер будет добавлено после определения реального протокола и адресов Morimens.
