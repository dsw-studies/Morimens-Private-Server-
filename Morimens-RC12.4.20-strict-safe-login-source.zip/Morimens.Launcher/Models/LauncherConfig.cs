
namespace Morimens.Launcher.Models;

public sealed class LauncherConfig
{
    public string ServerUrl { get; set; } = "http://localhost:5000";
    public string TcpHost { get; set; } = "127.0.0.1";
    public int TcpPort { get; set; } = 8443;
    public string GameExecutablePath { get; set; } = string.Empty;
    public string SteamAppId { get; set; } = string.Empty;
    public string ServerProjectPath { get; set; } = string.Empty;
    public string GameHostName { get; set; } =
        "z1g-p11222-game-mainport.qookkagames.com";
    public bool PrivateMode { get; set; } = true;
    public string LastUsername { get; set; } = string.Empty;
    public string LastDisplayName { get; set; } = string.Empty;
}
