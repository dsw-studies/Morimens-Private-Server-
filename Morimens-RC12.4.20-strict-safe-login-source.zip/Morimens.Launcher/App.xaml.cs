using System.Windows;

namespace Morimens.Launcher;

public partial class App : Application
{
}
