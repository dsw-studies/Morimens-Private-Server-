using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Media;
using Microsoft.Win32;
using Morimens.Launcher.Models;
using Morimens.Launcher.Services;

namespace Morimens.Launcher;

public partial class MainWindow : Window
{
    private readonly ConfigService _configService = new();
    private readonly SteamGameLocator _gameLocator = new();
    private readonly ServerStatusService _serverStatus = new();
    private readonly HostsRedirectService _redirect = new();
    private readonly LocalServerService _localServer = new();
    private readonly AuthApiService _auth = new();

    private LauncherConfig _config = new();
    private bool _busy;

    public MainWindow()
    {
        InitializeComponent();
        Loaded += async (_, _) => await InitializeAsync();
        Closing += (_, _) => _localServer.Stop();
    }

    private async Task InitializeAsync()
    {
        _config = await _configService.LoadAsync();
        _config.PrivateMode = true;

        ServerUrlTextBox.Text = _config.ServerUrl;
        TcpHostTextBox.Text = _config.TcpHost;
        TcpPortTextBox.Text = _config.TcpPort.ToString();
        GameHostTextBox.Text = _config.GameHostName;
        ServerProjectTextBox.Text = _config.ServerProjectPath;
        UsernameTextBox.Text = _config.LastUsername;
        DisplayNameTextBox.Text = _config.LastDisplayName;

        if (string.IsNullOrWhiteSpace(_config.GameExecutablePath)
            || !File.Exists(_config.GameExecutablePath))
        {
            var game = _gameLocator.FindGame();
            if (game is not null)
            {
                _config.GameExecutablePath = game.ExecutablePath;
                _config.SteamAppId = game.AppId;
            }
        }

        await SaveConfigAsync();
        await RefreshStateAsync();
        SetMessage("Готово. Введи данные аккаунта.", Brushes.LightSkyBlue);
    }

    private async Task SaveConfigAsync()
    {
        _config.ServerUrl = ServerUrlTextBox.Text.Trim();
        _config.TcpHost = TcpHostTextBox.Text.Trim();

        if (int.TryParse(TcpPortTextBox.Text.Trim(), out var port)
            && port is > 0 and <= 65535)
        {
            _config.TcpPort = port;
        }

        _config.GameHostName = GameHostTextBox.Text.Trim();
        _config.ServerProjectPath = ServerProjectTextBox.Text.Trim();
        _config.PrivateMode = true;
        await _configService.SaveAsync(_config);
    }

    private async Task RefreshStateAsync()
    {
        await SaveConfigAsync();

        GamePathText.Text = File.Exists(_config.GameExecutablePath)
            ? _config.GameExecutablePath
            : "Игра не найдена";

        var status = await _serverStatus.CheckAsync(
            _config.ServerUrl,
            _config.TcpHost,
            _config.TcpPort);

        ServerStatusText.Text = status.Message;
        ServerStatusText.Foreground = status.HttpOnline && status.TcpOnline
            ? Brushes.LightGreen
            : Brushes.Goldenrod;

        var redirectEnabled = _redirect.IsEnabled(
            _config.GameHostName,
            _config.TcpHost);

        RedirectStatusText.Text = redirectEnabled
            ? "Приватное подключение включено"
            : "Официальное подключение";
        RedirectStatusText.Foreground = redirectEnabled
            ? Brushes.LightGreen
            : Brushes.Goldenrod;
    }

    private async Task EnsureServerReadyAsync()
    {
        _localServer.Start(_config.ServerProjectPath);
        SetMessage("Запуск приватного сервера...", Brushes.Gold);

        for (var attempt = 0; attempt < 40; attempt++)
        {
            var status = await _serverStatus.CheckAsync(
                _config.ServerUrl,
                _config.TcpHost,
                _config.TcpPort);

            if (status.HttpOnline && status.TcpOnline)
            {
                ServerStatusText.Text = status.Message;
                ServerStatusText.Foreground = Brushes.LightGreen;
                SetMessage("Сервер запущен. Выполняю вход...", Brushes.LightGreen);
                return;
            }

            await Task.Delay(500);
        }

        throw new TimeoutException(
            $"Приватный сервер не запустился за 20 секунд. Лог: {_localServer.LogPath}");
    }

    private static void ValidateCredentials(
        string username,
        string password,
        string? displayName,
        bool registration)
    {
        if (username.Length is < 3 or > 32)
            throw new InvalidOperationException("Логин должен содержать от 3 до 32 символов.");
        if (password.Length < 6)
            throw new InvalidOperationException("Пароль должен содержать минимум 6 символов.");

        if (!registration)
            return;

        if (string.IsNullOrWhiteSpace(displayName))
            throw new InvalidOperationException("Введи игровой ник для регистрации.");
        if (displayName.Length is < 3 or > 14 || displayName.Any(ch => ch > 127))
            throw new InvalidOperationException("Игровой ник: от 3 до 14 символов, латиница и цифры.");
    }

    private async void Register_Click(object sender, RoutedEventArgs e)
    {
        await RunBusyAsync(async () =>
        {
            var username = UsernameTextBox.Text.Trim();
            var password = PasswordInput.Password;
            var displayName = DisplayNameTextBox.Text.Trim();
            ValidateCredentials(username, password, displayName, registration: true);

            await SaveConfigAsync();
            await EnsureServerReadyAsync();

            var result = await _auth.RegisterAsync(
                _config.ServerUrl,
                username,
                password,
                displayName);

            if (!result.Success)
                throw new InvalidOperationException(result.Message);

            _config.LastUsername = username;
            _config.LastDisplayName = result.DisplayName ?? displayName;
            await SaveConfigAsync();

            PasswordInput.Clear();
            SetMessage($"✓ Аккаунт создан. Игровой ник: {result.DisplayName ?? displayName}. Теперь введи пароль и нажми «ВОЙТИ И ИГРАТЬ».", Brushes.LightGreen);
            await RefreshStateAsync();
        });
    }

    private async void LoginAndPlay_Click(object sender, RoutedEventArgs e)
    {
        await RunBusyAsync(async () =>
        {
            var username = UsernameTextBox.Text.Trim();
            var password = PasswordInput.Password;
            var displayName = DisplayNameTextBox.Text.Trim();
            ValidateCredentials(username, password, displayName, registration: false);

            if (!File.Exists(_config.GameExecutablePath))
                throw new FileNotFoundException("Сначала выбери Morimens.exe.");

            await SaveConfigAsync();
            await EnsureServerReadyAsync();

            var result = await _auth.LoginAsync(
                _config.ServerUrl,
                username,
                password,
                string.IsNullOrWhiteSpace(displayName) ? string.Empty : displayName);
            if (!result.Success)
                throw new InvalidOperationException(result.Message);

            if (!_redirect.IsAdministrator())
                throw new InvalidOperationException("Перезапусти лаунчер от имени администратора.");

            _redirect.Enable(_config.GameHostName, _config.TcpHost);
            await RefreshStateAsync();
            SetMessage($"✓ Вход выполнен: {result.DisplayName ?? username}. Запускаю игру...", Brushes.LightGreen);
            var gameProcess = LaunchGame();
            WindowState = WindowState.Minimized;
            _ = CloseLauncherWhenGameExitsAsync(gameProcess);

            _config.LastUsername = username;
            _config.LastDisplayName = result.DisplayName ?? displayName;
            await SaveConfigAsync();

            PasswordInput.Clear();
            SetMessage($"✓ Игра запущена. Аккаунт: {result.DisplayName ?? username}.", Brushes.LightGreen);
        });
    }

    private Process? LaunchGame()
    {
        if (!string.IsNullOrWhiteSpace(_config.SteamAppId))
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = $"steam://run/{_config.SteamAppId}",
                UseShellExecute = true
            });
            return null;
        }

        return Process.Start(new ProcessStartInfo
        {
            FileName = _config.GameExecutablePath,
            WorkingDirectory = Path.GetDirectoryName(_config.GameExecutablePath)!,
            UseShellExecute = true
        });
    }

    private async Task CloseLauncherWhenGameExitsAsync(Process? launchedProcess)
    {
        try
        {
            var gameProcess = launchedProcess ?? await WaitForSteamGameProcessAsync();
            if (gameProcess is null)
                return;

            using (gameProcess)
            {
                await gameProcess.WaitForExitAsync();
            }

            await Dispatcher.InvokeAsync(Close);
        }
        catch
        {
            // The launcher must remain usable if Steam does not expose the game process.
        }
    }

    private async Task<Process?> WaitForSteamGameProcessAsync()
    {
        var processName = Path.GetFileNameWithoutExtension(_config.GameExecutablePath);
        if (string.IsNullOrWhiteSpace(processName))
            processName = "Morimens";

        for (var attempt = 0; attempt < 120; attempt++)
        {
            var process = Process.GetProcessesByName(processName)
                .FirstOrDefault(candidate => !candidate.HasExited);
            if (process is not null)
                return process;

            await Task.Delay(500);
        }

        return null;
    }

    private async Task RunBusyAsync(Func<Task> action)
    {
        if (_busy) return;
        _busy = true;
        IsEnabled = false;

        try
        {
            SetMessage("Выполняю...", Brushes.Gold);
            await action();
        }
        catch (Exception ex)
        {
            SetMessage($"Ошибка: {ex.Message}", Brushes.OrangeRed);
        }
        finally
        {
            IsEnabled = true;
            _busy = false;
        }
    }

    private void SetMessage(string message, Brush color)
    {
        MessageText.Text = message;
        MessageText.Foreground = color;
    }

    private async void Refresh_Click(object sender, RoutedEventArgs e)
    {
        await RunBusyAsync(RefreshStateAsync);
    }

    private async void ChooseGame_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "Выберите Morimens.exe",
            Filter = "Morimens executable (Morimens.exe)|Morimens.exe|Executable (*.exe)|*.exe",
            CheckFileExists = true
        };

        if (dialog.ShowDialog() != true) return;

        _config.GameExecutablePath = dialog.FileName;
        var found = _gameLocator.FindGame();
        if (found is not null
            && string.Equals(found.ExecutablePath, dialog.FileName, StringComparison.OrdinalIgnoreCase))
        {
            _config.SteamAppId = found.AppId;
        }

        await SaveConfigAsync();
        await RefreshStateAsync();
        SetMessage("✓ Клиент игры выбран.", Brushes.LightGreen);
    }

    private async void RestoreOfficial_Click(object sender, RoutedEventArgs e)
    {
        await RunBusyAsync(async () =>
        {
            if (!_redirect.IsAdministrator())
                throw new InvalidOperationException("Перезапусти лаунчер от имени администратора.");

            _redirect.Disable();
            await RefreshStateAsync();
            SetMessage("✓ Официальное подключение восстановлено.", Brushes.LightGreen);
        });
    }
}
