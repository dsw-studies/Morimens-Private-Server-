﻿$ErrorActionPreference = "Stop"

$source = $PSScriptRoot
$target = "D:\Morimens-ReServer\Morimens.Launcher"

$required = @(
    "App.xaml",
    "App.xaml.cs",
    "MainWindow.xaml",
    "MainWindow.xaml.cs",
    "Morimens.Launcher.csproj",
    "app.manifest",
    "launcher.json"
)

foreach ($file in $required) {
    if (-not (Test-Path (Join-Path $source $file))) {
        throw "В распакованной папке отсутствует обязательный файл: $file"
    }
}

Write-Host "Закрываю старые процессы лаунчера..." -ForegroundColor Cyan
Get-Process Morimens.Launcher -ErrorAction SilentlyContinue | Stop-Process -Force

if (Test-Path $target) {
    $backup = "$target.backup-$(Get-Date -Format yyyyMMdd-HHmmss)"
    Write-Host "Перемещаю старую папку в: $backup" -ForegroundColor Yellow
    Move-Item $target $backup
}

New-Item -ItemType Directory -Path $target | Out-Null

Get-ChildItem $source -Force |
    Where-Object { $_.Name -notin @("install_clean.ps1", "README_RU.md", "README.md") } |
    Copy-Item -Destination $target -Recurse -Force

foreach ($file in $required) {
    if (-not (Test-Path (Join-Path $target $file))) {
        throw "После копирования отсутствует обязательный файл: $file"
    }
}

Set-Location $target
dotnet clean
Remove-Item -Recurse -Force .\bin, .\obj -ErrorAction SilentlyContinue
dotnet build

Write-Host ""
Write-Host "Установка и сборка завершены." -ForegroundColor Green
Write-Host "Запуск:"
Write-Host "cd $target"
Write-Host "dotnet run"
