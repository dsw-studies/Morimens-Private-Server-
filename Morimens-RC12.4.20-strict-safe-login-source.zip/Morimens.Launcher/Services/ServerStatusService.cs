using System.Net.Http;

using System.Net.Sockets;

namespace Morimens.Launcher.Services;

public sealed class ServerStatusService : IDisposable
{
    private readonly HttpClient _client = new() { Timeout = TimeSpan.FromSeconds(2) };

    public async Task<(bool HttpOnline, bool TcpOnline, string Message)> CheckAsync(
        string serverUrl,
        string tcpHost,
        int tcpPort)
    {
        var httpOnline = false;
        var tcpOnline = false;
        var messages = new List<string>();

        try
        {
            using var response = await _client.GetAsync(serverUrl.TrimEnd('/') + "/health");
            httpOnline = response.IsSuccessStatusCode;
            messages.Add(httpOnline
                ? "HTTP API онлайн"
                : $"HTTP {(int)response.StatusCode}");
        }
        catch
        {
            messages.Add("HTTP API недоступен");
        }

        try
        {
            using var client = new TcpClient();
            using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(2));
            await client.ConnectAsync(tcpHost, tcpPort, timeout.Token);
            tcpOnline = true;
            messages.Add($"TCP {tcpHost}:{tcpPort} онлайн");
        }
        catch
        {
            messages.Add($"TCP {tcpHost}:{tcpPort} недоступен");
        }

        return (httpOnline, tcpOnline, string.Join(" • ", messages));
    }
    public void Dispose() => _client.Dispose();
}
