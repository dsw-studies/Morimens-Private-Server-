using System.Diagnostics;
using System.IO;

namespace Morimens.Launcher.Services;

public sealed class LocalServerService : IDisposable
{
    private Process? _process;
    private StreamWriter? _logWriter;

    public bool IsRunning => _process is { HasExited: false };

    public string LogPath
    {
        get
        {
            var logDir = Path.Combine(AppContext.BaseDirectory, "Runtime", "Logs");
            return Path.Combine(logDir, "server-startup.log");
        }
    }

    public void Start(string configuredPath)
    {
        if (IsRunning) return;

        // A launcher from an older portable folder may have left the private
        // server running. That orphan keeps the game port occupied and makes
        // the game connect to an outdated build, so currency patches appear
        // not to work. Stop orphaned Morimens.Server processes before starting
        // the server that belongs to this launcher.
        StopOrphanedServers();

        var baseDir = AppContext.BaseDirectory;
        var portableServerDir = Path.Combine(baseDir, "Runtime", "Server");
        var legacyServerDir = Path.Combine(baseDir, "Server");
        var serverDir = Directory.Exists(portableServerDir)
            ? portableServerDir
            : legacyServerDir;
        var exe = Path.Combine(serverDir, "Morimens.Server.exe");
        var dll = Path.Combine(serverDir, "Morimens.Server.dll");

        ProcessStartInfo start;
        if (File.Exists(exe))
        {
            start = CreateHiddenStartInfo(exe, string.Empty, Path.GetDirectoryName(exe)!);
        }
        else if (File.Exists(dll))
        {
            start = CreateHiddenStartInfo("dotnet", $"\"{dll}\"", Path.GetDirectoryName(dll)!);
        }
        else if (!string.IsNullOrWhiteSpace(configuredPath) && File.Exists(configuredPath))
        {
            start = CreateHiddenStartInfo(
                "dotnet",
                $"run --project \"{configuredPath}\"",
                Path.GetDirectoryName(configuredPath)!);
        }
        else
        {
            throw new FileNotFoundException("Компонент приватного сервера не найден рядом с лаунчером.");
        }

        Directory.CreateDirectory(Path.GetDirectoryName(LogPath)!);
        _logWriter?.Dispose();
        _logWriter = new StreamWriter(LogPath, append: false) { AutoFlush = true };
        _logWriter.WriteLine($"[{DateTime.Now:O}] Starting private server");
        _logWriter.WriteLine($"FileName: {start.FileName}");
        _logWriter.WriteLine($"Arguments: {start.Arguments}");
        _logWriter.WriteLine($"WorkingDirectory: {start.WorkingDirectory}");

        _process = new Process
        {
            StartInfo = start,
            EnableRaisingEvents = true
        };
        _process.OutputDataReceived += (_, e) => WriteLog(e.Data);
        _process.ErrorDataReceived += (_, e) => WriteLog(e.Data);
        _process.Exited += (_, _) =>
        {
            try
            {
                WriteLog($"Server exited with code {_process?.ExitCode}.");
            }
            catch
            {
                // The process may already be disposed during application shutdown.
            }
        };

        if (!_process.Start())
            throw new InvalidOperationException("Не удалось запустить приватный сервер.");

        _process.BeginOutputReadLine();
        _process.BeginErrorReadLine();
    }

    public void Stop()
    {
        var process = _process;
        _process = null;

        if (process is not null)
        {
            try
            {
                if (!process.HasExited)
                {
                    process.Kill(entireProcessTree: true);
                    process.WaitForExit(5000);
                }
            }
            catch
            {
                // Shutdown must continue even if the server already exited.
            }
            finally
            {
                process.Dispose();
            }
        }

        try
        {
            _logWriter?.Flush();
            _logWriter?.Dispose();
        }
        catch
        {
            // Ignore log shutdown errors.
        }
        finally
        {
            _logWriter = null;
        }
    }

    public void Dispose() => Stop();

    private static void StopOrphanedServers()
    {
        foreach (Process process in Process.GetProcessesByName("Morimens.Server"))
        {
            try
            {
                if (!process.HasExited)
                {
                    process.Kill(entireProcessTree: true);
                    process.WaitForExit(5000);
                }
            }
            catch
            {
                // A process may exit between enumeration and termination.
                // Startup will still report a clear port error if one remains.
            }
            finally
            {
                process.Dispose();
            }
        }
    }

    private static ProcessStartInfo CreateHiddenStartInfo(
        string fileName,
        string arguments,
        string workingDirectory)
    {
        return new ProcessStartInfo
        {
            FileName = fileName,
            Arguments = arguments,
            WorkingDirectory = workingDirectory,
            UseShellExecute = false,
            CreateNoWindow = true,
            WindowStyle = ProcessWindowStyle.Hidden,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
    }

    private void WriteLog(string? line)
    {
        if (string.IsNullOrEmpty(line)) return;

        try
        {
            _logWriter?.WriteLine($"[{DateTime.Now:HH:mm:ss}] {line}");
        }
        catch
        {
            // Logging must never stop the launcher or the server process.
        }
    }
}
