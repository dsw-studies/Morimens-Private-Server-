using System.IO;
using System.Linq;
using System.Collections.Generic;

using Microsoft.Win32;
using System.Text.RegularExpressions;

namespace Morimens.Launcher.Services;

public sealed record SteamGameInfo(string ExecutablePath, string AppId);

public sealed class SteamGameLocator
{
    private static readonly string[] ExecutableNames =
    {
        "Morimens.exe",
        "MementoMori.exe"
    };

    public SteamGameInfo? FindGame()
    {
        foreach (var library in FindSteamLibraries())
        {
            var steamApps = Path.Combine(library, "steamapps");
            var common = Path.Combine(steamApps, "common");
            if (!Directory.Exists(common)) continue;

            foreach (var exeName in ExecutableNames)
            {
                string? match = null;
                try
                {
                    match = Directory.EnumerateFiles(common, exeName, SearchOption.AllDirectories)
                        .FirstOrDefault();
                }
                catch
                {
                    // Continue with other libraries.
                }

                if (match is null) continue;

                var appId = FindAppIdForExecutable(steamApps, match);
                return new SteamGameInfo(match, appId ?? string.Empty);
            }
        }

        return null;
    }

    private static string? FindAppIdForExecutable(string steamApps, string executablePath)
    {
        foreach (var manifest in Directory.EnumerateFiles(steamApps, "appmanifest_*.acf"))
        {
            try
            {
                var text = File.ReadAllText(manifest);
                var installDir = Regex.Match(
                    text,
                    "\"installdir\"\\s+\"(?<value>[^\"]+)\"",
                    RegexOptions.IgnoreCase).Groups["value"].Value;

                var appId = Regex.Match(
                    text,
                    "\"appid\"\\s+\"(?<value>\\d+)\"",
                    RegexOptions.IgnoreCase).Groups["value"].Value;

                if (string.IsNullOrWhiteSpace(installDir) || string.IsNullOrWhiteSpace(appId))
                    continue;

                var expectedRoot = Path.GetFullPath(
                    Path.Combine(steamApps, "common", installDir));

                var actualPath = Path.GetFullPath(executablePath);
                if (actualPath.StartsWith(
                    expectedRoot.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar,
                    StringComparison.OrdinalIgnoreCase))
                {
                    return appId;
                }
            }
            catch
            {
                // Ignore malformed manifests.
            }
        }

        return null;
    }

    private static IEnumerable<string> FindSteamLibraries()
    {
        var roots = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var steamPath = ReadSteamPath();
        if (string.IsNullOrWhiteSpace(steamPath)) return roots;

        roots.Add(steamPath);
        var vdfPath = Path.Combine(steamPath, "steamapps", "libraryfolders.vdf");
        if (!File.Exists(vdfPath)) return roots;

        try
        {
            var text = File.ReadAllText(vdfPath);
            foreach (Match match in Regex.Matches(text, "\"path\"\\s+\"(?<path>[^\"]+)\""))
            {
                var path = match.Groups["path"].Value.Replace("\\\\", "\\");
                if (Directory.Exists(path)) roots.Add(path);
            }
        }
        catch
        {
            // Default Steam directory remains available.
        }

        return roots;
    }

    private static string? ReadSteamPath()
    {
        foreach (var keyPath in new[]
                 {
                     @"HKEY_CURRENT_USER\Software\Valve\Steam",
                     @"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Valve\Steam"
                 })
        {
            var value = Registry.GetValue(keyPath, "SteamPath", null)?.ToString()
                        ?? Registry.GetValue(keyPath, "InstallPath", null)?.ToString();

            if (!string.IsNullOrWhiteSpace(value) && Directory.Exists(value))
                return value;
        }

        var defaults = new[]
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Steam"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Steam")
        };

        return defaults.FirstOrDefault(Directory.Exists);
    }
}
