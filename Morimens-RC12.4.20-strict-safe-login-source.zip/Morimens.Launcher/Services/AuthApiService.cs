using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;

namespace Morimens.Launcher.Services;

public sealed class AuthApiService : IDisposable
{
    private readonly HttpClient _client = new()
    {
        Timeout = TimeSpan.FromSeconds(10)
    };

    public async Task<AuthResult> RegisterAsync(
        string serverUrl,
        string username,
        string password,
        string displayName,
        CancellationToken cancellationToken = default)
    {
        using var response = await _client.PostAsJsonAsync(
            BuildUrl(serverUrl, "api/auth/register"),
            new { Username = username, Password = password, DisplayName = displayName },
            cancellationToken);

        return await ReadResultAsync(response, cancellationToken);
    }

    public async Task<AuthResult> LoginAsync(
        string serverUrl,
        string username,
        string password,
        string displayName,
        CancellationToken cancellationToken = default)
    {
        using var response = await _client.PostAsJsonAsync(
            BuildUrl(serverUrl, "api/auth/login"),
            new { Username = username, Password = password, DisplayName = displayName },
            cancellationToken);

        return await ReadResultAsync(response, cancellationToken);
    }

    private static string BuildUrl(string baseUrl, string path) =>
        $"{baseUrl.TrimEnd('/')}/{path.TrimStart('/')}";

    private static async Task<AuthResult> ReadResultAsync(
        HttpResponseMessage response,
        CancellationToken cancellationToken)
    {
        var body = await response.Content.ReadAsStringAsync(cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            var message = TryReadError(body)
                ?? response.StatusCode switch
                {
                    HttpStatusCode.Unauthorized => "Неверный логин или пароль.",
                    HttpStatusCode.Conflict => "Такой логин уже зарегистрирован.",
                    _ => $"Сервер вернул ошибку {(int)response.StatusCode}."
                };

            return new AuthResult(false, message, null, null);
        }

        try
        {
            using var document = JsonDocument.Parse(body);
            var root = document.RootElement;
            var token = root.TryGetProperty("token", out var tokenElement)
                ? tokenElement.GetString()
                : null;

            string? displayName = null;
            if (root.TryGetProperty("account", out var account)
                && account.TryGetProperty("displayName", out var displayNameElement))
            {
                displayName = displayNameElement.GetString();
            }

            return new AuthResult(true, "Готово.", token, displayName);
        }
        catch (JsonException)
        {
            return new AuthResult(true, "Готово.", null, null);
        }
    }

    private static string? TryReadError(string body)
    {
        try
        {
            using var document = JsonDocument.Parse(body);
            return document.RootElement.TryGetProperty("error", out var error)
                ? error.GetString()
                : null;
        }
        catch (JsonException)
        {
            return null;
        }
    }

    public void Dispose() => _client.Dispose();
}

public sealed record AuthResult(
    bool Success,
    string Message,
    string? Token,
    string? DisplayName);
