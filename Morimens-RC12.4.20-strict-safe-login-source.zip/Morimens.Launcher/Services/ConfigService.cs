using System.IO;
using System.Text.Json;
using Morimens.Launcher.Models;

namespace Morimens.Launcher.Services;

public sealed class ConfigService
{
    private static readonly JsonSerializerOptions Options = new() { WriteIndented = true };
    private readonly string _path = Path.Combine(AppContext.BaseDirectory, "launcher.json");

    public async Task<LauncherConfig> LoadAsync()
    {
        if (!File.Exists(_path))
        {
            var config = new LauncherConfig();
            await SaveAsync(config);
            return config;
        }

        try
        {
            var json = await File.ReadAllTextAsync(_path);
            return JsonSerializer.Deserialize<LauncherConfig>(json, Options) ?? new LauncherConfig();
        }
        catch
        {
            return new LauncherConfig();
        }
    }

    public Task SaveAsync(LauncherConfig config)
    {
        var json = JsonSerializer.Serialize(config, Options);
        return File.WriteAllTextAsync(_path, json);
    }
}
