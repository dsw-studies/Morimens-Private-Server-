using System.IO;

using System.Net;
using System.Security.Principal;
using System.Text;

namespace Morimens.Launcher.Services;

public sealed class HostsRedirectService
{
    private const string BeginMarker = "# BEGIN MORIMENS PRIVATE SERVER";
    private const string EndMarker = "# END MORIMENS PRIVATE SERVER";

    private static string HostsPath =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "drivers", "etc", "hosts");

    public bool IsAdministrator()
    {
        using var identity = WindowsIdentity.GetCurrent();
        var principal = new WindowsPrincipal(identity);
        return principal.IsInRole(WindowsBuiltInRole.Administrator);
    }

    public bool IsActive(string hostName, string address) =>
        IsEnabled(hostName, address);

    public bool IsEnabled(string hostName, string address)
    {
        if (!File.Exists(HostsPath)) return false;
        var text = File.ReadAllText(HostsPath);
        return text.Contains(BeginMarker, StringComparison.Ordinal)
               && text.Contains($"{address} {hostName}", StringComparison.OrdinalIgnoreCase);
    }

    public void Enable(string hostName, string address)
    {
        Validate(hostName, address);
        EnsureBackup();

        var original = File.ReadAllText(HostsPath);
        var cleaned = RemoveManagedBlock(original).TrimEnd();

        var block = new StringBuilder()
            .AppendLine()
            .AppendLine(BeginMarker)
            .AppendLine($"{address} {hostName}")
            .AppendLine(EndMarker)
            .ToString();

        File.WriteAllText(HostsPath, cleaned + Environment.NewLine + block, new UTF8Encoding(false));
        FlushDns();
    }

    public void Disable()
    {
        if (!File.Exists(HostsPath)) return;

        var original = File.ReadAllText(HostsPath);
        var cleaned = RemoveManagedBlock(original).TrimEnd() + Environment.NewLine;
        File.WriteAllText(HostsPath, cleaned, new UTF8Encoding(false));
        FlushDns();
    }

    private static string RemoveManagedBlock(string text)
    {
        var begin = text.IndexOf(BeginMarker, StringComparison.Ordinal);
        if (begin < 0) return text;

        var end = text.IndexOf(EndMarker, begin, StringComparison.Ordinal);
        if (end < 0) return text[..begin];

        end += EndMarker.Length;
        while (end < text.Length && (text[end] == '\r' || text[end] == '\n'))
            end++;

        return text.Remove(begin, end - begin);
    }

    private static void Validate(string hostName, string address)
    {
        if (string.IsNullOrWhiteSpace(hostName)
            || hostName.Any(char.IsWhiteSpace)
            || hostName.Contains('#'))
        {
            throw new ArgumentException("Некорректное имя игрового хоста.", nameof(hostName));
        }

        if (!IPAddress.TryParse(address, out _))
            throw new ArgumentException("Некорректный IP-адрес.", nameof(address));
    }

    private static void EnsureBackup()
    {
        var backup = HostsPath + ".morimens-backup";
        if (!File.Exists(backup))
            File.Copy(HostsPath, backup, overwrite: false);
    }

    private static void FlushDns()
    {
        try
        {
            using var process = System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = "ipconfig.exe",
                Arguments = "/flushdns",
                CreateNoWindow = true,
                UseShellExecute = false
            });
            process?.WaitForExit(5000);
        }
        catch
        {
            // hosts change is already applied; DNS flush is best effort.
        }
    }
}
