# Launcher architecture

The launcher currently handles discovery, status checks, settings and process startup. It intentionally does not patch the original client yet. Network redirection will be added after the official Morimens bootstrap/login protocol is documented.
