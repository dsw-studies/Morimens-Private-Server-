param([string]$ProjectRoot = (Resolve-Path "$PSScriptRoot\..").Path)
$ErrorActionPreference = 'Stop'
$files = @(
  'Morimens.Server\Features\Gateway\AccountService.cs',
  'Morimens.Server\Protocol\Rpc\CapturedInitialGameStreamBuilder.cs',
  'Morimens.Server\Features\Economy\EconomyCatalog.cs',
  'Morimens.Server\Features\Economy\GameEconomyService.cs'
)
$backup = Join-Path $ProjectRoot ('Backups\gacha-currency-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
foreach ($rel in $files) {
  $src = Join-Path $PSScriptRoot $rel
  $dst = Join-Path $ProjectRoot $rel
  if (!(Test-Path $dst)) { throw "Project file not found: $dst" }
  $bak = Join-Path $backup $rel
  New-Item -ItemType Directory -Force -Path (Split-Path $bak) | Out-Null
  Copy-Item $dst $bak -Force
  Copy-Item $src $dst -Force
}
Write-Host "Patch applied. Backup: $backup" -ForegroundColor Green
Write-Host "Now run: .\build-portable.cmd" -ForegroundColor Cyan
