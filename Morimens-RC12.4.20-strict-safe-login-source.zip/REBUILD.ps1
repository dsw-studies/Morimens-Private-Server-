$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Get-Process Morimens.Server -ErrorAction SilentlyContinue | Stop-Process -Force
Get-Process Morimens.Launcher -ErrorAction SilentlyContinue | Stop-Process -Force
Remove-Item .\publish -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item .\Morimens.Server\bin,.\Morimens.Server\obj,.\Morimens.Launcher\bin,.\Morimens.Launcher\obj -Recurse -Force -ErrorAction SilentlyContinue
dotnet restore .\Morimens.sln
dotnet build .\Morimens.sln -c Release
.\build-portable.cmd
Write-Host "Done. Start publish\MorimensPortable\Morimens.Launcher.exe" -ForegroundColor Green
