@echo off
setlocal
cd /d "%~dp0"
echo [1/2] Restoring solution...
dotnet restore Morimens.sln
if errorlevel 1 goto fail
echo [2/2] Publishing Morimens Launcher...
dotnet publish Morimens.Launcher\Morimens.Launcher.csproj -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
if errorlevel 1 goto fail
start "" "%~dp0Morimens.Launcher\bin\Release\net8.0-windows\win-x64\publish"
exit /b 0
:fail
echo.
echo Build failed. See the error above.
pause
exit /b 1
