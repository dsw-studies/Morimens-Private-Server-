@echo off
setlocal
cd /d "%~dp0"

set "OUT=%CD%\publish\MorimensPortable"
set "SERVER_OUT=%OUT%\Runtime\Server"

if exist "%OUT%" rmdir /s /q "%OUT%"
if exist "%CD%\publish\MorimensPortable-win-x64.zip" del /q "%CD%\publish\MorimensPortable-win-x64.zip"
mkdir "%SERVER_OUT%"
if errorlevel 1 goto :error

echo [1/4] Restore...
dotnet restore Morimens.sln
if errorlevel 1 goto :error

echo [2/4] Publish private server...
dotnet publish Morimens.Server\Morimens.Server.csproj ^
  -c Release -r win-x64 --self-contained true ^
  -p:PublishSingleFile=true ^
  -p:IncludeNativeLibrariesForSelfExtract=true ^
  -o "%SERVER_OUT%"
if errorlevel 1 goto :error

echo [3/4] Publish launcher...
dotnet publish Morimens.Launcher\Morimens.Launcher.csproj ^
  -c Release -r win-x64 --self-contained true ^
  -p:PublishSingleFile=true ^
  -p:IncludeNativeLibrariesForSelfExtract=true ^
  -o "%OUT%"
if errorlevel 1 goto :error

if exist "%OUT%\launcher.json" del /q "%OUT%\launcher.json"

echo [4/4] Create portable ZIP...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Compress-Archive -Path '%OUT%\*' -DestinationPath '%CD%\publish\MorimensPortable-win-x64.zip' -Force"
if errorlevel 1 goto :error

echo.
echo Ready:
echo   %OUT%\Morimens.Launcher.exe
echo   %CD%\publish\MorimensPortable-win-x64.zip
exit /b 0

:error
echo.
echo Build failed. Portable launcher was not created.
if exist "%OUT%" rmdir /s /q "%OUT%"
if exist "%CD%\publish\MorimensPortable-win-x64.zip" del /q "%CD%\publish\MorimensPortable-win-x64.zip"
exit /b 1
