using System.Security.Claims;

namespace Morimens.Server.Common.Extensions;

public static class ClaimsPrincipalExtensions
{
    public static bool TryGetAccountId(this ClaimsPrincipal user, out Guid accountId)
    {
        var value = user.FindFirstValue(ClaimTypes.NameIdentifier)
                    ?? user.FindFirstValue("sub");
        return Guid.TryParse(value, out accountId);
    }
}
