const state = {
  key: localStorage.getItem("morimens-admin-key") || "",
  players: [],
  selected: null,
  catalog: null
};

const $ = selector => document.querySelector(selector);
const log = message => {
  $("#log").textContent = `[${new Date().toLocaleTimeString()}] ${message}\n` + $("#log").textContent;
};

$("#adminKey").value = state.key;
$("#saveKey").onclick = () => {
  state.key = $("#adminKey").value;
  localStorage.setItem("morimens-admin-key", state.key);
  refreshAll();
};

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "X-Admin-Key": state.key,
      ...(options.headers || {})
    }
  });

  const text = await response.text();
  let body = null;
  try { body = text ? JSON.parse(text) : null; } catch { body = text; }

  if (!response.ok)
    throw new Error(body?.error || body || `${response.status} ${response.statusText}`);

  return body;
}

async function refreshOverview() {
  const data = await api("/api/admin/overview");
  $("#stats").innerHTML = Object.entries(data)
    .map(([name,value]) => `<div class="stat"><strong>${value}</strong><span>${name}</span></div>`)
    .join("");
}

async function refreshPlayers() {
  state.players = await api("/api/admin/players");
  $("#playerList").innerHTML = state.players.map(player => `
    <div class="player" data-id="${player.id}">
      <b>${escapeHtml(player.profile?.displayName || player.username)}</b>
      <div>${escapeHtml(player.username)}</div>
      <div class="sub">Lv.${player.profile?.level ?? 1} · ${player.profile?.premiumCurrency ?? 0} premium</div>
      ${player.isBanned ? '<div class="bad">ЗАБЛОКИРОВАН</div>' : ''}
    </div>
  `).join("");

  document.querySelectorAll(".player").forEach(node => {
    node.onclick = () => openPlayer(node.dataset.id);
  });
}

async function refreshCatalog() {
  state.catalog = await api("/api/admin/catalog");
  $("#catalog").innerHTML = `
    <div class="card"><h3>Герои</h3><pre>${escapeHtml(JSON.stringify(state.catalog.heroes, null, 2))}</pre></div>
    <div class="card"><h3>Магазин</h3><pre>${escapeHtml(JSON.stringify(state.catalog.shopOffers, null, 2))}</pre></div>
    <div class="card"><h3>Баннеры</h3><pre>${escapeHtml(JSON.stringify(state.catalog.banners, null, 2))}</pre></div>
  `;
}

async function openPlayer(id) {
  const player = await api(`/api/admin/players/${id}`);
  state.selected = player;

  $("#editor").classList.remove("muted");
  $("#editor").innerHTML = `
    <h2>${escapeHtml(player.profile.displayName)}</h2>
    <div class="row">
      <input id="displayName" value="${attr(player.profile.displayName)}" placeholder="Имя">
      <input id="level" type="number" value="${player.profile.level}" placeholder="Уровень">
      <input id="gold" type="number" value="${player.profile.gold}" placeholder="Золото">
      <input id="premium" type="number" value="${player.profile.premiumCurrency}" placeholder="Premium">
    </div>
    <div class="actions">
      <button id="saveProfile">Сохранить профиль</button>
      <button id="toggleBan">${player.isBanned ? "Разблокировать" : "Заблокировать"}</button>
    </div>

    <h3>Инвентарь</h3>
    <div class="row">
      <input id="itemId" type="number" placeholder="Item ID">
      <input id="itemDelta" type="number" placeholder="+/- количество">
      <button id="changeItem">Изменить</button>
    </div>
    <div class="cards">
      ${player.inventory.map(x => `<div class="card">Item ${x.itemId}<br><b>${x.quantity}</b></div>`).join("") || '<span class="muted">Пусто</span>'}
    </div>

    <h3>Герои</h3>
    <div class="row">
      <input id="heroId" type="number" placeholder="Template ID">
      <input id="heroLevel" type="number" value="1" placeholder="Уровень">
      <input id="heroStars" type="number" value="1" placeholder="Звёзды">
      <button id="grantHero">Выдать</button>
    </div>
    <div class="cards">
      ${player.heroes.map(x => `<div class="card">Hero ${x.templateId}<br>Lv.${x.level} · Rank ${x.rank} · ★${x.stars}<br>Fragments ${x.duplicateFragments}</div>`).join("") || '<span class="muted">Нет героев</span>'}
    </div>

    <h3>Гача и магазин</h3>
    <div class="actions">
      <button id="pullOne">Гача ×1</button>
      <button id="pullTen">Гача ×10</button>
      ${(state.catalog?.shopOffers || []).map(x => `<button class="buy" data-offer="${x.offerId}">Купить: ${escapeHtml(x.name)}</button>`).join("")}
    </div>
  `;

  $("#saveProfile").onclick = async () => {
    await api(`/api/admin/players/${id}/profile`, {
      method: "PATCH",
      body: JSON.stringify({
        displayName: $("#displayName").value,
        level: Number($("#level").value),
        gold: Number($("#gold").value),
        premiumCurrency: Number($("#premium").value)
      })
    });
    log("Профиль сохранён.");
    await openPlayer(id);
    await refreshPlayers();
  };

  $("#toggleBan").onclick = async () => {
    await api(`/api/admin/players/${id}/profile`, {
      method: "PATCH",
      body: JSON.stringify({ isBanned: !player.isBanned })
    });
    log("Статус блокировки изменён.");
    await openPlayer(id);
    await refreshPlayers();
  };

  $("#changeItem").onclick = async () => {
    await api(`/api/admin/players/${id}/inventory`, {
      method: "POST",
      body: JSON.stringify({
        itemId: Number($("#itemId").value),
        delta: Number($("#itemDelta").value)
      })
    });
    log("Инвентарь изменён.");
    await openPlayer(id);
  };

  $("#grantHero").onclick = async () => {
    await api(`/api/admin/players/${id}/heroes`, {
      method: "POST",
      body: JSON.stringify({
        templateId: Number($("#heroId").value),
        level: Number($("#heroLevel").value),
        rank: 1,
        stars: Number($("#heroStars").value)
      })
    });
    log("Герой выдан.");
    await openPlayer(id);
  };

  $("#pullOne").onclick = () => pull(id, 1);
  $("#pullTen").onclick = () => pull(id, 10);

  document.querySelectorAll(".buy").forEach(button => {
    button.onclick = async () => {
      await api(`/api/admin/players/${id}/shop`, {
        method: "POST",
        body: JSON.stringify({ offerId: button.dataset.offer, quantity: 1 })
      });
      log(`Покупка ${button.dataset.offer} выполнена.`);
      await openPlayer(id);
    };
  });
}

async function pull(id, count) {
  const result = await api(`/api/admin/players/${id}/gacha`, {
    method: "POST",
    body: JSON.stringify({ bannerId: "standard", count })
  });
  log(`Гача ×${count}: ${result.map(x => `${x.characterName} (${x.rarity}★)`).join(", ")}`);
  await openPlayer(id);
}

$("#createPlayer").onsubmit = async event => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.target).entries());
  await api("/api/admin/players", {
    method: "POST",
    body: JSON.stringify(data)
  });
  event.target.reset();
  log("Игрок создан.");
  await refreshAll();
};

$("#refreshPlayers").onclick = refreshAll;

async function refreshAll() {
  try {
    await Promise.all([refreshOverview(), refreshPlayers(), refreshCatalog()]);
    log("Данные обновлены.");
  } catch (error) {
    log(`Ошибка: ${error.message}`);
  }
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[char]));
}
function attr(value) {
  return escapeHtml(value).replace(/`/g, "&#096;");
}

refreshAll();
