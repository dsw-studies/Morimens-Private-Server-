using Microsoft.AspNetCore.Mvc;
using Morimens.Server.Networking.Sessions;

namespace Morimens.Server.Networking;

[ApiController]
[Route("api/tcp/sessions")]
public sealed class SessionsController(GameSessionRegistry registry) : ControllerBase
{
    [HttpGet]
    public IActionResult GetSessions() => Ok(registry.Snapshot.Select(x => new
    {
        x.Id,
        x.ConnectedAt,
        remote = x.RemoteEndPoint?.ToString(),
        x.State,
        x.ReceivedFrames,
        x.SentFrames,
        x.ReceivedBytes,
        x.SentBytes,
        protocol = x.ClientHandshake?.ProtocolVersion,
        serverName = x.ClientHandshake?.ServerName,
        compression = x.ClientHandshake?.Compression
    }));
}
