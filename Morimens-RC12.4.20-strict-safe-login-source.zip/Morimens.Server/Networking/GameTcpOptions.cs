namespace Morimens.Server.Networking;

public sealed class GameTcpOptions
{
    public const string SectionName = "GameTcp";

    public string Mode { get; set; } = "Server";
    public int ListenPort { get; set; } = 8443;
    public string UpstreamHost { get; set; } = "34.36.56.239";
    public int UpstreamPort { get; set; } = 8443;
    public string DumpDirectory { get; set; } = "Dumps";
    public string SessionDirectory { get; set; } = "Sessions";
    public int MaximumFrameLength { get; set; } = ushort.MaxValue;
    public int IdleTimeoutSeconds { get; set; } = 30;
    public bool CaptureEncryptedFrames { get; set; } = true;
    public bool CaptureDecryptedCandidates { get; set; } = true;
}
