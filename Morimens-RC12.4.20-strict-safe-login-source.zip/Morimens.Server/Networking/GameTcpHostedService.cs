using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using Microsoft.Extensions.Options;
using Morimens.Server.Networking.Sessions;
using Morimens.Server.Protocol.Crypto;
using Morimens.Server.Protocol.Rpc;
using Morimens.Server.Protocol.Sconn;
using Morimens.Server.Protocol.Tcp;

namespace Morimens.Server.Networking;

public sealed class GameTcpHostedService : BackgroundService
{
    private readonly ILogger<GameTcpHostedService> _logger;
    private readonly GameTcpOptions _options;
    private readonly GameSessionRegistry _sessions;
    private readonly IRpcDispatcher _rpcDispatcher;
    private TcpListener? _listener;

    public GameTcpHostedService(
        ILogger<GameTcpHostedService> logger,
        IOptions<GameTcpOptions> options,
        GameSessionRegistry sessions,
        IRpcDispatcher rpcDispatcher)
    {
        _logger = logger;
        _options = options.Value;
        _sessions = sessions;
        _rpcDispatcher = rpcDispatcher;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _listener = new TcpListener(IPAddress.Any, _options.ListenPort);
        _listener.Start();

        _logger.LogInformation(
            "Morimens TCP listener started on 0.0.0.0:{Port} in {Mode} mode.",
            _options.ListenPort,
            _options.Mode);

        try
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                TcpClient client = await _listener.AcceptTcpClientAsync(stoppingToken);
                _ = HandleClientSafelyAsync(client, stoppingToken);
            }
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
        }
        finally
        {
            _listener.Stop();
        }
    }

    private async Task HandleClientSafelyAsync(TcpClient client, CancellationToken stoppingToken)
    {
        try
        {
            if (string.Equals(_options.Mode, "Proxy", StringComparison.OrdinalIgnoreCase))
                await HandleProxyClientAsync(client, stoppingToken);
            else
                await HandlePrivateServerClientAsync(client, stoppingToken);
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
        }
        catch (Exception exception)
        {
            _logger.LogError(exception, "TCP client processing failed for {Endpoint}.", client.Client.RemoteEndPoint);
        }
        finally
        {
            client.Dispose();
        }
    }

    private async Task HandlePrivateServerClientAsync(TcpClient client, CancellationToken stoppingToken)
    {
        var session = new GameSessionContext { RemoteEndPoint = client.Client.RemoteEndPoint };
        _sessions.Add(session);

        await using var capture = new SessionCaptureWriter(_options.SessionDirectory, session);
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(stoppingToken);
        timeout.CancelAfter(TimeSpan.FromSeconds(Math.Max(5, _options.IdleTimeoutSeconds)));
        CancellationToken cancellationToken = timeout.Token;

        try
        {
            _logger.LogInformation(
                "Session {SessionId} connected from {Endpoint}. Capture: {CaptureDirectory}",
                session.Id,
                session.RemoteEndPoint,
                capture.DirectoryPath);

            using NetworkStream stream = client.GetStream();
            byte[]? clientHello = await MorimensFrameCodec.ReadAsync(
                stream,
                _options.MaximumFrameLength,
                cancellationToken);

            if (clientHello is null)
                return;

            await capture.WriteAsync("C2S", "handshake", clientHello, cancellationToken);
            session.ReceivedFrames++;
            session.ReceivedBytes += clientHello.Length;

            MorimensClientHandshake handshake = MorimensHandshake.ParseClient(clientHello);
            if (!string.Equals(handshake.ServerName, "operate-global-game", StringComparison.Ordinal))
                throw new InvalidDataException($"Unexpected server name: {handshake.ServerName}.");

            session.ClientHandshake = handshake;
            session.Keys = MorimensHandshake.CreateSessionKeys(handshake.ClientPublicKey);
            session.State = "HandshakeComplete";

            byte[] serverHello = MorimensHandshake.BuildServerPayload(session.Keys, handshake.Compression);
            await MorimensFrameCodec.WriteAsync(stream, serverHello, cancellationToken);
            await capture.WriteAsync("S2C", "handshake", serverHello, cancellationToken);
            session.SentFrames++;
            session.SentBytes += serverHello.Length;

            _logger.LogInformation(
                "Session {SessionId}: handshake complete. Protocol={Protocol}, compression={Compression}, " +
                "key0={Key0}, key1={Key1}, key2={Key2}, key3={Key3}.",
                session.Id,
                handshake.ProtocolVersion,
                handshake.Compression,
                Convert.ToHexString(session.Keys.Key0),
                Convert.ToHexString(session.Keys.Key1),
                Convert.ToHexString(session.Keys.Key2),
                Convert.ToHexString(session.Keys.Key3));

            session.State = "AwaitingRawPostHandshake";
            timeout.CancelAfter(Timeout.InfiniteTimeSpan);

            // Р”РёР°РіРЅРѕСЃС‚РёС‡РµСЃРєРёР№ СЂРµР¶РёРј: РїРѕСЃР»Рµ server hello С‡РёС‚Р°РµРј РїРѕС‚РѕРє РєР°Рє РµСЃС‚СЊ,
            // РЅРµ РїСЂРµРґРїРѕР»Р°РіР°СЏ РЅР°Р»РёС‡РёРµ РґРІСѓС…Р±Р°Р№С‚РѕРІРѕРіРѕ frame header.
            byte[] wireHello = new byte[serverHello.Length + 2];
            System.Buffers.Binary.BinaryPrimitives.WriteUInt16BigEndian(
                wireHello.AsSpan(0, 2),
                checked((ushort)serverHello.Length));
            serverHello.CopyTo(wireHello.AsSpan(2));
            await File.WriteAllBytesAsync(
                Path.Combine(capture.DirectoryPath, "S2C_handshake_wire.bin"),
                wireHello,
                stoppingToken);

            await CaptureSconnBurstsAsync(
                stream,
                capture,
                session,
                stoppingToken);
        }
        catch (OperationCanceledException) when (timeout.IsCancellationRequested)
        {
            session.State = "TimedOut";
            _logger.LogInformation("Session {SessionId} timed out in state {State}.", session.Id, session.State);
        }
        finally
        {
            if (session.State != "TimedOut")
                session.State = "Disconnected";
            _sessions.Remove(session.Id);
            _logger.LogInformation("Session {SessionId} closed.", session.Id);
        }
    }


    private async Task CaptureSconnBurstsAsync(
        NetworkStream stream,
        SessionCaptureWriter capture,
        GameSessionContext session,
        CancellationToken stoppingToken)
    {
        const int totalTimeoutSeconds = 600;
        const int burstIdleMilliseconds = 35;
        const int followupIdleMilliseconds = 1200;

        byte[] readBuffer = new byte[65536];
        int burstNumber = 0;
        long totalBytes = 0;
        MorimensRc4Stream? c2sRc4 = null;
        MorimensRc4Stream? s2cRc4 = null;

        using var totalTimeout =
            CancellationTokenSource.CreateLinkedTokenSource(stoppingToken);
        totalTimeout.CancelAfter(TimeSpan.FromSeconds(totalTimeoutSeconds));

        _logger.LogInformation(
            "Session {SessionId}: sconn burst capture started; total timeout={TotalTimeout}s, " +
            "burst idle={BurstIdle}ms.",
            session.Id,
            totalTimeoutSeconds,
            burstIdleMilliseconds);

        while (!stoppingToken.IsCancellationRequested)
        {
            int firstRead;
            try
            {
                firstRead = await stream.ReadAsync(
                    readBuffer.AsMemory(),
                    totalTimeout.Token);
            }
            catch (OperationCanceledException)
                when (!stoppingToken.IsCancellationRequested &&
                      totalTimeout.IsCancellationRequested)
            {
                session.State = "SconnTimedOut";
                _logger.LogWarning(
                    "Session {SessionId}: sconn capture timeout after {Timeout}s; " +
                    "bursts={Bursts}, total={Total}.",
                    session.Id,
                    totalTimeoutSeconds,
                    burstNumber,
                    totalBytes);
                return;
            }

            if (firstRead == 0)
            {
                session.State = "ClientClosedAfterSconn";
                _logger.LogWarning(
                    "Session {SessionId}: client closed after sconn traffic; bursts={Bursts}, total={Total}.",
                    session.Id,
                    burstNumber,
                    totalBytes);
                return;
            }

            using var burst = new MemoryStream();
            burst.Write(readBuffer, 0, firstRead);

            // TCP does not preserve send() boundaries. We approximate application writes
            // by draining bytes that arrive within a short idle window.
            while (!stoppingToken.IsCancellationRequested)
            {
                await Task.Delay(burstIdleMilliseconds, stoppingToken);

                bool drainedAny = false;
                while (stream.DataAvailable)
                {
                    int read = await stream.ReadAsync(
                        readBuffer.AsMemory(),
                        stoppingToken);
                    if (read == 0)
                        break;

                    burst.Write(readBuffer, 0, read);
                    drainedAny = true;
                }

                if (!drainedAny)
                    break;
            }

            burstNumber++;
            byte[] raw = burst.ToArray();
            totalBytes += raw.Length;
            session.ReceivedBytes += raw.Length;

            await capture.WriteAsync(
                "C2S",
                $"sconn-burst-{burstNumber:D4}",
                raw,
                stoppingToken);

            string streamPath = Path.Combine(
                capture.DirectoryPath,
                "C2S_sconn_stream.bin");

            await using (var streamFile = new FileStream(
                streamPath,
                FileMode.Append,
                FileAccess.Write,
                FileShare.Read,
                4096,
                useAsync: true))
            {
                await streamFile.WriteAsync(raw, stoppingToken);
            }

            if (session.Keys is null)
                throw new InvalidOperationException("Session keys are unavailable after handshake.");

            c2sRc4 ??= new MorimensRc4Stream(
                SconnTransportDecoder.BuildSessionKey(session.Keys));
            s2cRc4 ??= new MorimensRc4Stream(
                SconnTransportDecoder.BuildSessionKey(session.Keys));

            SconnDecodeResult decoded = SconnTransportDecoder.Decode(
                raw,
                c2sRc4);

            await capture.WriteAsync(
                "C2S",
                $"sconn-burst-{burstNumber:D4}-rc4-plain",
                decoded.Rc4Plaintext,
                stoppingToken);

            await capture.WriteAsync(
                "C2S",
                $"sconn-burst-{burstNumber:D4}-rpc",
                decoded.RpcPayload,
                stoppingToken);

            var analysis = new
            {
                CipherLength = decoded.Ciphertext.Length,
                Rc4PlainLength = decoded.Rc4Plaintext.Length,
                RpcPayloadLength = decoded.RpcPayload.Length,
                HasLz4Frame = decoded.HasLz4Frame,
                CipherHex32 = Convert.ToHexString(
                    decoded.Ciphertext.AsSpan(0, Math.Min(decoded.Ciphertext.Length, 32))),
                Rc4PlainHex32 = Convert.ToHexString(
                    decoded.Rc4Plaintext.AsSpan(0, Math.Min(decoded.Rc4Plaintext.Length, 32))),
                RpcHex32 = Convert.ToHexString(
                    decoded.RpcPayload.AsSpan(0, Math.Min(decoded.RpcPayload.Length, 32)))
            };

            string analysisPath = Path.Combine(
                capture.DirectoryPath,
                $"sconn-burst-{burstNumber:D4}-decode.json");
            await File.WriteAllTextAsync(
                analysisPath,
                JsonSerializer.Serialize(
                    analysis,
                    new JsonSerializerOptions { WriteIndented = true }),
                stoppingToken);

            _logger.LogInformation(
                "Session {SessionId}: decoded sconn burst={Burst}, cipher={CipherLength}, " +
                "rc4Plain={Rc4PlainLength}, rpc={RpcLength}, lz4={HasLz4}, rpcHex32={RpcPreview}.",
                session.Id,
                burstNumber,
                decoded.Ciphertext.Length,
                decoded.Rc4Plaintext.Length,
                decoded.RpcPayload.Length,
                decoded.HasLz4Frame,
                analysis.RpcHex32);

            LoginRequestInspection loginInspection =
                LoginRequestInspector.Inspect(decoded.RpcPayload);

            string loginInspectionPath = Path.Combine(
                capture.DirectoryPath,
                $"login-request-{burstNumber:D4}.json");
            await File.WriteAllTextAsync(
                loginInspectionPath,
                JsonSerializer.Serialize(
                    loginInspection,
                    new JsonSerializerOptions { WriteIndented = true }),
                stoppingToken);

            IReadOnlyList<GameRpcRequest> parsedGameRequests =
                GameRpcStreamParser.Parse(decoded.RpcPayload);

            if (parsedGameRequests.Count > 0)
            {
                string gameRpcInfoPath = Path.Combine(
                    capture.DirectoryPath,
                    $"game-rpc-burst-{burstNumber:D4}.json");

                await File.WriteAllTextAsync(
                    gameRpcInfoPath,
                    JsonSerializer.Serialize(
                        parsedGameRequests.Select(
                            request => new
                            {
                                request.Sequence,
                                request.Method,
                                FrameLength = request.Frame.Length
                            }),
                        new JsonSerializerOptions { WriteIndented = true }),
                    stoppingToken);
            }

            GameRpcRequest? exactGameLogin =
                parsedGameRequests.FirstOrDefault(
                    request => string.Equals(
                        request.Method,
                        "Login",
                        StringComparison.Ordinal));

            if (exactGameLogin is not null && decoded.RpcPayload.Length < 1200)
            {
                await capture.WriteAsync(
                    "C2S",
                    $"game-login-request-{burstNumber:D4}-rpc",
                    decoded.RpcPayload,
                    stoppingToken);

                string gameLoginInfoPath = Path.Combine(
                    capture.DirectoryPath,
                    $"game-login-request-{burstNumber:D4}.json");

                await File.WriteAllTextAsync(
                    gameLoginInfoPath,
                    JsonSerializer.Serialize(
                        new
                        {
                            Method = exactGameLogin.Method,
                            exactGameLogin.Sequence,
                            PayloadLength = decoded.RpcPayload.Length,
                            RpcHex64 = Convert.ToHexString(
                                decoded.RpcPayload.AsSpan(
                                    0,
                                    Math.Min(decoded.RpcPayload.Length, 64)))
                        },
                        new JsonSerializerOptions { WriteIndented = true }),
                    stoppingToken);

                _logger.LogInformation(
                    "Session {SessionId}: exact GAME Login request saved. " +
                    "sequence={Sequence}, rpc={RpcLength}.",
                    session.Id,
                    exactGameLogin.Sequence,
                    decoded.RpcPayload.Length);
            }

            RpcDispatchResult dispatchResult = await _rpcDispatcher.DispatchAsync(
                session,
                decoded.RpcPayload,
                stoppingToken);

            _logger.LogInformation(
                "Session {SessionId}: RPC dispatch handled={Handled}, detail={Detail}.",
                session.Id,
                dispatchResult.Handled,
                dispatchResult.Detail);

            if (dispatchResult.Handled &&
                dispatchResult.Response is { Length: > 0 } responseRpc)
            {
                ushort requestSequence = parsedGameRequests.Count > 0
                    ? parsedGameRequests[0].Sequence
                    : decoded.RpcPayload.Length > 6
                        ? decoded.RpcPayload[6]
                        : throw new InvalidDataException(
                            "RPC request sequence byte is missing.");

                bool gameNodeResponse = dispatchResult.Detail.StartsWith(
                    "Game-node",
                    StringComparison.Ordinal);
                bool capturedInitialGameStream = dispatchResult.Detail.StartsWith(
                    "Captured initial game stream",
                    StringComparison.Ordinal);
                bool capturedPostLoginStream = dispatchResult.Detail.StartsWith(
                    "Captured post-login stream",
                    StringComparison.Ordinal);
                bool capturedGameLoginResponse = dispatchResult.Detail.StartsWith(
                    "Captured Game Login response",
                    StringComparison.Ordinal);

                byte[] responseWire = capturedInitialGameStream
                    ? SconnTransportEncoder.EncodeCapturedInitialGameStream(
                        responseRpc,
                        session.Keys,
                        s2cRc4)
                    : capturedPostLoginStream
                        ? SconnTransportEncoder.EncodeCapturedPostLoginStream(
                            responseRpc,
                            session.Keys,
                            s2cRc4)
                        : capturedGameLoginResponse
                            ? SconnTransportEncoder.EncodeCapturedGameLoginResponse(
                                responseRpc,
                                session.Keys,
                                s2cRc4)
                            : gameNodeResponse
                                ? SconnTransportEncoder.EncodeGameNodeResponse(
                                    responseRpc,
                                    checked((byte)requestSequence),
                                    session.Keys,
                                    s2cRc4)
                                : SconnTransportEncoder.EncodeGatewayResponse(
                                    responseRpc,
                                    checked((byte)requestSequence),
                                    session.Keys,
                                    s2cRc4);

                await stream.WriteAsync(responseWire, stoppingToken);
                await stream.FlushAsync(stoppingToken);

                await capture.WriteAsync(
                    "S2C",
                    $"login-response-{burstNumber:D4}-rpc",
                    responseRpc,
                    stoppingToken);
                await capture.WriteAsync(
                    "S2C",
                    $"login-response-{burstNumber:D4}-wire",
                    responseWire,
                    stoppingToken);

                session.SentFrames++;
                session.SentBytes += responseWire.Length;
                session.State = "MinimalLoginResponseSent";

                _logger.LogInformation(
                    "Session {SessionId}: {ResponseKind} sent. sequence={Sequence}, rpc={RpcLength}, wire={WireLength}.",
                    session.Id,
                    capturedInitialGameStream
                        ? "exact initial GAME stream"
                        : capturedPostLoginStream
                            ? "captured post-login GAME stream"
                            : capturedGameLoginResponse
                                ? "captured GAME Login response"
                                : gameNodeResponse
                                    ? "game-node account response"
                                    : "gateway LoginResponse",
                    requestSequence,
                    responseRpc.Length,
                    responseWire.Length);

                // Keep the connection open so the client can either accept the
                // response and send its next RPC, or close it itself on a parse error.

                _logger.LogInformation(
                    "Session {SessionId}: waiting for client follow-up after LoginResponse.",
                    session.Id);
            }

            if (raw.Length is >= 24 and <= 40)
            {
                _logger.LogInformation(
                    "Session {SessionId}: burst {Burst} matches the observed small sconn service block range.",
                    session.Id,
                    burstNumber);
            }
            else if (raw.Length is >= 140 and <= 220)
            {
                _logger.LogInformation(
                    "Session {SessionId}: burst {Burst} matches the observed medium authorization block range.",
                    session.Id,
                    burstNumber);
            }
            else if (raw.Length >= 1500)
            {
                _logger.LogInformation(
                    "Session {SessionId}: burst {Burst} matches the observed main LoginRequest range.",
                    session.Id,
                    burstNumber);
            }

            // Allow the client time to wait for a server response between bursts.
            // No response is fabricated in this diagnostic version.
            totalTimeout.CancelAfter(
                TimeSpan.FromSeconds(totalTimeoutSeconds));

            await Task.Delay(followupIdleMilliseconds, stoppingToken);
        }
    }

    private async Task HandleProxyClientAsync(TcpClient client, CancellationToken cancellationToken)
    {
        EndPoint? endpoint = client.Client.RemoteEndPoint;
        _logger.LogInformation(
            "Proxy client {Endpoint}; connecting to {Host}:{Port}.",
            endpoint,
            _options.UpstreamHost,
            _options.UpstreamPort);

        using var upstream = new TcpClient();
        await upstream.ConnectAsync(_options.UpstreamHost, _options.UpstreamPort, cancellationToken);

        string sessionName = $"{DateTime.UtcNow:yyyyMMdd_HHmmss_fff}_{Guid.NewGuid():N}";
        string directory = Path.GetFullPath(Path.Combine(_options.DumpDirectory, sessionName));
        Directory.CreateDirectory(directory);

        using NetworkStream clientStream = client.GetStream();
        using NetworkStream upstreamStream = upstream.GetStream();
        using var linked = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        using var gate = new SemaphoreSlim(1, 1);

        Task c2s = PumpAsync(clientStream, upstreamStream, directory, "client-to-server", gate, linked.Token);
        Task s2c = PumpAsync(upstreamStream, clientStream, directory, "server-to-client", gate, linked.Token);

        await Task.WhenAny(c2s, s2c);
        linked.Cancel();
        try { await Task.WhenAll(c2s, s2c); } catch (OperationCanceledException) { }
    }

    private static async Task PumpAsync(
        Stream source,
        Stream destination,
        string directory,
        string direction,
        SemaphoreSlim gate,
        CancellationToken cancellationToken)
    {
        string binaryPath = Path.Combine(directory, direction + ".bin");
        string eventsPath = Path.Combine(directory, "traffic.jsonl");
        await using var dump = new FileStream(binaryPath, FileMode.Create, FileAccess.Write, FileShare.Read, 65536, true);
        byte[] buffer = new byte[65536];
        long offset = 0;

        while (!cancellationToken.IsCancellationRequested)
        {
            int read = await source.ReadAsync(buffer, cancellationToken);
            if (read == 0)
                break;

            await dump.WriteAsync(buffer.AsMemory(0, read), cancellationToken);
            await destination.WriteAsync(buffer.AsMemory(0, read), cancellationToken);
            await destination.FlushAsync(cancellationToken);

            var entry = new
            {
                timestampUtc = DateTimeOffset.UtcNow,
                direction,
                offset,
                length = read,
                firstBytesHex = Convert.ToHexString(buffer.AsSpan(0, Math.Min(read, 64)))
            };

            await gate.WaitAsync(cancellationToken);
            try
            {
                await File.AppendAllTextAsync(
                    eventsPath,
                    JsonSerializer.Serialize(entry) + Environment.NewLine,
                    cancellationToken);
            }
            finally
            {
                gate.Release();
            }

            offset += read;
        }
    }
}

