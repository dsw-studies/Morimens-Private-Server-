using System.Collections.Concurrent;

namespace Morimens.Server.Networking.Sessions;

public sealed class GameSessionRegistry
{
    private readonly ConcurrentDictionary<Guid, GameSessionContext> _sessions = new();

    public IReadOnlyCollection<GameSessionContext> Snapshot => _sessions.Values.ToArray();

    public void Add(GameSessionContext session) => _sessions[session.Id] = session;

    public void Remove(Guid sessionId) => _sessions.TryRemove(sessionId, out _);
}
