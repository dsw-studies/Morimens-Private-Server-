using System.Text.Json;

namespace Morimens.Server.Networking.Sessions;

public sealed class SessionCaptureWriter : IAsyncDisposable
{
    private readonly string _directory;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private long _sequence;

    public SessionCaptureWriter(string rootDirectory, GameSessionContext session)
    {
        _directory = Path.GetFullPath(Path.Combine(
            rootDirectory,
            $"{session.ConnectedAt:yyyyMMdd_HHmmss_fff}_{session.Id:N}"));
        Directory.CreateDirectory(_directory);
    }

    public string DirectoryPath => _directory;

    public async ValueTask WriteAsync(
        string direction,
        string stage,
        ReadOnlyMemory<byte> payload,
        CancellationToken cancellationToken)
    {
        long sequence = Interlocked.Increment(ref _sequence);
        string fileName = $"{sequence:000000}_{direction}_{stage}_{payload.Length}.bin";
        string filePath = Path.Combine(_directory, fileName);
        string eventsPath = Path.Combine(_directory, "events.jsonl");

        await _gate.WaitAsync(cancellationToken);
        try
        {
            await File.WriteAllBytesAsync(filePath, payload.ToArray(), cancellationToken);
            var entry = new
            {
                sequence,
                timestampUtc = DateTimeOffset.UtcNow,
                direction,
                stage,
                length = payload.Length,
                file = fileName,
                firstBytesHex = Convert.ToHexString(payload.Span[..Math.Min(payload.Length, 64)])
            };
            await File.AppendAllTextAsync(
                eventsPath,
                JsonSerializer.Serialize(entry) + Environment.NewLine,
                cancellationToken);
        }
        finally
        {
            _gate.Release();
        }
    }

    public ValueTask DisposeAsync()
    {
        _gate.Dispose();
        return ValueTask.CompletedTask;
    }
}
