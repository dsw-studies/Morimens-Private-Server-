using System.Net;
using Morimens.Server.Protocol.Crypto;

namespace Morimens.Server.Networking.Sessions;

public sealed class GameSessionContext
{
    public Guid Id { get; } = Guid.NewGuid();
    public DateTimeOffset ConnectedAt { get; } = DateTimeOffset.UtcNow;
    public EndPoint? RemoteEndPoint { get; init; }
    public MorimensClientHandshake? ClientHandshake { get; set; }
    public MorimensSessionKeys? Keys { get; set; }
    public long ReceivedFrames { get; set; }
    public long SentFrames { get; set; }
    public long ReceivedBytes { get; set; }
    public long SentBytes { get; set; }
    public string State { get; set; } = "Connected";

    // Extended economy handlers must stay disabled while the captured RC12.4.16
    // bootstrap is still bringing the client to the main menu.
    public bool InitialGameStreamPrepared { get; set; }
    public bool PostLoginActionsReady { get; set; }
    public int PostLoginHeartbeatCount { get; set; }
    public bool InventorySeedSent { get; set; }
}
