namespace Morimens.Server.Models;

public sealed class ShopPurchase
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid AccountId { get; set; }
    public Account? Account { get; set; }

    public required string OfferId { get; set; }
    public int Quantity { get; set; }
    public long PricePaid { get; set; }
    public required string Currency { get; set; }
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
}
