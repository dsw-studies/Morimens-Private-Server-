using Microsoft.EntityFrameworkCore;

namespace Morimens.Server.Data;

public static class LocalAccountSchema
{
    public static async Task EnsureAsync(GameDbContext db, CancellationToken ct = default)
    {
        await db.Database.EnsureCreatedAsync(ct);

        var connection = db.Database.GetDbConnection();
        await connection.OpenAsync(ct);

        await using var check = connection.CreateCommand();
        check.CommandText = "PRAGMA table_info('Accounts');";

        bool hasLocalUid = false;
        await using (var reader = await check.ExecuteReaderAsync(ct))
        {
            while (await reader.ReadAsync(ct))
            {
                if (string.Equals(reader.GetString(1), "LocalUid", StringComparison.OrdinalIgnoreCase))
                {
                    hasLocalUid = true;
                    break;
                }
            }
        }

        if (!hasLocalUid)
        {
            await using var alter = connection.CreateCommand();
            alter.CommandText = "ALTER TABLE Accounts ADD COLUMN LocalUid INTEGER NOT NULL DEFAULT 0;";
            await alter.ExecuteNonQueryAsync(ct);
        }

        await using (var backfill = connection.CreateCommand())
        {
            backfill.CommandText = """
                UPDATE Accounts
                SET LocalUid = 100000000 + rowid
                WHERE LocalUid IS NULL OR LocalUid = 0;
                """;
            await backfill.ExecuteNonQueryAsync(ct);
        }

        await using (var index = connection.CreateCommand())
        {
            index.CommandText = """
                CREATE UNIQUE INDEX IF NOT EXISTS IX_Accounts_LocalUid
                ON Accounts(LocalUid);
                """;
            await index.ExecuteNonQueryAsync(ct);
        }
    }
}
