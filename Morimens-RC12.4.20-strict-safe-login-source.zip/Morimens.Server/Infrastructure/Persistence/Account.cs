namespace Morimens.Server.Models;

public sealed class Account
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public required string Username { get; set; }
    public required string PasswordHash { get; set; }
    public long LocalUid { get; set; }
    public bool IsBanned { get; set; }
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? LastLoginAt { get; set; }

    public PlayerProfile? Profile { get; set; }
    public List<GameCharacter> Characters { get; set; } = [];
    public List<InventoryItem> Inventory { get; set; } = [];
    public List<GachaPull> GachaPulls { get; set; } = [];
    public List<ShopPurchase> ShopPurchases { get; set; } = [];
}
