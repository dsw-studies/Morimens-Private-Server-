namespace Morimens.Server.Models;

public sealed class GameCharacter
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid AccountId { get; set; }
    public Account? Account { get; set; }

    public int TemplateId { get; set; }
    public int Level { get; set; } = 1;
    public int Rank { get; set; } = 1;
    public int Stars { get; set; } = 1;
    public int Experience { get; set; }
    public int DuplicateFragments { get; set; }
    public bool IsLocked { get; set; }
    public bool IsFavorite { get; set; }
}
