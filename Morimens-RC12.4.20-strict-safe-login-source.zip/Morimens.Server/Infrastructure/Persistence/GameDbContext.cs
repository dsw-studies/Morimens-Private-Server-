using Microsoft.EntityFrameworkCore;
using Morimens.Server.Models;

namespace Morimens.Server.Data;

public sealed class GameDbContext(DbContextOptions<GameDbContext> options) : DbContext(options)
{
    public DbSet<Account> Accounts => Set<Account>();
    public DbSet<PlayerProfile> PlayerProfiles => Set<PlayerProfile>();
    public DbSet<GameCharacter> Characters => Set<GameCharacter>();
    public DbSet<InventoryItem> InventoryItems => Set<InventoryItem>();
    public DbSet<GachaPull> GachaPulls => Set<GachaPull>();
    public DbSet<ShopPurchase> ShopPurchases => Set<ShopPurchase>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Account>()
            .HasIndex(x => x.Username)
            .IsUnique();

        modelBuilder.Entity<Account>()
            .HasIndex(x => x.LocalUid)
            .IsUnique();

        modelBuilder.Entity<Account>()
            .HasOne(x => x.Profile)
            .WithOne(x => x.Account)
            .HasForeignKey<PlayerProfile>(x => x.AccountId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<GameCharacter>()
            .HasIndex(x => new { x.AccountId, x.TemplateId })
            .IsUnique();

        modelBuilder.Entity<InventoryItem>()
            .HasIndex(x => new { x.AccountId, x.ItemId })
            .IsUnique();

        modelBuilder.Entity<GachaPull>()
            .HasIndex(x => new { x.AccountId, x.CreatedAt });

        modelBuilder.Entity<ShopPurchase>()
            .HasIndex(x => new { x.AccountId, x.CreatedAt });
    }
}
