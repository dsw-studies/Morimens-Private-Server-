namespace Morimens.Server.Models;

public sealed class PlayerProfile
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid AccountId { get; set; }
    public Account? Account { get; set; }

    public string DisplayName { get; set; } = "Traveler";
    public int AvatarId { get; set; } = 1001;
    public int Level { get; set; } = 1;
    public long Experience { get; set; }

    // MVP resources shown by the private server.
    public long Gold { get; set; } = 999;
    public long PremiumCurrency { get; set; } = 999;
    public int Stamina { get; set; } = 999;
    public int MaxStamina { get; set; } = 999;
}
