namespace Morimens.Server.Models;

public sealed class GachaPull
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid AccountId { get; set; }
    public Account? Account { get; set; }

    public required string BannerId { get; set; }
    public int CharacterTemplateId { get; set; }
    public int Rarity { get; set; }
    public bool WasDuplicate { get; set; }
    public int DuplicateFragmentsGranted { get; set; }
    public int Cost { get; set; }
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
}
