# Private-server TCP pipeline

The client transport up to the RPC payload is now implemented from observed
runtime captures.

Implemented:

1. 2-byte big-endian framing for the initial handshake.
2. Morimens client-handshake parser.
3. DH64 key agreement (`g=5`, `p=2^64-59`).
4. Four exact `hmac64_md5(sharedSecret, counter)` values for counters `0..3`.
5. 32-byte transport key: `key0 || key1 || key2 || key3`.
6. Standard RC4 transform for post-handshake client traffic.
7. LZ4 frame detection and block decompression.
8. Capture files for ciphertext, RC4 plaintext, and decompressed RPC payload.
9. Per-connection session state and diagnostics.
10. RPC dispatcher boundary ready for the recovered sproto schemas.
11. `/api/tcp/sessions` diagnostic endpoint.

Observed and regression-checked transport:

```text
DH shared secret
-> hmac64_md5 x4
-> concatenate to 32-byte key
-> RC4
-> LZ4 frame
-> sproto/RPC payload
```

Current remaining protocol work:

- identify the exact sconn/RPC envelope fields in the decompressed payload;
- recover `LoginRequest` and `LoginResponse` sproto schemas;
- encode and encrypt the first valid server response;
- implement the minimal post-login RPC set required to reach the main menu.

The old DES candidate analyzer remains in the source tree only for historical
capture comparison. It is not used by the active private-server path.
