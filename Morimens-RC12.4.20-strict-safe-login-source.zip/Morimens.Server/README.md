# Morimens.Server

ASP.NET Core 8 development backend for reverse-engineering a compatible Morimens private server.

## Run

```powershell
dotnet restore
dotnet run
```

Open the URL printed by Kestrel, for example:

- `http://localhost:5158/health`
- `http://localhost:5158/swagger/index.html`

## Current working flow

1. `POST /api/auth/register`
2. Copy the returned JWT.
3. Press **Authorize** in Swagger and paste the token only.
4. Call `GET /api/game/bootstrap`.

## Feature routes

- `/api/auth/*` — registration and login
- `/api/config/*` — version and server status
- `/api/game/bootstrap` — legacy bootstrap route
- `/api/player/*` — player profile
- `/api/inventory/*` — inventory

The old `/api/game/profile/display-name` and `/api/game/inventory/add` routes remain available for backward compatibility.

See [ARCHITECTURE.md](ARCHITECTURE.md) for the project layout and module boundaries.

## Important

The current HTTP/JWT API is an internal development interface. It is not yet compatible with the original Morimens client. Recovered HTTP, TCP and sproto wire formats should be implemented as adapters under `Protocol/` rather than mixed directly into persistence entities.
