using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Morimens.Server.Common.Extensions;
using Morimens.Server.Data;
using Morimens.Server.Dtos;
using Morimens.Server.Models;

namespace Morimens.Server.Features.Inventory;

[ApiController]
[Authorize]
[Route("api/inventory")]
public sealed class InventoryController(GameDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<InventoryItemDto>>> Get(CancellationToken ct)
    {
        if (!User.TryGetAccountId(out var accountId))
            return Unauthorized();

        var items = await db.InventoryItems.AsNoTracking()
            .Where(x => x.AccountId == accountId)
            .OrderBy(x => x.ItemId)
            .Select(x => new InventoryItemDto(x.ItemId, x.Quantity))
            .ToListAsync(ct);
        return Ok(items);
    }

    [HttpPost("grant")]
    public async Task<ActionResult<InventoryItemDto>> Grant(AddItemRequest request, CancellationToken ct)
    {
        if (!User.TryGetAccountId(out var accountId))
            return Unauthorized();
        if (request.ItemId <= 0 || request.Quantity <= 0)
            return BadRequest(new { error = "ItemId and Quantity must be positive." });

        var item = await db.InventoryItems.SingleOrDefaultAsync(
            x => x.AccountId == accountId && x.ItemId == request.ItemId, ct);
        if (item is null)
        {
            item = new InventoryItem { AccountId = accountId, ItemId = request.ItemId, Quantity = request.Quantity };
            db.InventoryItems.Add(item);
        }
        else
        {
            checked { item.Quantity += request.Quantity; }
        }

        await db.SaveChangesAsync(ct);
        return Ok(new InventoryItemDto(item.ItemId, item.Quantity));
    }
}
