namespace Morimens.Server.Services;

public sealed record ActiveLocalAccount(
    Guid AccountId,
    long Uid,
    string Username,
    string DisplayName,
    long Gold,
    long PremiumCurrency,
    int Stamina,
    int MaxStamina,
    DateTimeOffset SelectedAt);

public sealed class ActiveLocalAccountRegistry
{
    private readonly object _gate = new();
    private ActiveLocalAccount? _current;

    public ActiveLocalAccount? Current
    {
        get
        {
            lock (_gate)
                return _current;
        }
    }

    public void Select(Models.Account account)
    {
        ArgumentNullException.ThrowIfNull(account);

        Models.PlayerProfile? profile = account.Profile;

        lock (_gate)
        {
            _current = new ActiveLocalAccount(
                account.Id,
                account.LocalUid,
                account.Username,
                profile?.DisplayName ?? account.Username,
                profile?.Gold ?? 999,
                profile?.PremiumCurrency ?? 999,
                profile?.Stamina ?? 999,
                profile?.MaxStamina ?? 999,
                DateTimeOffset.UtcNow);
        }
    }
}
