using Microsoft.EntityFrameworkCore;
using Morimens.Server.Data;
using Morimens.Server.Features.Economy;
using Morimens.Server.Models;

namespace Morimens.Server.Services;

public sealed class AccountService(GameDbContext db, PasswordService passwords)
{
    private const long MvpGold = 999;
    private const long MvpPremiumCurrency = 999;
    private const int MvpStamina = 999;
    private const int MvpMaxStamina = 999;

    public async Task<Account> RegisterAsync(string username, string password, string? displayName, CancellationToken ct)
    {
        username = username.Trim();
        if (username.Length is < 3 or > 32)
            throw new ArgumentException("Username must be between 3 and 32 characters.");
        if (password.Length < 6)
            throw new ArgumentException("Password must contain at least 6 characters.");
        if (await db.Accounts.AnyAsync(x => x.Username == username, ct))
            throw new InvalidOperationException("Username is already registered.");

        string selectedDisplayName = string.IsNullOrWhiteSpace(displayName) ? username : displayName.Trim();
        if (selectedDisplayName.Length is < 3 or > 14 || selectedDisplayName.Any(ch => ch > 127))
            throw new ArgumentException("Display name must be 3-14 ASCII characters.");

        long nextUid = await AllocateUidAsync(ct);

        var account = new Account
        {
            Username = username,
            LocalUid = nextUid,
            PasswordHash = passwords.Hash(password),
            Profile = new PlayerProfile
            {
                DisplayName = selectedDisplayName,
                Gold = MvpGold,
                PremiumCurrency = MvpPremiumCurrency,
                Stamina = MvpStamina,
                MaxStamina = MvpMaxStamina
            },
            Characters =
            [
                new GameCharacter { TemplateId = 1001, Level = 1, Rank = 1, Stars = 1 }
            ],
            Inventory = CapturedEconomyIds.All
                .Select(itemId => new InventoryItem
                {
                    ItemId = itemId,
                    Quantity = CapturedEconomyIds.SeedQuantity
                })
                .ToList()
        };

        db.Accounts.Add(account);
        await db.SaveChangesAsync(ct);
        return account;
    }

    public async Task<Account> GetOrCreateLocalAsync(string nickname, CancellationToken ct)
    {
        nickname = nickname.Trim();
        if (nickname.Length is < 3 or > 24)
            throw new ArgumentException("Nickname must be between 3 and 24 characters.");

        Account? existing = await db.Accounts
            .Include(x => x.Profile)
            .Include(x => x.Inventory)
            .SingleOrDefaultAsync(x => x.Username == nickname, ct);

        if (existing is not null)
        {
            ApplyMvpResources(existing);
            existing.LastLoginAt = DateTimeOffset.UtcNow;
            await db.SaveChangesAsync(ct);
            return existing;
        }

        return await RegisterAsync(
            nickname,
            Convert.ToHexString(Guid.NewGuid().ToByteArray()),
            nickname,
            ct);
    }

    private async Task<long> AllocateUidAsync(CancellationToken ct)
    {
        const long firstUid = 100_000_001;

        long? currentMax = await db.Accounts
            .Select(x => (long?)x.LocalUid)
            .MaxAsync(ct);

        return currentMax is null or < firstUid
            ? firstUid
            : checked(currentMax.Value + 1);
    }

    public async Task<Account?> ValidateAsync(string username, string password, string? displayName, CancellationToken ct)
    {
        Account? account = await db.Accounts
            .Include(x => x.Profile)
            .Include(x => x.Inventory)
            .SingleOrDefaultAsync(x => x.Username == username.Trim(), ct);

        if (account is null || !passwords.Verify(password, account.PasswordHash))
            return null;

        ApplyMvpResources(account);
        if (!string.IsNullOrWhiteSpace(displayName))
        {
            string selectedDisplayName = displayName.Trim();
            if (selectedDisplayName.Length is < 3 or > 14 || selectedDisplayName.Any(ch => ch > 127))
                throw new ArgumentException("Display name must be 3-14 ASCII characters.");
            account.Profile!.DisplayName = selectedDisplayName;
        }
        account.LastLoginAt = DateTimeOffset.UtcNow;
        await db.SaveChangesAsync(ct);
        return account;
    }

    private static void ApplyMvpResources(Account account)
    {
        account.Profile ??= new PlayerProfile
        {
            AccountId = account.Id,
            DisplayName = account.Username
        };

        account.Profile.Gold = MvpGold;
        account.Profile.PremiumCurrency = MvpPremiumCurrency;
        account.Profile.Stamina = MvpStamina;
        account.Profile.MaxStamina = MvpMaxStamina;

        foreach (int itemId in CapturedEconomyIds.All)
        {
            SetInventoryQuantity(
                account,
                itemId,
                CapturedEconomyIds.SeedQuantity);
        }
    }

    private static void SetInventoryQuantity(Account account, int itemId, long quantity)
    {
        InventoryItem? item = account.Inventory.FirstOrDefault(x => x.ItemId == itemId);
        if (item is null)
        {
            account.Inventory.Add(new InventoryItem
            {
                AccountId = account.Id,
                ItemId = itemId,
                Quantity = quantity
            });
            return;
        }

        item.Quantity = quantity;
    }
}
