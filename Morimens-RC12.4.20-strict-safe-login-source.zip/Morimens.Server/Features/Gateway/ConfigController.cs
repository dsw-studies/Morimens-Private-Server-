using Microsoft.AspNetCore.Mvc;

namespace Morimens.Server.Controllers;

[ApiController]
[Route("api/config")]
public sealed class ConfigController(IConfiguration configuration) : ControllerBase
{
    [HttpGet("version")]
    public IActionResult Version() => Ok(new
    {
        serverVersion = configuration["Server:Version"],
        region = configuration["Server:Region"],
        maintenance = configuration.GetValue<bool>("Server:Maintenance"),
        minimumClientVersion = "0.0.0",
        assets = new { baseUrl = "http://localhost:5000/assets/" }
    });
}
