using Microsoft.AspNetCore.Mvc;
using Morimens.Server.Dtos;
using Morimens.Server.Models;
using Morimens.Server.Services;

namespace Morimens.Server.Controllers;

[ApiController]
[Route("api/auth")]
public sealed class AuthController(
    AccountService accounts,
    TokenService tokens,
    ActiveLocalAccountRegistry activeAccounts) : ControllerBase
{
    [HttpPost("register")]
    public async Task<ActionResult<AuthResponse>> Register(
        RegisterRequest request,
        CancellationToken ct)
    {
        try
        {
            Account account = await accounts.RegisterAsync(
                request.Username,
                request.Password,
                request.DisplayName,
                ct);

            activeAccounts.Select(account);
            var token = tokens.Create(account);
            return Ok(ToResponse(account, token));
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(new { error = ex.Message });
        }
    }

    [HttpPost("login")]
    public async Task<ActionResult<AuthResponse>> Login(
        LoginRequest request,
        CancellationToken ct)
    {
        Account? account = await accounts.ValidateAsync(
            request.Username,
            request.Password,
            request.DisplayName,
            ct);

        if (account is null)
            return Unauthorized(new { error = "Invalid username or password." });

        activeAccounts.Select(account);
        var token = tokens.Create(account);
        return Ok(ToResponse(account, token));
    }

    private static AuthResponse ToResponse(
        Account account,
        (string Token, DateTimeOffset ExpiresAt) token) =>
        new(
            token.Token,
            token.ExpiresAt,
            new AccountDto(
                account.Id,
                account.LocalUid,
                account.Username,
                account.Profile?.DisplayName ?? account.Username,
                account.Profile?.Level ?? 1));
}
