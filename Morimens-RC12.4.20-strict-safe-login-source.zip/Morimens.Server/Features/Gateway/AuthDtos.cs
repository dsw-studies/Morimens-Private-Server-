namespace Morimens.Server.Dtos;

public sealed record RegisterRequest(string Username, string Password, string? DisplayName);
public sealed record LoginRequest(string Username, string Password, string? DisplayName);
public sealed record LocalLoginRequest(string Nickname);
public sealed record AuthResponse(string Token, DateTimeOffset ExpiresAt, AccountDto Account);
public sealed record AccountDto(Guid Id, long Uid, string Username, string DisplayName, int Level);
