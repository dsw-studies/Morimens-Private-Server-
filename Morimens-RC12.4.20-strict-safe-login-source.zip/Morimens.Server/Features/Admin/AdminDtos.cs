namespace Morimens.Server.Features.Admin;

public sealed record CreatePlayerRequest(
    string Username,
    string Password,
    string? DisplayName);

public sealed record UpdateProfileRequest(
    string? DisplayName,
    int? AvatarId,
    int? Level,
    long? Experience,
    long? Gold,
    long? PremiumCurrency,
    int? Stamina,
    int? MaxStamina,
    bool? IsBanned);

public sealed record ChangeItemRequest(
    int ItemId,
    long Delta);

public sealed record GrantHeroRequest(
    int TemplateId,
    int Level = 1,
    int Rank = 1,
    int Stars = 1);

public sealed record UpdateHeroRequest(
    int? Level,
    int? Rank,
    int? Stars,
    int? Experience,
    int? DuplicateFragments,
    bool? IsLocked,
    bool? IsFavorite);

public sealed record GachaPullRequest(
    string BannerId,
    int Count);

public sealed record ShopPurchaseRequest(
    string OfferId,
    int Quantity);
