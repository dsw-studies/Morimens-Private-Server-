using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Morimens.Server.Data;
using Morimens.Server.Features.Economy;
using Morimens.Server.Services;

namespace Morimens.Server.Features.Admin;

[ApiController]
[Route("api/admin")]
[AdminApiKey]
public sealed class AdminController(
    GameDbContext db,
    AccountService accounts,
    GameEconomyService economy,
    EconomyCatalog catalog) : ControllerBase
{
    [HttpGet("overview")]
    public async Task<IActionResult> Overview(CancellationToken ct)
    {
        return Ok(new
        {
            players = await db.Accounts.CountAsync(ct),
            heroes = await db.Characters.CountAsync(ct),
            inventoryRows = await db.InventoryItems.CountAsync(ct),
            gachaPulls = await db.GachaPulls.CountAsync(ct),
            purchases = await db.ShopPurchases.CountAsync(ct)
        });
    }

    [HttpGet("players")]
    public async Task<IActionResult> Players(CancellationToken ct)
    {
        var players = await db.Accounts
            .Include(x => x.Profile)
            .OrderBy(x => x.Username)
            .Select(x => new
            {
                x.Id,
                x.Username,
                x.IsBanned,
                x.CreatedAt,
                x.LastLoginAt,
                profile = x.Profile == null ? null : new
                {
                    x.Profile.DisplayName,
                    x.Profile.AvatarId,
                    x.Profile.Level,
                    x.Profile.Experience,
                    x.Profile.Gold,
                    x.Profile.PremiumCurrency,
                    x.Profile.Stamina,
                    x.Profile.MaxStamina
                }
            })
            .ToListAsync(ct);

        return Ok(players);
    }

    [HttpPost("players")]
    public async Task<IActionResult> CreatePlayer(
        CreatePlayerRequest request,
        CancellationToken ct)
    {
        var account = await accounts.RegisterAsync(
            request.Username,
            request.Password,
            request.DisplayName,
            ct);

        return Created($"/api/admin/players/{account.Id}", new
        {
            account.Id,
            account.Username
        });
    }

    [HttpGet("players/{accountId:guid}")]
    public async Task<IActionResult> Player(Guid accountId, CancellationToken ct)
    {
        var player = await db.Accounts
            .Include(x => x.Profile)
            .Include(x => x.Characters)
            .Include(x => x.Inventory)
            .SingleOrDefaultAsync(x => x.Id == accountId, ct);

        return player is null
            ? NotFound()
            : Ok(new
            {
                player.Id,
                player.Username,
                player.IsBanned,
                player.CreatedAt,
                player.LastLoginAt,
                player.Profile,
                heroes = player.Characters.OrderBy(x => x.TemplateId),
                inventory = player.Inventory.OrderBy(x => x.ItemId)
            });
    }

    [HttpPatch("players/{accountId:guid}/profile")]
    public async Task<IActionResult> UpdateProfile(
        Guid accountId,
        UpdateProfileRequest request,
        CancellationToken ct)
    {
        var account = await db.Accounts
            .Include(x => x.Profile)
            .SingleOrDefaultAsync(x => x.Id == accountId, ct);

        if (account?.Profile is null) return NotFound();

        if (request.DisplayName is not null)
            account.Profile.DisplayName = request.DisplayName.Trim();
        if (request.AvatarId is int avatarId)
            account.Profile.AvatarId = avatarId;
        if (request.Level is int level)
            account.Profile.Level = Math.Max(1, level);
        if (request.Experience is long experience)
            account.Profile.Experience = Math.Max(0, experience);
        if (request.Gold is long gold)
            account.Profile.Gold = Math.Max(0, gold);
        if (request.PremiumCurrency is long premium)
            account.Profile.PremiumCurrency = Math.Max(0, premium);
        if (request.Stamina is int stamina)
            account.Profile.Stamina = Math.Max(0, stamina);
        if (request.MaxStamina is int maxStamina)
            account.Profile.MaxStamina = Math.Max(1, maxStamina);
        if (request.IsBanned is bool banned)
            account.IsBanned = banned;

        await db.SaveChangesAsync(ct);
        return Ok(account.Profile);
    }

    [HttpPost("players/{accountId:guid}/inventory")]
    public async Task<IActionResult> ChangeInventory(
        Guid accountId,
        ChangeItemRequest request,
        CancellationToken ct)
    {
        if (!await db.Accounts.AnyAsync(x => x.Id == accountId, ct))
            return NotFound();

        try
        {
            return Ok(await economy.AddItemAsync(
                accountId,
                request.ItemId,
                request.Delta,
                ct));
        }
        catch (InvalidOperationException error)
        {
            return BadRequest(new { error = error.Message });
        }
    }

    [HttpPost("players/{accountId:guid}/heroes")]
    public async Task<IActionResult> GrantHero(
        Guid accountId,
        GrantHeroRequest request,
        CancellationToken ct)
    {
        if (!await db.Accounts.AnyAsync(x => x.Id == accountId, ct))
            return NotFound();

        try
        {
            return Ok(await economy.GrantHeroAsync(
                accountId,
                request.TemplateId,
                request.Level,
                request.Rank,
                request.Stars,
                ct));
        }
        catch (KeyNotFoundException error)
        {
            return BadRequest(new { error = error.Message });
        }
    }

    [HttpPatch("players/{accountId:guid}/heroes/{templateId:int}")]
    public async Task<IActionResult> UpdateHero(
        Guid accountId,
        int templateId,
        UpdateHeroRequest request,
        CancellationToken ct)
    {
        var hero = await db.Characters.SingleOrDefaultAsync(
            x => x.AccountId == accountId && x.TemplateId == templateId,
            ct);

        if (hero is null) return NotFound();

        if (request.Level is int level) hero.Level = Math.Max(1, level);
        if (request.Rank is int rank) hero.Rank = Math.Max(1, rank);
        if (request.Stars is int stars) hero.Stars = Math.Max(1, stars);
        if (request.Experience is int experience) hero.Experience = Math.Max(0, experience);
        if (request.DuplicateFragments is int fragments)
            hero.DuplicateFragments = Math.Max(0, fragments);
        if (request.IsLocked is bool locked) hero.IsLocked = locked;
        if (request.IsFavorite is bool favorite) hero.IsFavorite = favorite;

        await db.SaveChangesAsync(ct);
        return Ok(hero);
    }

    [HttpGet("catalog")]
    public IActionResult Catalog() => Ok(new
    {
        catalog.Heroes,
        catalog.ShopOffers,
        catalog.Banners
    });

    [HttpPost("players/{accountId:guid}/gacha")]
    public async Task<IActionResult> Gacha(
        Guid accountId,
        GachaPullRequest request,
        CancellationToken ct)
    {
        try
        {
            var results = await economy.PullAsync(
                accountId,
                request.BannerId,
                request.Count,
                ct);

            return Ok(results);
        }
        catch (Exception error) when (
            error is InvalidOperationException
                or ArgumentException
                or KeyNotFoundException)
        {
            return BadRequest(new { error = error.Message });
        }
    }

    [HttpPost("players/{accountId:guid}/shop")]
    public async Task<IActionResult> Purchase(
        Guid accountId,
        ShopPurchaseRequest request,
        CancellationToken ct)
    {
        try
        {
            await economy.PurchaseAsync(
                accountId,
                request.OfferId,
                request.Quantity,
                ct);

            return Ok(new { ok = true });
        }
        catch (Exception error) when (
            error is InvalidOperationException
                or ArgumentException
                or KeyNotFoundException)
        {
            return BadRequest(new { error = error.Message });
        }
    }

    [HttpGet("players/{accountId:guid}/gacha-history")]
    public async Task<IActionResult> GachaHistory(Guid accountId, CancellationToken ct) =>
        Ok(await db.GachaPulls
            .Where(x => x.AccountId == accountId)
            .OrderByDescending(x => x.CreatedAt)
            .Take(200)
            .ToListAsync(ct));

    [HttpGet("players/{accountId:guid}/purchase-history")]
    public async Task<IActionResult> PurchaseHistory(Guid accountId, CancellationToken ct) =>
        Ok(await db.ShopPurchases
            .Where(x => x.AccountId == accountId)
            .OrderByDescending(x => x.CreatedAt)
            .Take(200)
            .ToListAsync(ct));
}
