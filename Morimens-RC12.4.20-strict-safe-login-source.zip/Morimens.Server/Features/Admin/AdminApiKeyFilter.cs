using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Morimens.Server.Features.Admin;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public sealed class AdminApiKeyAttribute : Attribute, IAsyncActionFilter
{
    public async Task OnActionExecutionAsync(
        ActionExecutingContext context,
        ActionExecutionDelegate next)
    {
        var configuration = context.HttpContext.RequestServices
            .GetRequiredService<IConfiguration>();

        var expected = configuration["Admin:ApiKey"];
        var provided = context.HttpContext.Request.Headers["X-Admin-Key"].FirstOrDefault();

        if (string.IsNullOrWhiteSpace(expected)
            || !string.Equals(expected, provided, StringComparison.Ordinal))
        {
            context.Result = new UnauthorizedObjectResult(new
            {
                error = "Invalid admin key."
            });
            return;
        }

        await next();
    }
}
