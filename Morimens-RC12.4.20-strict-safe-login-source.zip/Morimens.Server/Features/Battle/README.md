# Battle module

Reserved for stage validation, formations, battle start tickets, battle result verification, stamina spending, drops and rewards.
