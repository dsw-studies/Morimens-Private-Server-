# Economy module

Reserved for currencies, shop, gacha, mail rewards, exchanges and transaction ledger.
