namespace Morimens.Server.Features.Economy;

public sealed record HeroDefinition(
    int TemplateId,
    string Name,
    int Rarity,
    int Weight);

public sealed record ShopOfferDefinition(
    string OfferId,
    string Name,
    string Currency,
    long Price,
    int ItemId,
    long ItemQuantity,
    int? CharacterTemplateId);

public sealed record GachaBannerDefinition(
    string BannerId,
    string Name,
    int SingleCost,
    int TenCost,
    int PityThreshold);

public sealed class EconomyCatalog
{
    public IReadOnlyList<HeroDefinition> Heroes { get; } =
    [
        new(1001, "Starter", 3, 4200),
        new(1002, "Night Scholar", 3, 3000),
        new(1003, "Ash Knight", 4, 1400),
        new(1004, "Moon Oracle", 4, 900),
        new(1005, "Abyss Queen", 5, 450),
        new(1006, "Golden Witness", 5, 50),
        new(145294, "Lotan: Cetarchon (Genesis)", 5, 1)
    ];

    public IReadOnlyList<GachaBannerDefinition> Banners { get; } =
    [
        new("standard", "Standard Invocation", 160, 1_600, 80),
        new("145237", "Genesis Lotan", 160, 800, 80)
    ];

    public IReadOnlyList<ShopOfferDefinition> ShopOffers { get; } =
    [
        new("gold-small", "10 000 Gold", "premium", 100, 1, 10_000, null),
        new("gold-large", "100 000 Gold", "premium", 800, 1, 100_000, null),
        new("stamina-pack", "Stamina Pack", "premium", 50, 3, 1, null),
        new("starter-hero", "Starter Hero", "gold", 25_000, 0, 0, 1001)
    ];

    public HeroDefinition RequireHero(int templateId) =>
        Heroes.FirstOrDefault(x => x.TemplateId == templateId)
        ?? throw new KeyNotFoundException($"Hero template {templateId} not found.");

    public ShopOfferDefinition RequireOffer(string offerId) =>
        ShopOffers.FirstOrDefault(x => x.OfferId.Equals(offerId, StringComparison.OrdinalIgnoreCase))
        ?? throw new KeyNotFoundException($"Shop offer '{offerId}' not found.");

    public GachaBannerDefinition RequireBanner(string bannerId) =>
        Banners.FirstOrDefault(x => x.BannerId.Equals(bannerId, StringComparison.OrdinalIgnoreCase))
        ?? throw new KeyNotFoundException($"Gacha banner '{bannerId}' not found.");
}
