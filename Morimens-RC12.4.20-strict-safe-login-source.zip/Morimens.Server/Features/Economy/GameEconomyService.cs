using Microsoft.EntityFrameworkCore;
using Morimens.Server.Data;
using Morimens.Server.Models;

namespace Morimens.Server.Features.Economy;

public sealed record GachaResult(
    int CharacterTemplateId,
    string CharacterName,
    int Rarity,
    bool WasDuplicate,
    int DuplicateFragments);

public sealed class GameEconomyService(
    GameDbContext db,
    EconomyCatalog catalog)
{
    public async Task<InventoryItem> AddItemAsync(
        Guid accountId,
        int itemId,
        long delta,
        CancellationToken ct)
    {
        if (delta == 0)
            throw new ArgumentException("Delta cannot be zero.");

        var item = await db.InventoryItems
            .SingleOrDefaultAsync(x => x.AccountId == accountId && x.ItemId == itemId, ct);

        if (item is null)
        {
            if (delta < 0)
                throw new InvalidOperationException("Not enough items.");

            item = new InventoryItem
            {
                AccountId = accountId,
                ItemId = itemId,
                Quantity = delta
            };
            db.InventoryItems.Add(item);
        }
        else
        {
            if (item.Quantity + delta < 0)
                throw new InvalidOperationException("Not enough items.");

            item.Quantity += delta;
            item.UpdatedAt = DateTimeOffset.UtcNow;
        }

        await db.SaveChangesAsync(ct);
        return item;
    }

    public async Task<GameCharacter> GrantHeroAsync(
        Guid accountId,
        int templateId,
        int level,
        int rank,
        int stars,
        CancellationToken ct)
    {
        catalog.RequireHero(templateId);

        var hero = await db.Characters
            .SingleOrDefaultAsync(x => x.AccountId == accountId && x.TemplateId == templateId, ct);

        if (hero is null)
        {
            hero = new GameCharacter
            {
                AccountId = accountId,
                TemplateId = templateId,
                Level = Math.Max(1, level),
                Rank = Math.Max(1, rank),
                Stars = Math.Max(1, stars)
            };
            db.Characters.Add(hero);
        }
        else
        {
            hero.Level = Math.Max(hero.Level, level);
            hero.Rank = Math.Max(hero.Rank, rank);
            hero.Stars = Math.Max(hero.Stars, stars);
        }

        await db.SaveChangesAsync(ct);
        return hero;
    }

    public async Task<IReadOnlyList<GachaResult>> PullAsync(
        Guid accountId,
        string bannerId,
        int count,
        CancellationToken ct)
    {
        if (count is not (1 or 5 or 10))
            throw new ArgumentException("Only 1, 5 or 10 pulls are supported.");

        var banner = catalog.RequireBanner(bannerId);
        var account = await db.Accounts
            .Include(x => x.Profile)
            .Include(x => x.Characters)
            .SingleAsync(x => x.Id == accountId, ct);

        var cost = count switch
        {
            10 => banner.TenCost,
            5 => checked(banner.SingleCost * 5),
            _ => banner.SingleCost
        };
        if (account.Profile is null || account.Profile.PremiumCurrency < cost)
            throw new InvalidOperationException("Not enough premium currency.");

        account.Profile.PremiumCurrency -= cost;

        var pullsSinceFiveStar = await db.GachaPulls
            .Where(x => x.AccountId == accountId && x.BannerId == bannerId)
            .OrderByDescending(x => x.CreatedAt)
            .Take(banner.PityThreshold)
            .ToListAsync(ct);

        var consecutiveNonFive = 0;
        foreach (var pull in pullsSinceFiveStar)
        {
            if (pull.Rarity >= 5) break;
            consecutiveNonFive++;
        }

        var results = new List<GachaResult>(count);

        for (var index = 0; index < count; index++)
        {
            var forceFive = consecutiveNonFive + 1 >= banner.PityThreshold;
            var hero = banner.BannerId.Equals("145237", StringComparison.OrdinalIgnoreCase)
                ? catalog.RequireHero(145294)
                : RollHero(forceFive);

            var owned = account.Characters
                .FirstOrDefault(x => x.TemplateId == hero.TemplateId);

            var duplicate = owned is not null;
            var fragments = duplicate ? hero.Rarity * 10 : 0;

            if (owned is null)
            {
                owned = new GameCharacter
                {
                    AccountId = accountId,
                    TemplateId = hero.TemplateId,
                    Level = 1,
                    Rank = 1,
                    Stars = hero.Rarity >= 5 ? 3 : 1
                };
                account.Characters.Add(owned);
            }
            else
            {
                owned.DuplicateFragments += fragments;
            }

            db.GachaPulls.Add(new GachaPull
            {
                AccountId = accountId,
                BannerId = banner.BannerId,
                CharacterTemplateId = hero.TemplateId,
                Rarity = hero.Rarity,
                WasDuplicate = duplicate,
                DuplicateFragmentsGranted = fragments,
                Cost = index == 0 ? cost : 0
            });

            results.Add(new GachaResult(
                hero.TemplateId,
                hero.Name,
                hero.Rarity,
                duplicate,
                fragments));

            consecutiveNonFive = hero.Rarity >= 5 ? 0 : consecutiveNonFive + 1;
        }

        await db.SaveChangesAsync(ct);
        return results;
    }

    public async Task PurchaseAsync(
        Guid accountId,
        string offerId,
        int quantity,
        CancellationToken ct)
    {
        if (quantity is < 1 or > 99)
            throw new ArgumentOutOfRangeException(nameof(quantity));

        var offer = catalog.RequireOffer(offerId);
        var account = await db.Accounts
            .Include(x => x.Profile)
            .Include(x => x.Inventory)
            .Include(x => x.Characters)
            .SingleAsync(x => x.Id == accountId, ct);

        if (account.Profile is null)
            throw new InvalidOperationException("Profile is missing.");

        var total = checked(offer.Price * quantity);
        switch (offer.Currency.ToLowerInvariant())
        {
            case "gold":
                if (account.Profile.Gold < total)
                    throw new InvalidOperationException("Not enough gold.");
                account.Profile.Gold -= total;
                break;

            case "premium":
                if (account.Profile.PremiumCurrency < total)
                    throw new InvalidOperationException("Not enough premium currency.");
                account.Profile.PremiumCurrency -= total;
                break;

            default:
                throw new InvalidOperationException("Unsupported shop currency.");
        }

        if (offer.CharacterTemplateId is int heroId)
        {
            var hero = account.Characters.FirstOrDefault(x => x.TemplateId == heroId);
            if (hero is null)
            {
                account.Characters.Add(new GameCharacter
                {
                    AccountId = accountId,
                    TemplateId = heroId
                });
            }
            else
            {
                hero.DuplicateFragments += 10 * quantity;
            }
        }
        else
        {
            var item = account.Inventory.FirstOrDefault(x => x.ItemId == offer.ItemId);
            if (item is null)
            {
                account.Inventory.Add(new InventoryItem
                {
                    AccountId = accountId,
                    ItemId = offer.ItemId,
                    Quantity = offer.ItemQuantity * quantity
                });
            }
            else
            {
                item.Quantity += offer.ItemQuantity * quantity;
                item.UpdatedAt = DateTimeOffset.UtcNow;
            }
        }

        db.ShopPurchases.Add(new ShopPurchase
        {
            AccountId = accountId,
            OfferId = offer.OfferId,
            Quantity = quantity,
            PricePaid = total,
            Currency = offer.Currency
        });

        await db.SaveChangesAsync(ct);
    }

    private HeroDefinition RollHero(bool forceFive)
    {
        var candidates = forceFive
            ? catalog.Heroes.Where(x => x.Rarity >= 5).ToArray()
            : catalog.Heroes.ToArray();

        var totalWeight = candidates.Sum(x => x.Weight);
        var roll = Random.Shared.Next(1, totalWeight + 1);

        foreach (var hero in candidates)
        {
            roll -= hero.Weight;
            if (roll <= 0) return hero;
        }

        return candidates[^1];
    }
}
