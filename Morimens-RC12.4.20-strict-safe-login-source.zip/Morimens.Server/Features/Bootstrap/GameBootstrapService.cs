using Microsoft.EntityFrameworkCore;
using Morimens.Server.Data;
using Morimens.Server.Dtos;

namespace Morimens.Server.Services;

public sealed class GameBootstrapService(GameDbContext db, IConfiguration configuration)
{
    public async Task<BootstrapResponse?> GetAsync(Guid accountId, CancellationToken ct)
    {
        var account = await db.Accounts
            .AsNoTracking()
            .Include(x => x.Profile)
            .Include(x => x.Characters)
            .Include(x => x.Inventory)
            .SingleOrDefaultAsync(x => x.Id == accountId, ct);

        if (account?.Profile is null)
            return null;

        return new BootstrapResponse(
            new ProfileDto(account.Id, account.Profile.DisplayName, account.Profile.Level,
                account.Profile.Experience, account.Profile.Gold, account.Profile.PremiumCurrency,
                account.Profile.Stamina, account.Profile.MaxStamina),
            account.Characters.Select(x => new CharacterDto(x.Id, x.TemplateId, x.Level, x.Rank, x.Experience, x.IsLocked)).ToList(),
            account.Inventory.Select(x => new InventoryItemDto(x.ItemId, x.Quantity)).ToList(),
            new
            {
                region = configuration["Server:Region"],
                version = configuration["Server:Version"],
                maintenance = configuration.GetValue<bool>("Server:Maintenance"),
                utc = DateTimeOffset.UtcNow
            });
    }
}
