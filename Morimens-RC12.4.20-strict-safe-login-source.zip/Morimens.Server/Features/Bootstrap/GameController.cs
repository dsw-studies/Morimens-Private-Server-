using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Morimens.Server.Data;
using Morimens.Server.Dtos;
using Morimens.Server.Models;
using Morimens.Server.Services;

namespace Morimens.Server.Controllers;

[ApiController]
[Authorize]
[Route("api/game")]
public sealed class GameController(GameDbContext db, GameBootstrapService bootstrap) : ControllerBase
{
    [HttpGet("bootstrap")]
    public async Task<ActionResult<BootstrapResponse>> Bootstrap(CancellationToken ct)
    {
        if (!TryGetAccountId(out var accountId))
            return Unauthorized();

        var result = await bootstrap.GetAsync(accountId, ct);
        return result is null ? NotFound() : Ok(result);
    }

    [HttpPatch("profile/display-name")]
    public async Task<IActionResult> UpdateDisplayName(UpdateDisplayNameRequest request, CancellationToken ct)
    {
        if (!TryGetAccountId(out var accountId))
            return Unauthorized();
        if (string.IsNullOrWhiteSpace(request.DisplayName) || request.DisplayName.Length > 24)
            return BadRequest(new { error = "Display name must contain 1-24 characters." });

        var profile = await db.PlayerProfiles.SingleOrDefaultAsync(x => x.AccountId == accountId, ct);
        if (profile is null)
            return NotFound();

        profile.DisplayName = request.DisplayName.Trim();
        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    [HttpPost("inventory/add")]
    public async Task<ActionResult<InventoryItemDto>> AddItem(AddItemRequest request, CancellationToken ct)
    {
        if (!TryGetAccountId(out var accountId))
            return Unauthorized();
        if (request.ItemId <= 0 || request.Quantity <= 0)
            return BadRequest(new { error = "ItemId and Quantity must be positive." });

        var item = await db.InventoryItems.SingleOrDefaultAsync(
            x => x.AccountId == accountId && x.ItemId == request.ItemId, ct);

        if (item is null)
        {
            item = new InventoryItem { AccountId = accountId, ItemId = request.ItemId, Quantity = request.Quantity };
            db.InventoryItems.Add(item);
        }
        else
        {
            checked { item.Quantity += request.Quantity; }
        }

        await db.SaveChangesAsync(ct);
        return Ok(new InventoryItemDto(item.ItemId, item.Quantity));
    }

    private bool TryGetAccountId(out Guid accountId)
    {
        var value = User.FindFirstValue(ClaimTypes.NameIdentifier)
                    ?? User.FindFirstValue("sub");
        return Guid.TryParse(value, out accountId);
    }
}
