namespace Morimens.Server.Dtos;

public sealed record ProfileDto(
    Guid AccountId,
    string DisplayName,
    int Level,
    long Experience,
    long Gold,
    long PremiumCurrency,
    int Stamina,
    int MaxStamina);

public sealed record CharacterDto(Guid Id, int TemplateId, int Level, int Rank, int Experience, bool IsLocked);
public sealed record InventoryItemDto(int ItemId, long Quantity);
public sealed record BootstrapResponse(ProfileDto Profile, IReadOnlyList<CharacterDto> Characters, IReadOnlyList<InventoryItemDto> Inventory, object Server);
public sealed record UpdateDisplayNameRequest(string DisplayName);
public sealed record AddItemRequest(int ItemId, long Quantity);
