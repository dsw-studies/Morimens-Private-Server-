using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Morimens.Server.Common.Extensions;
using Morimens.Server.Data;
using Morimens.Server.Dtos;

namespace Morimens.Server.Features.Player;

[ApiController]
[Authorize]
[Route("api/player")]
public sealed class PlayerController(GameDbContext db) : ControllerBase
{
    [HttpGet("profile")]
    public async Task<ActionResult<ProfileDto>> GetProfile(CancellationToken ct)
    {
        if (!User.TryGetAccountId(out var accountId))
            return Unauthorized();

        var profile = await db.PlayerProfiles.AsNoTracking()
            .SingleOrDefaultAsync(x => x.AccountId == accountId, ct);
        if (profile is null)
            return NotFound();

        return Ok(new ProfileDto(profile.AccountId, profile.DisplayName, profile.Level,
            profile.Experience, profile.Gold, profile.PremiumCurrency,
            profile.Stamina, profile.MaxStamina));
    }

    [HttpPatch("display-name")]
    public async Task<IActionResult> UpdateDisplayName(UpdateDisplayNameRequest request, CancellationToken ct)
    {
        if (!User.TryGetAccountId(out var accountId))
            return Unauthorized();
        if (string.IsNullOrWhiteSpace(request.DisplayName) || request.DisplayName.Trim().Length > 24)
            return BadRequest(new { error = "Display name must contain 1-24 characters." });

        var profile = await db.PlayerProfiles.SingleOrDefaultAsync(x => x.AccountId == accountId, ct);
        if (profile is null)
            return NotFound();

        profile.DisplayName = request.DisplayName.Trim();
        await db.SaveChangesAsync(ct);
        return NoContent();
    }
}
