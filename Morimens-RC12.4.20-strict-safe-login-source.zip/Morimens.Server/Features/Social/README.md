# Social module

Reserved for friends, guilds, chat, rankings and presence.
