using System.Text.Json;

namespace Morimens.Server.GameConfig;

public sealed class GameConfigCatalog(IWebHostEnvironment environment)
{
    private readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web);

    public async Task<IReadOnlyList<T>> LoadAsync<T>(string fileName, CancellationToken ct = default)
    {
        var path = Path.Combine(environment.ContentRootPath, "GameConfig", "Data", fileName);
        await using var stream = File.OpenRead(path);
        return await JsonSerializer.DeserializeAsync<List<T>>(stream, _json, ct) ?? [];
    }
}
