# Morimens.Server architecture

```text
Morimens.Server/
├── Common/                    Shared helpers without game rules
├── Features/
│   ├── Gateway/               Registration, login, version, sessions
│   ├── Bootstrap/             Initial player-state response
│   ├── Player/                Profile and account progression
│   ├── Inventory/             Items and grants
│   ├── Battle/                Battle lifecycle (planned)
│   ├── Economy/               Shop/gacha/currencies (planned)
│   └── Social/                Friends/guild/chat (planned)
├── GameConfig/                Static balance/configuration data
├── Infrastructure/
│   ├── Persistence/           EF Core context and entities
│   └── Security/              Password hashing and JWT
└── Protocol/
    ├── Http/                   Original-client HTTP adapters
    ├── Sproto/                Sproto schemas and codec
    └── Tcp/                   Socket transport and packet dispatch
```

## Dependency rule

Protocol and controllers call feature services. Feature services may use persistence and configuration. Infrastructure must not contain gameplay rules.

## Compatibility rule

Do not shape the database around unknown client packets. Translate recovered client DTOs in `Protocol/*` into stable internal feature commands.
