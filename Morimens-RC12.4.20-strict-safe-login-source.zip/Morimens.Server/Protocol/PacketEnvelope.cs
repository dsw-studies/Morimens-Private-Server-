namespace Morimens.Server.Protocol;

// Placeholder for the future Morimens TCP/sproto transport.
public sealed record PacketEnvelope(int Session, int ProtocolId, ReadOnlyMemory<byte> Payload);

public interface IGamePacketCodec
{
    PacketEnvelope Decode(ReadOnlyMemory<byte> packet);
    byte[] Encode(PacketEnvelope packet);
}
