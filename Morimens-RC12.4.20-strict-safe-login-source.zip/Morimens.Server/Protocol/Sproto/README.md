# Sproto transport

Add recovered `.sproto` schemas, protocol IDs, request/response codecs and session correlation here.
