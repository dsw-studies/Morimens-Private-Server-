namespace Morimens.Server.Protocol.Sproto;

/// <summary>
/// Encoder/decoder for the sparse eight-byte packing used by the Morimens
/// sproto transport. A 0xFF block stores a run of completely non-zero chunks;
/// every other header is a bit mask followed by the non-zero bytes.
/// </summary>
public static class SprotoPackCodec
{
    public static byte[] Pack(ReadOnlySpan<byte> source)
    {
        using var output = new MemoryStream(source.Length + source.Length / 8 + 16);
        int offset = 0;

        while (offset < source.Length)
        {
            Span<byte> chunk = stackalloc byte[8];
            int available = Math.Min(8, source.Length - offset);
            source.Slice(offset, available).CopyTo(chunk);

            byte mask = BuildMask(chunk);
            if (mask == 0xFF)
            {
                int runChunks = 1;
                while (runChunks < 256)
                {
                    int nextOffset = offset + runChunks * 8;
                    if (nextOffset + 8 > source.Length ||
                        BuildMask(source.Slice(nextOffset, 8)) != 0xFF)
                    {
                        break;
                    }

                    runChunks++;
                }

                output.WriteByte(0xFF);
                output.WriteByte(checked((byte)(runChunks - 1)));
                output.Write(source.Slice(offset, runChunks * 8));
                offset += runChunks * 8;
                continue;
            }

            output.WriteByte(mask);
            for (int index = 0; index < 8; index++)
            {
                if ((mask & (1 << index)) != 0)
                    output.WriteByte(chunk[index]);
            }

            offset += available;
        }

        return output.ToArray();
    }

    public static byte[] Unpack(ReadOnlySpan<byte> packed)
    {
        using var output = new MemoryStream(Math.Max(packed.Length, 64));
        int offset = 0;

        while (offset < packed.Length)
        {
            byte header = packed[offset++];
            if (header == 0xFF)
            {
                if (offset >= packed.Length)
                    throw new InvalidDataException("Truncated sproto 0xFF run.");

                int chunks = packed[offset++] + 1;
                int byteCount = checked(chunks * 8);
                if (offset > packed.Length - byteCount)
                    throw new InvalidDataException("Truncated sproto raw run.");

                output.Write(packed.Slice(offset, byteCount));
                offset += byteCount;
                continue;
            }

            Span<byte> chunk = stackalloc byte[8];
            for (int index = 0; index < 8; index++)
            {
                if ((header & (1 << index)) == 0)
                    continue;

                if (offset >= packed.Length)
                    throw new InvalidDataException("Truncated sproto sparse block.");

                chunk[index] = packed[offset++];
            }

            output.Write(chunk);
        }

        return output.ToArray();
    }

    private static byte BuildMask(ReadOnlySpan<byte> chunk)
    {
        byte mask = 0;
        for (int index = 0; index < 8; index++)
        {
            if (chunk[index] != 0)
                mask |= checked((byte)(1 << index));
        }

        return mask;
    }
}
