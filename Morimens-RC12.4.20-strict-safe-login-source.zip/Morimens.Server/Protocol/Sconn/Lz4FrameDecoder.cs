using System.Runtime.InteropServices;
using System.Buffers.Binary;

namespace Morimens.Server.Protocol.Sconn;

public static class Lz4FrameDecoder
{
    private const uint Magic = 0x184D2204;

    public static bool LooksLikeFrame(ReadOnlySpan<byte> data) =>
        data.Length >= 4 &&
        BinaryPrimitives.ReadUInt32LittleEndian(data) == Magic;

    public static byte[] Decode(ReadOnlySpan<byte> frame)
    {
        if (!LooksLikeFrame(frame))
            throw new InvalidDataException("The buffer does not start with an LZ4 frame header.");

        int offset = 4;
        Require(frame, offset, 3);

        byte flg = frame[offset++];
        byte bd = frame[offset++];

        int version = (flg >> 6) & 0x03;
        if (version != 1)
            throw new InvalidDataException($"Unsupported LZ4 frame version: {version}.");

        bool blockChecksum = (flg & 0x10) != 0;
        bool contentSizePresent = (flg & 0x08) != 0;
        bool contentChecksum = (flg & 0x04) != 0;
        bool dictionaryIdPresent = (flg & 0x01) != 0;

        // Reserved bits must be zero. The block-size code is validated for diagnostics,
        // although the decoder grows dynamically and does not depend on the advertised size.
        if ((flg & 0x02) != 0 || (bd & 0x8F) != 0)
            throw new InvalidDataException("Reserved LZ4 frame header bits are set.");

        int blockMaximumCode = (bd >> 4) & 0x07;
        if (blockMaximumCode is < 4 or > 7)
            throw new InvalidDataException($"Unsupported LZ4 maximum block-size code: {blockMaximumCode}.");

        ulong? declaredContentSize = null;
        if (contentSizePresent)
        {
            Require(frame, offset, 8);
            declaredContentSize = BinaryPrimitives.ReadUInt64LittleEndian(frame.Slice(offset, 8));
            offset += 8;
        }

        if (dictionaryIdPresent)
        {
            Require(frame, offset, 4);
            offset += 4;
        }

        // Header checksum. It is retained in captures, but verification would require
        // xxHash32 and is not needed to decode the observed client frames.
        Require(frame, offset, 1);
        offset++;

        using var output = declaredContentSize is > 0 and <= int.MaxValue
            ? new MemoryStream((int)declaredContentSize.Value)
            : new MemoryStream();

        bool sawEndMark = false;
        while (true)
        {
            // Morimens emits a streaming LZ4 chunk that may end immediately after
            // a complete block, without the optional zero-sized frame end mark.
            if (offset == frame.Length)
                break;

            Require(frame, offset, 4);
            uint blockHeader = BinaryPrimitives.ReadUInt32LittleEndian(frame.Slice(offset, 4));
            offset += 4;

            if (blockHeader == 0)
            {
                sawEndMark = true;
                break;
            }

            bool uncompressed = (blockHeader & 0x80000000u) != 0;
            int blockLength = checked((int)(blockHeader & 0x7FFFFFFFu));
            if (blockLength == 0)
                throw new InvalidDataException("LZ4 frame contains an empty non-terminal block.");

            Require(frame, offset, blockLength);
            ReadOnlySpan<byte> block = frame.Slice(offset, blockLength);
            offset += blockLength;

            if (uncompressed)
                output.Write(block);
            else
                DecodeBlock(block, output);

            if (blockChecksum)
            {
                Require(frame, offset, 4);
                offset += 4;
            }
        }

        if (contentChecksum)
        {
            if (!sawEndMark)
                throw new InvalidDataException(
                    "An LZ4 content checksum requires a complete frame end mark.");

            Require(frame, offset, 4);
            offset += 4;
        }

        byte[] result = output.ToArray();
        if (declaredContentSize.HasValue &&
            declaredContentSize.Value != (ulong)result.Length)
        {
            throw new InvalidDataException(
                $"LZ4 content-size mismatch: expected {declaredContentSize.Value}, decoded {result.Length}.");
        }

        return result;
    }

    /// <summary>
    /// Decodes one raw LZ4 block without a frame header. Morimens uses these
    /// blocks inside some post-login RPC batches, mixed with uncompressed
    /// blocks. The output size is derived while decoding.
    /// </summary>
    public static byte[] DecodeRawBlock(ReadOnlySpan<byte> source)
    {
        using var output = new MemoryStream(Math.Max(source.Length * 2, 256));
        DecodeBlock(source, output);
        return output.ToArray();
    }

    private static void DecodeBlock(ReadOnlySpan<byte> source, Stream destination)
    {
        var decoded = new List<byte>(Math.Max(source.Length * 2, 256));
        int input = 0;

        while (input < source.Length)
        {
            byte token = source[input++];

            int literalLength = token >> 4;
            if (literalLength == 15)
                literalLength += ReadLengthExtension(source, ref input);

            if (input + literalLength > source.Length)
                throw new InvalidDataException("LZ4 literal sequence exceeds the input block.");

            for (int i = 0; i < literalLength; i++)
                decoded.Add(source[input + i]);
            input += literalLength;

            if (input == source.Length)
                break;

            if (input + 2 > source.Length)
                throw new InvalidDataException("LZ4 match offset is truncated.");

            int matchOffset = source[input] | (source[input + 1] << 8);
            input += 2;

            if (matchOffset <= 0 || matchOffset > decoded.Count)
                throw new InvalidDataException($"Invalid LZ4 match offset: {matchOffset}.");

            int matchLength = token & 0x0F;
            if (matchLength == 15)
                matchLength += ReadLengthExtension(source, ref input);
            matchLength += 4;

            int matchStart = decoded.Count - matchOffset;
            for (int i = 0; i < matchLength; i++)
                decoded.Add(decoded[matchStart + i]);
        }

        destination.Write(CollectionsMarshal.AsSpan(decoded));
    }

    private static int ReadLengthExtension(ReadOnlySpan<byte> source, ref int input)
    {
        int total = 0;
        while (true)
        {
            if (input >= source.Length)
                throw new InvalidDataException("LZ4 length extension is truncated.");

            byte value = source[input++];
            total = checked(total + value);
            if (value != 255)
                return total;
        }
    }

    private static void Require(ReadOnlySpan<byte> source, int offset, int count)
    {
        if (offset < 0 || count < 0 || offset > source.Length - count)
            throw new InvalidDataException("LZ4 frame is truncated.");
    }
}
