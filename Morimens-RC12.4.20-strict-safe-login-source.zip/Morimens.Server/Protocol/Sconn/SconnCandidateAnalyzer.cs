using System.Security.Cryptography;
using System.Text;

namespace Morimens.Server.Protocol.Sconn;

public sealed record SconnCandidate(
    string Name,
    int Offset,
    int CipherLength,
    int KeyIndex,
    double Score,
    string PlainHexPreview,
    string PlainTextPreview);

public sealed record SconnBurstAnalysis(
    int Length,
    string Shape,
    string? BestCandidate,
    IReadOnlyList<SconnCandidate> Candidates);

public static class SconnCandidateAnalyzer
{
    public static SconnBurstAnalysis Analyze(
        ReadOnlySpan<byte> raw,
        IReadOnlyList<byte[]> keys)
    {
        var candidates = new List<SconnCandidate>();

        for (int keyIndex = 0; keyIndex < keys.Count; keyIndex++)
        {
            byte[] key = keys[keyIndex];

            for (int offset = 0; offset <= Math.Min(32, raw.Length); offset++)
            {
                int available = raw.Length - offset;
                int cipherLength = available - (available % 8);
                if (cipherLength < 8)
                    continue;

                TryCandidate(
                    candidates,
                    raw.Slice(offset, cipherLength),
                    key,
                    keyIndex,
                    offset,
                    cipherLength,
                    $"DES-ECB/key{keyIndex}/offset{offset}");
            }
        }

        List<SconnCandidate> ordered = candidates
            .OrderByDescending(candidate => candidate.Score)
            .Take(24)
            .ToList();

        string shape = raw.Length switch
        {
            >= 24 and <= 40 => "small-service-block",
            >= 140 and <= 220 => "medium-auth-block",
            >= 1500 => "large-login-block",
            _ => "unknown"
        };

        string? best = ordered.Count == 0
            ? null
            : $"{ordered[0].Name}; score={ordered[0].Score:F2}";

        return new SconnBurstAnalysis(
            raw.Length,
            shape,
            best,
            ordered);
    }

    private static void TryCandidate(
        List<SconnCandidate> candidates,
        ReadOnlySpan<byte> cipher,
        byte[] key,
        int keyIndex,
        int offset,
        int cipherLength,
        string name)
    {
        try
        {
            using DES des = DES.Create();
            des.Mode = CipherMode.ECB;
            des.Padding = PaddingMode.None;
            des.Key = key;

            using ICryptoTransform decryptor = des.CreateDecryptor();
            byte[] plain = decryptor.TransformFinalBlock(cipher.ToArray(), 0, cipher.Length);
            double score = ScorePlaintext(plain);

            candidates.Add(new SconnCandidate(
                name,
                offset,
                cipherLength,
                keyIndex,
                score,
                Convert.ToHexString(plain.AsSpan(0, Math.Min(plain.Length, 48))),
                ToTextPreview(plain)));
        }
        catch (CryptographicException)
        {
        }
    }

    private static double ScorePlaintext(ReadOnlySpan<byte> data)
    {
        if (data.IsEmpty)
            return 0;

        int printable = 0;
        int zeroes = 0;
        int structural = 0;

        foreach (byte value in data)
        {
            if (value is >= 0x20 and <= 0x7E || value is 9 or 10 or 13)
                printable++;
            if (value == 0)
                zeroes++;
            if (value is 0x04 or 0x05 or 0x0A or 0x0D or 0x10 or 0x12 or 0x1A)
                structural++;
        }

        double printableRatio = (double)printable / data.Length;
        double zeroRatio = (double)zeroes / data.Length;
        double structureRatio = (double)structural / data.Length;

        double score = printableRatio * 60.0;
        score += Math.Min(structureRatio * 80.0, 20.0);
        score += Math.Min(zeroRatio * 30.0, 10.0);

        if (LooksLikeIso7816Padding(data))
            score += 25.0;
        if (LooksLikeLz4Frame(data))
            score += 40.0;
        if (ContainsUsefulAscii(data))
            score += 20.0;

        return score;
    }

    private static bool LooksLikeIso7816Padding(ReadOnlySpan<byte> data)
    {
        int index = data.Length - 1;
        while (index >= 0 && data[index] == 0)
            index--;

        return index >= 0 && data[index] == 0x80;
    }

    private static bool LooksLikeLz4Frame(ReadOnlySpan<byte> data) =>
        data.Length >= 4 &&
        data[0] == 0x04 &&
        data[1] == 0x22 &&
        data[2] == 0x4D &&
        data[3] == 0x18;

    private static bool ContainsUsefulAscii(ReadOnlySpan<byte> data)
    {
        string text = Encoding.UTF8.GetString(data);
        return text.Contains("login", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("steam", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("operate", StringComparison.OrdinalIgnoreCase) ||
               text.Contains("rpc", StringComparison.OrdinalIgnoreCase);
    }

    private static string ToTextPreview(ReadOnlySpan<byte> data)
    {
        var builder = new StringBuilder();
        foreach (byte value in data[..Math.Min(data.Length, 96)])
        {
            builder.Append(value is >= 0x20 and <= 0x7E ? (char)value : '.');
        }

        return builder.ToString();
    }
}
