using Morimens.Server.Protocol.Crypto;

namespace Morimens.Server.Protocol.Sconn;

public sealed record SconnDecodeResult(
    byte[] Ciphertext,
    byte[] Rc4Plaintext,
    byte[] RpcPayload,
    bool HasLz4Frame);

public static class SconnTransportDecoder
{
    public static byte[] BuildSessionKey(MorimensSessionKeys keys)
    {
        ArgumentNullException.ThrowIfNull(keys);

        byte[] result = new byte[32];
        keys.Key0.CopyTo(result, 0);
        keys.Key1.CopyTo(result, 8);
        keys.Key2.CopyTo(result, 16);
        keys.Key3.CopyTo(result, 24);
        return result;
    }

    public static SconnDecodeResult Decode(
        ReadOnlySpan<byte> ciphertext,
        MorimensSessionKeys keys)
    {
        var rc4 = new MorimensRc4Stream(BuildSessionKey(keys));
        return Decode(ciphertext, rc4);
    }

    public static SconnDecodeResult Decode(
        ReadOnlySpan<byte> ciphertext,
        MorimensRc4Stream rc4)
    {
        ArgumentNullException.ThrowIfNull(rc4);
        byte[] rc4Plaintext = rc4.Transform(ciphertext);
        bool hasLz4Frame = Lz4FrameDecoder.LooksLikeFrame(rc4Plaintext);

        byte[] rpcPayload = hasLz4Frame
            ? Lz4FrameDecoder.Decode(rc4Plaintext)
            : rc4Plaintext.ToArray();

        // Game-node traffic uses a uint32 little-endian record length before
        // the RPC/sproto payload. Example: D3 01 00 00 followed by 467 bytes.
        if (!hasLz4Frame && rpcPayload.Length >= 4)
        {
            uint declaredLength = System.Buffers.Binary.BinaryPrimitives
                .ReadUInt32LittleEndian(rpcPayload.AsSpan(0, 4));

            if (declaredLength == rpcPayload.Length - 4)
                rpcPayload = rpcPayload.AsSpan(4).ToArray();
        }

        return new SconnDecodeResult(
            ciphertext.ToArray(),
            rc4Plaintext,
            rpcPayload,
            hasLz4Frame);
    }
}
