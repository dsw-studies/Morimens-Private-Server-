using System.Buffers.Binary;
using Morimens.Server.Protocol.Crypto;

namespace Morimens.Server.Protocol.Sconn;

public static class SconnTransportEncoder
{
    public static byte[] EncodeGatewayResponse(
        ReadOnlySpan<byte> rpcPayload,
        byte requestSequence,
        MorimensSessionKeys keys,
        MorimensRc4Stream? rc4 = null)
    {
        byte[] lz4 = BuildUncompressedLz4Frame(rpcPayload);
        byte[] envelope = BuildEnvelope(requestSequence, 0x0292, 0x00);
        return EncryptFramed(envelope, lz4, keys, rc4);
    }




public static byte[] EncodeCapturedPostLoginStream(
    ReadOnlySpan<byte> plaintextStream,
    MorimensSessionKeys keys,
    MorimensRc4Stream? rc4 = null)
{
    if (plaintextStream.IsEmpty)
        return [];

    // The builder returns complete uint16-BE framed response records.
    // They are already carrying their own RPC envelope and LZ4 payload.
    rc4 ??= new MorimensRc4Stream(
        SconnTransportDecoder.BuildSessionKey(keys));
    return rc4.Transform(plaintextStream);
}

    public static byte[] EncodeCapturedInitialGameStream(
        ReadOnlySpan<byte> plaintextStream,
        MorimensSessionKeys keys,
        MorimensRc4Stream? rc4 = null)
    {
        if (plaintextStream.Length < 122_046)
        {
            throw new InvalidDataException(
                $"Expected at least the 122046-byte initial game stream, got {plaintextStream.Length}.");
        }

        // The stream starts with the nine captured records and may append valid
        // reconstructed notifications, such as the all-items-to-999 sync.
        // Do not add another frame or another LZ4 layer.
        rc4 ??= new MorimensRc4Stream(SconnTransportDecoder.BuildSessionKey(keys));
        return rc4.Transform(plaintextStream);
    }

    public static byte[] EncodeCapturedGameLoginResponse(
        ReadOnlySpan<byte> completePacket,
        MorimensSessionKeys keys,
        MorimensRc4Stream? rc4 = null)
    {
        // Exact game-stream pipeline observed in the official trace:
        //
        // 1. uint16 big-endian RPC packet size
        // 2. RPC packet
        // 3. one LZ4 streaming block
        // 4. RC4
        //
        // For an uncompressed LZ4 block, bit 31 of the little-endian block
        // header is set. This avoids recompressing the captured payload while
        // preserving the exact transport format expected by the client.
        int rpcRecordLength = checked(2 + completePacket.Length);

        if (completePacket.Length > ushort.MaxValue)
            throw new InvalidDataException(
                $"Captured RPC packet is too large: {completePacket.Length} bytes.");

        byte[] plaintext = new byte[4 + rpcRecordLength];

        BinaryPrimitives.WriteUInt32LittleEndian(
            plaintext.AsSpan(0, 4),
            0x80000000u | checked((uint)rpcRecordLength));

        BinaryPrimitives.WriteUInt16BigEndian(
            plaintext.AsSpan(4, 2),
            checked((ushort)completePacket.Length));

        completePacket.CopyTo(plaintext.AsSpan(6));

        rc4 ??= new MorimensRc4Stream(SconnTransportDecoder.BuildSessionKey(keys));
        return rc4.Transform(plaintext);
    }

    public static byte[] EncodeGameNodeResponse(
        ReadOnlySpan<byte> accountPayload,
        byte requestSequence,
        MorimensSessionKeys keys,
        MorimensRc4Stream? rc4 = null)
    {
        if (accountPayload.Length != 32)
            throw new InvalidDataException($"Expected 32-byte account id, got {accountPayload.Length} bytes.");

        byte[] envelope = BuildEnvelope(requestSequence, 0x0220, 0x03);
        return EncryptFramed(envelope, accountPayload.ToArray(), keys, rc4);
    }

    private static byte[] BuildEnvelope(byte sequence, ushort protocolCode, byte tail)
    {
        // Exact sconn/sproto response envelope observed in successful official traces.
        return
        [
            0x55, 0x02, 0x01, sequence,
            0x02, 0x11,
            (byte)(protocolCode >> 8), (byte)protocolCode,
            0xFF, tail
        ];
    }

    private static byte[] EncryptFramed(
        ReadOnlySpan<byte> envelope,
        ReadOnlySpan<byte> payload,
        MorimensSessionKeys keys,
        MorimensRc4Stream? rc4)
    {
        int packetLength = checked(envelope.Length + payload.Length);
        byte[] plaintext = new byte[2 + packetLength];
        BinaryPrimitives.WriteUInt16BigEndian(plaintext.AsSpan(0, 2), checked((ushort)packetLength));
        envelope.CopyTo(plaintext.AsSpan(2));
        payload.CopyTo(plaintext.AsSpan(2 + envelope.Length));

        rc4 ??= new MorimensRc4Stream(SconnTransportDecoder.BuildSessionKey(keys));
        return rc4.Transform(plaintext);
    }

    private static byte[] BuildUncompressedLz4Frame(ReadOnlySpan<byte> payload)
    {
        byte[] frame = new byte[7 + 4 + payload.Length + 4];
        BinaryPrimitives.WriteUInt32LittleEndian(frame.AsSpan(0, 4), 0x184D2204);
        frame[4] = 0x60;
        frame[5] = 0x40;
        frame[6] = 0x82;
        BinaryPrimitives.WriteUInt32LittleEndian(
            frame.AsSpan(7, 4),
            0x80000000u | checked((uint)payload.Length));
        payload.CopyTo(frame.AsSpan(11, payload.Length));
        BinaryPrimitives.WriteUInt32LittleEndian(frame.AsSpan(11 + payload.Length, 4), 0u);
        return frame;
    }
}
