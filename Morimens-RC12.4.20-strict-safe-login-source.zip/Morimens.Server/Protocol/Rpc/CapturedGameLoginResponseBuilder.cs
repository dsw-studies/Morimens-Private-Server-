using System.Buffers.Binary;
using System.Reflection;

namespace Morimens.Server.Protocol.Rpc;

public static class CapturedGameLoginResponseBuilder
{
    private const string ResourceName =
        "Morimens.Server.Protocol.Fixtures.game-login-response-seq4.bin";

    private static readonly Lazy<byte[]> Template = new(LoadTemplate);

    public static byte[] Build(long localUid, byte requestSequence)
    {
        if (requestSequence != 4)
        {
            throw new InvalidDataException(
                $"Captured Game Login response currently supports sequence 4, got {requestSequence}.");
        }

        if (localUid is <= 0 or > uint.MaxValue)
            throw new ArgumentOutOfRangeException(nameof(localUid));

        byte[] response = Template.Value.ToArray();

        ReadOnlySpan<byte> marker = "roleId"u8;
        int markerOffset = response.AsSpan().IndexOf(marker);
        if (markerOffset < 0)
            throw new InvalidDataException("Captured Game Login response has no roleId field.");

        int valueOffset = markerOffset + marker.Length;
        if (valueOffset + 5 > response.Length || response[valueOffset] != 0xCE)
            throw new InvalidDataException("Captured roleId is not encoded as MessagePack uint32.");

        BinaryPrimitives.WriteUInt32BigEndian(
            response.AsSpan(valueOffset + 1, 4),
            checked((uint)localUid));

        return response;
    }

    private static byte[] LoadTemplate()
    {
        Assembly assembly = typeof(CapturedGameLoginResponseBuilder).Assembly;
        using Stream stream = assembly.GetManifestResourceStream(ResourceName)
            ?? throw new InvalidOperationException(
                $"Embedded resource {ResourceName} was not found.");

        using var memory = new MemoryStream();
        stream.CopyTo(memory);
        return memory.ToArray();
    }
}
