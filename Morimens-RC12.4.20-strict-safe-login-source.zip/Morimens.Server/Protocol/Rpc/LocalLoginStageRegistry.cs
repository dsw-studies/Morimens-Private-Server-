using System.Collections.Concurrent;

namespace Morimens.Server.Protocol.Rpc;

public enum LocalLoginStage
{
    Gateway,
    GameNode
}

public static class LocalLoginStageRegistry
{
    private sealed record Entry(DateTimeOffset ExpiresAt);
    private static readonly ConcurrentDictionary<string, Entry> PendingGameNode =
        new(StringComparer.Ordinal);

    public static LocalLoginStage Consume(string accountId)
    {
        DateTimeOffset now = DateTimeOffset.UtcNow;
        foreach ((string key, Entry value) in PendingGameNode)
        {
            if (value.ExpiresAt <= now)
                PendingGameNode.TryRemove(key, out _);
        }

        if (PendingGameNode.TryRemove(accountId, out Entry? entry) && entry.ExpiresAt > now)
            return LocalLoginStage.GameNode;

        PendingGameNode[accountId] = new Entry(now.AddMinutes(5));
        return LocalLoginStage.Gateway;
    }
}
