using Morimens.Server.Networking.Sessions;

namespace Morimens.Server.Protocol.Rpc;

public interface IRpcDispatcher
{
    ValueTask<RpcDispatchResult> DispatchAsync(
        GameSessionContext session,
        ReadOnlyMemory<byte> plaintext,
        CancellationToken cancellationToken);
}
