using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Morimens.Server.Protocol.Rpc;

public sealed record LoginRequestInspection(
    bool Recognized,
    int PayloadLength,
    string HeaderHex,
    int EncodedOffset,
    int EncodedLength,
    int DecodedJsonLength,
    string? AccountId,
    int TokenLength,
    string? TokenSha256,
    string Detail);

public static class LoginRequestInspector
{
    private static readonly byte[][] Prefixes =
    [
        [],
        "e"u8.ToArray(),
        "ey"u8.ToArray(),
        "eyJ"u8.ToArray()
    ];

    public static LoginRequestInspection Inspect(ReadOnlySpan<byte> payload)
    {
        (int offset, int length) = FindLongestBase64Run(payload);
        string headerHex = Convert.ToHexString(payload[..Math.Min(offset, payload.Length)]);

        if (length < 32)
        {
            return new LoginRequestInspection(
                false, payload.Length, headerHex, offset, length, 0,
                null, 0, null,
                "No sufficiently long base64-like field was found.");
        }

        ReadOnlySpan<byte> encoded = payload.Slice(offset, length);

        foreach (byte[] prefix in Prefixes)
        {
            byte[] candidate = new byte[prefix.Length + encoded.Length];
            prefix.CopyTo(candidate, 0);
            encoded.CopyTo(candidate.AsSpan(prefix.Length));

            string base64 = Encoding.ASCII.GetString(candidate);
            base64 += new string('=', (4 - base64.Length % 4) % 4);

            byte[] decoded;
            try
            {
                decoded = Convert.FromBase64String(base64);
            }
            catch (FormatException)
            {
                continue;
            }

            try
            {
                using JsonDocument document = JsonDocument.Parse(decoded);
                JsonElement root = document.RootElement;

                if (root.ValueKind != JsonValueKind.Object ||
                    !root.TryGetProperty("token", out JsonElement tokenElement) ||
                    !root.TryGetProperty("acc", out JsonElement accountElement))
                {
                    continue;
                }

                string token = tokenElement.GetString() ?? string.Empty;
                string? account = accountElement.GetString();
                string tokenHash = Convert.ToHexString(
                    SHA256.HashData(Encoding.UTF8.GetBytes(token)));

                return new LoginRequestInspection(
                    true,
                    payload.Length,
                    headerHex,
                    offset,
                    length,
                    decoded.Length,
                    account,
                    token.Length,
                    tokenHash,
                    $"LoginRequest JSON recovered with synthetic base64 prefix '{Encoding.ASCII.GetString(prefix)}'.");
            }
            catch (JsonException)
            {
            }
        }

        return new LoginRequestInspection(
            false, payload.Length, headerHex, offset, length, 0,
            null, 0, null,
            "A base64-like field was found, but it did not decode to the expected token/acc JSON.");
    }

    private static (int Offset, int Length) FindLongestBase64Run(ReadOnlySpan<byte> payload)
    {
        int bestOffset = 0;
        int bestLength = 0;
        int currentOffset = 0;
        int currentLength = 0;

        for (int index = 0; index < payload.Length; index++)
        {
            if (IsBase64Byte(payload[index]))
            {
                if (currentLength == 0)
                    currentOffset = index;
                currentLength++;
            }
            else
            {
                if (currentLength > bestLength)
                {
                    bestOffset = currentOffset;
                    bestLength = currentLength;
                }

                currentLength = 0;
            }
        }

        if (currentLength > bestLength)
        {
            bestOffset = currentOffset;
            bestLength = currentLength;
        }

        return (bestOffset, bestLength);
    }

    private static bool IsBase64Byte(byte value) =>
        value is >= (byte)'A' and <= (byte)'Z' ||
        value is >= (byte)'a' and <= (byte)'z' ||
        value is >= (byte)'0' and <= (byte)'9' ||
        value is (byte)'+' or (byte)'/' or (byte)'=';
}
