using System.Buffers.Binary;
using System.Text;
using Morimens.Server.Protocol.Sproto;

namespace Morimens.Server.Protocol.Rpc;

public static class MorimensRpcRecordBuilder
{
    public static byte[] BuildDirectResponse(
        ushort sequence,
        ReadOnlySpan<byte> messagePackPayload)
    {
        byte[] lz4Frame = BuildUncompressedLz4Frame(messagePackPayload);
        byte[] unpacked = new byte[16 + lz4Frame.Length];

        BinaryPrimitives.WriteUInt16LittleEndian(unpacked.AsSpan(0, 2), 2);
        BinaryPrimitives.WriteUInt16LittleEndian(unpacked.AsSpan(2, 2), 1);
        BinaryPrimitives.WriteUInt16LittleEndian(unpacked.AsSpan(4, 2), sequence);
        BinaryPrimitives.WriteUInt16LittleEndian(unpacked.AsSpan(6, 2), 2);
        BinaryPrimitives.WriteUInt16LittleEndian(unpacked.AsSpan(8, 2), 2);
        BinaryPrimitives.WriteUInt16LittleEndian(unpacked.AsSpan(10, 2), 0);
        BinaryPrimitives.WriteUInt32LittleEndian(
            unpacked.AsSpan(12, 4),
            checked((uint)lz4Frame.Length));
        lz4Frame.CopyTo(unpacked.AsSpan(16));

        return FramePacked(SprotoPackCodec.Pack(unpacked));
    }

    public static byte[] BuildNotification(
        string method,
        ReadOnlySpan<byte> messagePackPayload)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(method);

        byte[] methodBytes = Encoding.ASCII.GetBytes(method);
        byte[] lz4Frame = BuildUncompressedLz4Frame(messagePackPayload);
        byte[] unpacked = new byte[18 + methodBytes.Length + lz4Frame.Length];

        // Exact unpacked notification prefix recovered from Role.OnSyncItems.
        BinaryPrimitives.WriteUInt16LittleEndian(unpacked.AsSpan(0, 2), 1);
        BinaryPrimitives.WriteUInt16LittleEndian(unpacked.AsSpan(2, 2), 6);
        BinaryPrimitives.WriteUInt16LittleEndian(unpacked.AsSpan(4, 2), 2);
        BinaryPrimitives.WriteUInt32LittleEndian(unpacked.AsSpan(6, 4), 0);
        BinaryPrimitives.WriteUInt32LittleEndian(
            unpacked.AsSpan(10, 4),
            checked((uint)methodBytes.Length));
        methodBytes.CopyTo(unpacked.AsSpan(14));

        int frameLengthOffset = 14 + methodBytes.Length;
        BinaryPrimitives.WriteUInt32LittleEndian(
            unpacked.AsSpan(frameLengthOffset, 4),
            checked((uint)lz4Frame.Length));
        lz4Frame.CopyTo(unpacked.AsSpan(frameLengthOffset + 4));

        return FramePacked(SprotoPackCodec.Pack(unpacked));
    }

    public static byte[] RewriteDirectResponseSequence(
        ReadOnlySpan<byte> completeRecord,
        ushort sequence)
    {
        if (completeRecord.Length < 3)
            throw new InvalidDataException("Captured RPC record is truncated.");

        int packedLength = BinaryPrimitives.ReadUInt16BigEndian(
            completeRecord.Slice(0, 2));
        if (packedLength <= 0 || packedLength > completeRecord.Length - 2)
            throw new InvalidDataException("Captured RPC record length is invalid.");

        byte[] unpacked = SprotoPackCodec.Unpack(
            completeRecord.Slice(2, packedLength));
        if (unpacked.Length < 16 ||
            BinaryPrimitives.ReadUInt16LittleEndian(unpacked.AsSpan(0, 2)) != 2 ||
            BinaryPrimitives.ReadUInt16LittleEndian(unpacked.AsSpan(2, 2)) != 1)
        {
            throw new InvalidDataException(
                "Captured RPC record is not a direct response package.");
        }

        BinaryPrimitives.WriteUInt16LittleEndian(
            unpacked.AsSpan(4, 2),
            sequence);

        return FramePacked(SprotoPackCodec.Pack(unpacked));
    }

    public static byte[] Combine(params byte[][] records)
    {
        int length = records.Sum(static record => record?.Length ?? 0);
        byte[] result = new byte[length];
        int offset = 0;

        foreach (byte[]? record in records)
        {
            if (record is null || record.Length == 0)
                continue;

            record.CopyTo(result, offset);
            offset += record.Length;
        }

        return result;
    }

    private static byte[] FramePacked(ReadOnlySpan<byte> packed)
    {
        if (packed.Length > ushort.MaxValue)
        {
            throw new InvalidDataException(
                $"Packed RPC record is too large: {packed.Length} bytes.");
        }

        byte[] result = new byte[2 + packed.Length];
        BinaryPrimitives.WriteUInt16BigEndian(
            result.AsSpan(0, 2),
            checked((ushort)packed.Length));
        packed.CopyTo(result.AsSpan(2));
        return result;
    }

    private static byte[] BuildUncompressedLz4Frame(
        ReadOnlySpan<byte> payload)
    {
        byte[] frame = new byte[7 + 4 + payload.Length + 4];
        BinaryPrimitives.WriteUInt32LittleEndian(
            frame.AsSpan(0, 4),
            0x184D2204);
        frame[4] = 0x60;
        frame[5] = 0x40;
        frame[6] = 0x82;
        BinaryPrimitives.WriteUInt32LittleEndian(
            frame.AsSpan(7, 4),
            0x80000000u | checked((uint)payload.Length));
        payload.CopyTo(frame.AsSpan(11));
        BinaryPrimitives.WriteUInt32LittleEndian(
            frame.AsSpan(11 + payload.Length, 4),
            0);
        return frame;
    }
}
