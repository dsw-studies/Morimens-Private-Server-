using System.Buffers.Binary;
using System.Text;
using Morimens.Server.Protocol.Sconn;
using Morimens.Server.Protocol.Sproto;

namespace Morimens.Server.Protocol.Rpc;

public sealed record GameRpcRequest(
    ushort Sequence,
    string Method,
    byte[] Frame);

public static class GameRpcStreamParser
{
    private static readonly string[] KnownMethods =
    [
        // Action calls recovered or inferred from the supplied official traces.
        // Specific/long names must remain before their module prefixes.
        "Item.UseChooseItem",
        "Item.OpenChooseItem",
        "Item.UseItem",
        "Summon.GetSummonRecord",
        "Summon.SummonFive",
        "Summon.DoSummon",
        "Summon.OnSummon",
        "Summon.Summon",
        "Summon.Draw",
        "Summon.Pull",
        "Shop.Purchase",
        "Shop.BuyGoods",
        "Shop.BuyItem",
        "Shop.Buy",

        "Login.Heartbeat",
        "SchoolTowerMgr.OnOpenSchoolTower",
        "ActivityMgr.GetClientProfile",
        "Roles.GetPvpOpeningVoice",
        "Roles.GetClientProfile",
        "PvpTeam.OnOpenPvpTeam",
        "HomeConversion.OnOpen",
        "Setting.ChangeLanguage",
        "DailyChallenge.OnOpen",
        "AbyssChallenge.OnOpen",
        "TaskModuleMgr.OnOpen",
        "Item.OnShowTrinkGet",
        "Base.OpenClientData",
        "Item.OnShowWeapon",
        "Collection.OnOpen",
        "Stage.GetStageIn",
        "Talents.OnTalent",
        "Teams.ShowTeam",
        "Produce.OnOpen",
        "Social.OnOpen",
        "Comment.OnOpen",
        "Summon.OnOpen",
        "Tutorial.OnOpen",
        "Trinket.OnOpen",
        "Base.OnOpen",
        "Pvp.OnOpGen",
        "Shop.Open",
        "Login"
    ];

    private static readonly string[] MethodModules =
    [
        "Login", "SchoolTowerMgr", "ActivityMgr", "Roles", "PvpTeam",
        "HomeConversion", "Setting", "DailyChallenge", "AbyssChallenge",
        "TaskModuleMgr", "Item", "Base", "Collection", "Stage", "Talents",
        "Teams", "Produce", "Social", "Comment", "Summon", "Tutorial",
        "Trinket", "Pvp", "Shop", "Role"
    ];

    public static IReadOnlyList<GameRpcRequest> Parse(ReadOnlyMemory<byte> payload) =>
        Parse(payload.Span);

    public static IReadOnlyList<GameRpcRequest> Parse(ReadOnlySpan<byte> payload)
    {
        var result = new List<GameRpcRequest>();

        if (TryParseLz4Blocks(payload, result) && result.Count > 0)
            return result;

        result.Clear();
        if (TryParseBigEndianRecords(payload, result) && result.Count > 0)
            return result;

        result.Clear();
        AddScannedFrame(payload, result);
        return result;
    }

    private static bool TryParseLz4Blocks(
        ReadOnlySpan<byte> stream,
        List<GameRpcRequest> output)
    {
        int offset = 0;
        bool sawBlock = false;

        while (offset < stream.Length)
        {
            if (offset + 4 > stream.Length)
                return false;

            uint header = BinaryPrimitives.ReadUInt32LittleEndian(
                stream.Slice(offset, 4));

            bool uncompressed = (header & 0x80000000u) != 0;
            int blockLength = checked((int)(header & 0x7FFFFFFFu));

            if (blockLength <= 0 ||
                offset + 4 + blockLength > stream.Length)
            {
                return false;
            }

            sawBlock = true;
            ReadOnlySpan<byte> encodedBlock =
                stream.Slice(offset + 4, blockLength);

            byte[]? decodedBlock = null;
            ReadOnlySpan<byte> block = encodedBlock;

            if (!uncompressed)
            {
                try
                {
                    decodedBlock = Lz4FrameDecoder.DecodeRawBlock(encodedBlock);
                    block = decodedBlock;
                }
                catch (InvalidDataException)
                {
                    return false;
                }
            }

            if (!TryParseBigEndianRecords(block, output))
                return false;

            offset += 4 + blockLength;
        }

        return sawBlock;
    }

    private static bool TryParseBigEndianRecords(
        ReadOnlySpan<byte> stream,
        List<GameRpcRequest> output)
    {
        int offset = 0;
        bool sawRecord = false;

        while (offset < stream.Length)
        {
            if (offset + 2 > stream.Length)
                return false;

            int frameLength = BinaryPrimitives.ReadUInt16BigEndian(
                stream.Slice(offset, 2));

            if (frameLength <= 0 ||
                offset + 2 + frameLength > stream.Length)
            {
                return false;
            }

            sawRecord = true;
            ReadOnlySpan<byte> frame = stream.Slice(offset + 2, frameLength);
            AddFrame(frame, output);
            offset += 2 + frameLength;
        }

        return sawRecord;
    }

    private static void AddScannedFrame(
        ReadOnlySpan<byte> payload,
        List<GameRpcRequest> output)
    {
        int frameStart = FindFrameStart(payload);
        if (frameStart < 0)
            return;

        AddFrame(payload[frameStart..], output);
    }

    private static void AddFrame(
        ReadOnlySpan<byte> frame,
        List<GameRpcRequest> output)
    {
        int frameStart = FindFrameStart(frame);
        if (frameStart < 0 || frameStart + 4 > frame.Length)
            return;

        ReadOnlySpan<byte> rpcFrame = frame[frameStart..];
        ushort sequence = ReadSequence(rpcFrame);
        byte[] inspectionFrame = BuildInspectionFrame(rpcFrame);
        string method = ExtractKnownMethod(inspectionFrame);
        if (string.IsNullOrWhiteSpace(method))
            method = ExtractLikelyMethod(inspectionFrame);
        if (string.IsNullOrWhiteSpace(method))
            method = $"Unknown_{sequence:X4}";

        output.Add(new GameRpcRequest(
            sequence,
            method,
            inspectionFrame));
    }

    private static byte[] BuildInspectionFrame(ReadOnlySpan<byte> packedFrame)
    {
        byte[] packed = packedFrame.ToArray();

        try
        {
            byte[] unpacked = SprotoPackCodec.Unpack(packedFrame);
            int lz4Offset = FindLz4Frame(unpacked);
            if (lz4Offset < 0)
                return MorimensRpcRecordBuilder.Combine(packed, unpacked);

            byte[] decoded = Lz4FrameDecoder.Decode(unpacked.AsSpan(lz4Offset));
            return MorimensRpcRecordBuilder.Combine(packed, unpacked, decoded);
        }
        catch (InvalidDataException)
        {
            // A scanned fallback may include trailing bytes from another packet.
            // Keep the original packed bytes so known-method recognition can still run.
            return packed;
        }
    }

    private static int FindLz4Frame(ReadOnlySpan<byte> source)
    {
        ReadOnlySpan<byte> magic = [0x04, 0x22, 0x4D, 0x18];
        return source.IndexOf(magic);
    }

    private static ushort ReadSequence(ReadOnlySpan<byte> frame)
    {
        if (frame.Length < 4)
            throw new InvalidDataException("Packed RPC frame is truncated.");

        return frame[0] switch
        {
            0x45 => 0,
            0x55 => frame[3],
            0x65 => checked((ushort)(frame[3] << 8)),
            0x75 when frame.Length >= 5 =>
                BinaryPrimitives.ReadUInt16LittleEndian(frame.Slice(3, 2)),
            _ => frame[3]
        };
    }

    private static int FindFrameStart(ReadOnlySpan<byte> bytes)
    {
        for (int index = 0; index <= bytes.Length - 3; index++)
        {
            byte mask = bytes[index];
            bool requestHeaderMask = mask is 0x45 or 0x55 or 0x65 or 0x75;
            if (requestHeaderMask &&
                bytes[index + 1] == 0x02 &&
                bytes[index + 2] == 0x04)
            {
                return index;
            }
        }

        return -1;
    }

    private static string ExtractKnownMethod(ReadOnlySpan<byte> frame)
    {
        foreach (string method in KnownMethods)
        {
            if (ContainsMethod(frame, method))
                return method;
        }

        return string.Empty;
    }

    private static string ExtractLikelyMethod(ReadOnlySpan<byte> frame)
    {
        foreach (string module in MethodModules)
        {
            string prefix = module + ".";
            ReadOnlySpan<byte> expectedPrefix = Encoding.ASCII.GetBytes(prefix);

            for (int start = 0; start < frame.Length; start++)
            {
                if (!TryMatchWithPackingGaps(
                        frame,
                        start,
                        expectedPrefix,
                        out int source))
                {
                    continue;
                }

                var method = new StringBuilder(prefix);
                int skipped = 0;
                while (source < frame.Length && method.Length < 96)
                {
                    byte value = frame[source];
                    if (IsMethodCharacter(value))
                    {
                        method.Append((char)value);
                        source++;
                        skipped = 0;
                        continue;
                    }

                    if (skipped < 4)
                    {
                        source++;
                        skipped++;
                        continue;
                    }

                    break;
                }

                string candidate = method.ToString().TrimEnd('.', '_');
                if (candidate.Length > prefix.Length)
                    return candidate;
            }
        }

        return string.Empty;
    }

    private static bool ContainsMethod(
        ReadOnlySpan<byte> frame,
        string method)
    {
        ReadOnlySpan<byte> expected = Encoding.ASCII.GetBytes(method);

        for (int start = 0; start < frame.Length; start++)
        {
            if (TryMatchWithPackingGaps(
                    frame,
                    start,
                    expected,
                    out _))
            {
                return true;
            }
        }

        return false;
    }

    private static bool TryMatchWithPackingGaps(
        ReadOnlySpan<byte> frame,
        int start,
        ReadOnlySpan<byte> expected,
        out int source)
    {
        source = start;
        int target = 0;
        int skipped = 0;

        while (source < frame.Length &&
               target < expected.Length &&
               skipped <= 4)
        {
            byte value = frame[source];

            if (value == expected[target])
            {
                source++;
                target++;
                skipped = 0;
                continue;
            }

            if (!IsMethodCharacter(value))
            {
                source++;
                skipped++;
                continue;
            }

            break;
        }

        return target == expected.Length;
    }

    private static bool IsMethodCharacter(byte value) =>
        value is >= (byte)'A' and <= (byte)'Z' or
        >= (byte)'a' and <= (byte)'z' or
        >= (byte)'0' and <= (byte)'9' or
        (byte)'.' or (byte)'_';
}
