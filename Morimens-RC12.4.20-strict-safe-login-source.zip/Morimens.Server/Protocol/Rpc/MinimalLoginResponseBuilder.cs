using System.Buffers.Binary;

namespace Morimens.Server.Protocol.Rpc;

public static class MinimalLoginResponseBuilder
{
    public static byte[] Build(long localUid)
    {
        if (localUid is <= 0 or > uint.MaxValue)
            throw new ArgumentOutOfRangeException(nameof(localUid));

        uint uid = checked((uint)localUid);
        string nodeInstance = "operate-global-game-2.operate-global-game.z1-p11222";
        string node = nodeInstance + "#1782693592";

        using var stream = new MemoryStream();

        WriteArrayHeader(stream, 2);
        WriteMapHeader(stream, 2);

        WriteString(stream, "address");
        WriteMapHeader(stream, 4);
        WriteString(stream, "node");
        WriteString(stream, node);
        WriteString(stream, "boxid");
        WriteString(stream, "123124");
        WriteString(stream, "node_instance");
        WriteString(stream, nodeInstance);
        WriteString(stream, "service");
        WriteString(stream, "444");

        WriteString(stream, "uid");
        WriteUInt32(stream, uid);
        WriteUInt32(stream, uid);

        return stream.ToArray();
    }

    private static void WriteArrayHeader(Stream stream, int count) =>
        stream.WriteByte((byte)(0x90 | count));

    private static void WriteMapHeader(Stream stream, int count) =>
        stream.WriteByte((byte)(0x80 | count));

    private static void WriteUInt32(Stream stream, uint value)
    {
        stream.WriteByte(0xCE);
        Span<byte> bytes = stackalloc byte[4];
        BinaryPrimitives.WriteUInt32BigEndian(bytes, value);
        stream.Write(bytes);
    }

    private static void WriteString(Stream stream, string value)
    {
        byte[] bytes = System.Text.Encoding.UTF8.GetBytes(value);
        if (bytes.Length <= 31)
            stream.WriteByte((byte)(0xA0 | bytes.Length));
        else
        {
            stream.WriteByte(0xD9);
            stream.WriteByte(checked((byte)bytes.Length));
        }

        stream.Write(bytes);
    }
}
