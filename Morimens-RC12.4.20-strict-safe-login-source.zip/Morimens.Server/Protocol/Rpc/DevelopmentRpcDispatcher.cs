using System.Collections.Concurrent;
using Morimens.Server.Networking.Sessions;
using Morimens.Server.Services;

namespace Morimens.Server.Protocol.Rpc;

public sealed class DevelopmentRpcDispatcher(
    ILogger<DevelopmentRpcDispatcher> logger,
    ActiveLocalAccountRegistry activeAccounts) : IRpcDispatcher
{
    private readonly ConcurrentDictionary<Guid, int> _itemUseFallback = new();

    public ValueTask<RpcDispatchResult> DispatchAsync(
        GameSessionContext session,
        ReadOnlyMemory<byte> plaintext,
        CancellationToken cancellationToken)
    {
        ReadOnlySpan<byte> rpc = plaintext.Span;
        IReadOnlyList<GameRpcRequest> gameRequests =
            GameRpcStreamParser.Parse(plaintext);

        GameRpcRequest? gameLogin = gameRequests.FirstOrDefault(
            request => string.Equals(
                request.Method,
                "Login",
                StringComparison.Ordinal));

        if (gameLogin is not null && rpc.Length < 1200)
        {
            ActiveLocalAccount? selected = activeAccounts.Current;
            if (selected is null)
            {
                return ValueTask.FromResult(RpcDispatchResult.Unknown(
                    "Game Login received, but no local account is selected."));
            }

            if (gameLogin.Sequence > byte.MaxValue)
            {
                return ValueTask.FromResult(RpcDispatchResult.Unknown(
                    $"Unsupported GAME Login sequence {gameLogin.Sequence}."));
            }

            // RC12.4.20: the complete login/bootstrap path remains identical to
            // the proven RC12.4.16 behavior. No economy notification, full-shop
            // payload, or feature-unlock packet is injected during startup.
            _itemUseFallback.TryRemove(session.Id, out _);
            session.InitialGameStreamPrepared = true;
            session.PostLoginActionsReady = false;
            session.PostLoginHeartbeatCount = 0;
            session.InventorySeedSent = false;

            logger.LogInformation(
                "Session {SessionId}: GAME Login RPC recognized. sequence={Sequence}, " +
                "payload={PayloadLength}, localUser={Username}, uid={Uid}.",
                session.Id,
                gameLogin.Sequence,
                rpc.Length,
                selected.Username,
                selected.Uid);

            byte[] capturedStream =
                CapturedInitialGameStreamBuilder.Build(
                    selected.Uid,
                    selected.DisplayName,
                    selected.Stamina,
                    selected.Gold,
                    checked((byte)gameLogin.Sequence));

            logger.LogInformation(
                "Session {SessionId}: byte-stable RC12.4.16 initial GAME stream prepared. " +
                "sequence={Sequence}, localUser={Username}, localUid={LocalUid}, " +
                "protocolUid={ProtocolUid}, displayName={DisplayName}, stamina={Stamina}, " +
                "gold={Gold}, stream={StreamLength}, records=9.",
                session.Id,
                gameLogin.Sequence,
                selected.Username,
                selected.Uid,
                selected.Uid,
                selected.DisplayName,
                selected.Stamina,
                selected.Gold,
                capturedStream.Length);

            return ValueTask.FromResult(RpcDispatchResult.Success(
                capturedStream,
                $"Captured initial game stream prepared for protocol uid=" +
                $"{selected.Uid}."));
        }

        if (gameRequests.Count > 0)
        {
            ActiveLocalAccount? selected = activeAccounts.Current;
            if (selected is null)
            {
                return ValueTask.FromResult(RpcDispatchResult.Unknown(
                    "Post-login RPC received, but no local account is selected."));
            }

            using var responseOutput = new MemoryStream();
            var handledActions = new List<string>();
            var replayRequests = new List<GameRpcRequest>();

            // Only explicit irreversible user actions are intercepted here.
            // These methods cannot be part of passive startup/menu bootstrap:
            // a real pull, a real purchase, or explicit item consumption.
            // Shop.Open, Summon.OnOpen, Item.OpenChooseItem and all heartbeats
            // always continue through the stable RC12.4.16 response bank.
            foreach (GameRpcRequest request in gameRequests)
            {
                int fallbackIndex = _itemUseFallback.GetOrAdd(session.Id, 0);
                if (!CapturedActionResponseBuilder.TryBuild(
                        request,
                        fallbackIndex,
                        out byte[] actionResponse,
                        out string action))
                {
                    replayRequests.Add(request);
                    continue;
                }

                responseOutput.Write(actionResponse);
                handledActions.Add(
                    $"{request.Sequence}:{request.Method}=>{action}");

                if (action.StartsWith("use-", StringComparison.Ordinal))
                {
                    _itemUseFallback.AddOrUpdate(
                        session.Id,
                        1,
                        static (_, current) => current + 1);
                }
            }

            // Always use the original compact captured response templates for
            // ordinary post-login traffic. The full 42-tab shop catalog is not
            // injected automatically because Shop.Open also occurs while the
            // client is still constructing the main menu.
            byte[] replayStream = CapturedPostLoginResponseBuilder.Build(
                replayRequests,
                out int replayCount,
                out string replaySummary,
                enableExtendedShop: false);
            responseOutput.Write(replayStream);

            // Restoring all discovered items to 999 is safe only after an
            // explicit action initiated by the player. Never send this large
            // notification because of heartbeat/open-window traffic.
            bool appendInventorySync = handledActions.Count > 0;
            if (appendInventorySync)
            {
                responseOutput.Write(
                    CapturedActionResponseBuilder.BuildInventorySeedNotification());
                session.InventorySeedSent = true;
            }

            string methods = string.Join(
                ", ",
                gameRequests.Select(
                    request => $"{request.Sequence}:{request.Method}"));
            string actionSummary = handledActions.Count == 0
                ? "none"
                : string.Join(", ", handledActions);

            logger.LogInformation(
                "Session {SessionId}: compatibility-safe post-login batch processed. " +
                "requests={RequestCount}, methods={Methods}, actions={Actions}, " +
                "replayResponses={ReplayCount}, responseMap={ResponseMap}, " +
                "inventorySync={InventorySync}, bytes={Length}.",
                session.Id,
                gameRequests.Count,
                methods,
                actionSummary,
                replayCount,
                replaySummary,
                appendInventorySync,
                responseOutput.Length);

            if (responseOutput.Length == 0)
            {
                return ValueTask.FromResult(RpcDispatchResult.Success(
                    null,
                    $"Post-login RPC batch observed; no response required. " +
                    $"requests={gameRequests.Count}."));
            }

            return ValueTask.FromResult(RpcDispatchResult.Success(
                responseOutput.ToArray(),
                $"Captured post-login stream prepared; compatibilitySafe=true, " +
                $"actions={actionSummary}, replayResponses={replayCount}, " +
                $"inventorySync={appendInventorySync}."));
        }

        LoginRequestInspection inspection = LoginRequestInspector.Inspect(rpc);
        if (!inspection.Recognized ||
            string.IsNullOrWhiteSpace(inspection.AccountId))
        {
            return ValueTask.FromResult(
                RpcDispatchResult.Unknown(inspection.Detail));
        }

        ActiveLocalAccount? local = activeAccounts.Current;
        if (local is null)
        {
            logger.LogWarning(
                "Session {SessionId}: gateway login rejected because no local " +
                "account is selected. Use POST /api/auth/login first.",
                session.Id);

            return ValueTask.FromResult(RpcDispatchResult.Unknown(
                "No local account selected. Login through the local API first."));
        }

        long protocolUid = local.Uid;
        byte[] response = MinimalLoginResponseBuilder.Build(protocolUid);

        logger.LogInformation(
            "Session {SessionId}: GATEWAY LoginRequest mapped to local user={Username}, " +
            "localUid={LocalUid}, protocolUid={ProtocolUid}. Payload={PayloadLength}, " +
            "header={HeaderHex}, protocolAccount={ProtocolAccount}, responseRpc={ResponseLength}.",
            session.Id,
            local.Username,
            local.Uid,
            protocolUid,
            inspection.PayloadLength,
            inspection.HeaderHex,
            inspection.AccountId,
            response.Length);

        return ValueTask.FromResult(RpcDispatchResult.Success(
            response,
            $"Gateway LoginResponse generated for replay protocol uid={protocolUid}."));
    }
}
