namespace Morimens.Server.Protocol.Rpc;

public sealed record RpcDispatchResult(bool Handled, byte[]? Response, string Detail)
{
    public static RpcDispatchResult Unknown(string detail) => new(false, null, detail);
    public static RpcDispatchResult Success(byte[]? response, string detail) => new(true, response, detail);
}
