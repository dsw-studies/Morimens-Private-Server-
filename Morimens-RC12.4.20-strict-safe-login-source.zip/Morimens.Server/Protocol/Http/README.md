# HTTP compatibility layer

Add routes and DTO adapters matching the original client here. Keep internal application services independent from the wire format.
