using System.Buffers.Binary;

namespace Morimens.Server.Protocol.Tcp;

public static class MorimensFrameCodec
{
    public static async ValueTask<byte[]?> ReadAsync(
        Stream stream,
        int maximumLength,
        CancellationToken cancellationToken)
    {
        byte[] header = new byte[2];
        if (!await ReadExactlyOrEndAsync(stream, header, cancellationToken))
            return null;

        int length = BinaryPrimitives.ReadUInt16BigEndian(header);
        if (length <= 0 || length > maximumLength)
            throw new InvalidDataException($"Invalid Morimens frame length: {length}.");

        byte[] payload = new byte[length];
        if (!await ReadExactlyOrEndAsync(stream, payload, cancellationToken))
            throw new EndOfStreamException("Connection closed in the middle of a Morimens frame.");

        return payload;
    }

    public static async ValueTask WriteAsync(
        Stream stream,
        ReadOnlyMemory<byte> payload,
        CancellationToken cancellationToken)
    {
        if (payload.Length is <= 0 or > ushort.MaxValue)
            throw new ArgumentOutOfRangeException(nameof(payload));

        byte[] header = new byte[2];
        BinaryPrimitives.WriteUInt16BigEndian(header, checked((ushort)payload.Length));
        await stream.WriteAsync(header, cancellationToken);
        await stream.WriteAsync(payload, cancellationToken);
        await stream.FlushAsync(cancellationToken);
    }

    private static async ValueTask<bool> ReadExactlyOrEndAsync(
        Stream stream,
        Memory<byte> destination,
        CancellationToken cancellationToken)
    {
        int offset = 0;
        while (offset < destination.Length)
        {
            int read = await stream.ReadAsync(destination[offset..], cancellationToken);
            if (read == 0)
                return false;
            offset += read;
        }
        return true;
    }
}
