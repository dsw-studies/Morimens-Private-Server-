# TCP gateway

Add connection framing, heartbeat, session management, encryption and packet dispatch here.
