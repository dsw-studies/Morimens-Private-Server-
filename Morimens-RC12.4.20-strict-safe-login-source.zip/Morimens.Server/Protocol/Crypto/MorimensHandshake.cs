using System.Buffers.Binary;
using System.Globalization;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;
using Morimens.Server.Protocol.Tcp;

namespace Morimens.Server.Protocol.Crypto;

public sealed record MorimensClientHandshake(
    string ProtocolVersion,
    byte[] ClientPublicKey,
    string ServerName,
    string Flags,
    string Compression);

public sealed record MorimensSessionKeys(
    byte[] ServerPrivateKey,
    byte[] ServerPublicKey,
    byte[] SharedSecret,
    byte[] Key0,
    byte[] Key1,
    byte[] Key2,
    byte[] Key3)
{
    public IReadOnlyList<byte[]> AllKeys => [Key0, Key1, Key2, Key3];

    // Временная совместимость со старым кодом.
    public byte[] HashKey => Key0;
}

public static class MorimensHandshake
{
    private static readonly BigInteger Prime = (BigInteger.One << 64) - 59;
    private const ulong Generator = 5;

    public static MorimensClientHandshake ParseClient(ReadOnlySpan<byte> payload)
    {
        string text = Encoding.UTF8.GetString(payload);
        string[] lines = text.Split('\n');
        if (lines.Length < 5)
            throw new InvalidDataException("Client handshake must contain at least five lines.");

        byte[] publicKey;
        try
        {
            publicKey = Convert.FromBase64String(lines[1].TrimEnd('\r'));
        }
        catch (FormatException exception)
        {
            throw new InvalidDataException("Client DH public key is not valid Base64.", exception);
        }

        if (publicKey.Length != 8)
            throw new InvalidDataException("Client DH public key must be exactly eight bytes.");

        ulong publicValue = BinaryPrimitives.ReadUInt64LittleEndian(publicKey);
        if (publicValue == 0 || new BigInteger(publicValue) >= Prime)
            throw new InvalidDataException("Client DH public key is outside the accepted range.");

        return new MorimensClientHandshake(
            lines[0].TrimEnd('\r'),
            publicKey,
            lines[2].TrimEnd('\r'),
            lines[3].TrimEnd('\r'),
            lines[4].TrimEnd('\r'));
    }

    public static MorimensSessionKeys CreateSessionKeys(ReadOnlySpan<byte> clientPublicKey)
    {
        if (clientPublicKey.Length != 8)
            throw new ArgumentException("Client public key must be eight bytes.", nameof(clientPublicKey));

        ulong clientPublic = BinaryPrimitives.ReadUInt64LittleEndian(clientPublicKey);
        ulong serverPrivate = GeneratePrivateKey();
        ulong serverPublic = PowMod(Generator, serverPrivate);
        ulong sharedSecret = PowMod(clientPublic, serverPrivate);

        byte[] privateBytes = ToLittleEndian(serverPrivate);
        byte[] publicBytes = ToLittleEndian(serverPublic);
        byte[] sharedBytes = ToLittleEndian(sharedSecret);

        return new MorimensSessionKeys(
            privateBytes,
            publicBytes,
            sharedBytes,
            Hmac64Md5(sharedBytes, 0),
            Hmac64Md5(sharedBytes, 1),
            Hmac64Md5(sharedBytes, 2),
            Hmac64Md5(sharedBytes, 3));
    }

    public static byte[] BuildServerPayload(MorimensSessionKeys keys, string compression)
    {
        string challenge = RandomNumberGenerator
            .GetInt32(10_000_000, 100_000_000)
            .ToString(CultureInfo.InvariantCulture);

        string text = string.Join('\n', challenge, Convert.ToBase64String(keys.ServerPublicKey), compression);
        return Encoding.UTF8.GetBytes(text);
    }

    // Точное поведение skynet crypt.hmac64_md5:
    // MD5((a || b) repeated 3), затем XOR первой и второй половины digest.
    public static byte[] Hmac64Md5(ReadOnlySpan<byte> a, ulong counter)
    {
        if (a.Length != 8)
            throw new ArgumentException("hmac64_md5 first argument must be eight bytes.", nameof(a));

        Span<byte> b = stackalloc byte[8];
        BinaryPrimitives.WriteUInt64LittleEndian(b, counter);

        byte[] input = new byte[48];
        for (int i = 0; i < 3; i++)
        {
            a.CopyTo(input.AsSpan(i * 16, 8));
            b.CopyTo(input.AsSpan(i * 16 + 8, 8));
        }

        byte[] digest = MD5.HashData(input);
        byte[] result = new byte[8];
        for (int i = 0; i < 8; i++)
            result[i] = (byte)(digest[i] ^ digest[i + 8]);

        return result;
    }

    // Оставлено только для анализа старых captures; в актуальном handshake не используется.
    public static byte[] HashKey(ReadOnlySpan<byte> data)
    {
        uint h1 = 0x00001505;
        uint h2 = 0x4E67C6A7;
        unchecked
        {
            foreach (byte value in data)
            {
                h1 = h1 * 33 + value;
                h2 ^= (h2 >> 2) + (h2 << 5) + value;
            }
        }

        byte[] result = new byte[8];
        BinaryPrimitives.WriteUInt32LittleEndian(result.AsSpan(0, 4), h1);
        BinaryPrimitives.WriteUInt32LittleEndian(result.AsSpan(4, 4), h2);
        return result;
    }

    private static ulong GeneratePrivateKey()
    {
        Span<byte> bytes = stackalloc byte[8];
        while (true)
        {
            RandomNumberGenerator.Fill(bytes);
            ulong value = BinaryPrimitives.ReadUInt64LittleEndian(bytes);
            if (value != 0 && new BigInteger(value) < Prime)
                return value;
        }
    }

    private static ulong PowMod(ulong value, ulong exponent) =>
        checked((ulong)BigInteger.ModPow(new BigInteger(value), new BigInteger(exponent), Prime));

    private static byte[] ToLittleEndian(ulong value)
    {
        byte[] bytes = new byte[8];
        BinaryPrimitives.WriteUInt64LittleEndian(bytes, value);
        return bytes;
    }
}
