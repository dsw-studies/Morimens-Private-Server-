namespace Morimens.Server.Protocol.Crypto;

public static class MorimensRc4
{
    public static byte[] Transform(ReadOnlySpan<byte> input, ReadOnlySpan<byte> key)
    {
        if (key.IsEmpty)
            throw new ArgumentException("RC4 key must not be empty.", nameof(key));

        Span<byte> state = stackalloc byte[256];
        for (int i = 0; i < state.Length; i++)
            state[i] = (byte)i;

        int j = 0;
        for (int i = 0; i < state.Length; i++)
        {
            j = (j + state[i] + key[i % key.Length]) & 0xFF;
            (state[i], state[j]) = (state[j], state[i]);
        }

        byte[] output = new byte[input.Length];
        int x = 0;
        j = 0;

        for (int offset = 0; offset < input.Length; offset++)
        {
            x = (x + 1) & 0xFF;
            j = (j + state[x]) & 0xFF;
            (state[x], state[j]) = (state[j], state[x]);
            byte keyByte = state[(state[x] + state[j]) & 0xFF];
            output[offset] = (byte)(input[offset] ^ keyByte);
        }

        return output;
    }
}
