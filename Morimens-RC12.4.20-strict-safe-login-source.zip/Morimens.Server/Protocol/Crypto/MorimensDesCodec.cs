using System.Security.Cryptography;

namespace Morimens.Server.Protocol.Crypto;

public static class MorimensDesCodec
{
    public static bool TryDecrypt(ReadOnlySpan<byte> encrypted, ReadOnlySpan<byte> key, out byte[] plaintext)
    {
        plaintext = [];
        if (key.Length != 8 || encrypted.Length == 0 || encrypted.Length % 8 != 0)
            return false;

        try
        {
            using DES des = DES.Create();
            des.Mode = CipherMode.ECB;
            des.Padding = PaddingMode.None;
            des.Key = key.ToArray();
            using ICryptoTransform transform = des.CreateDecryptor();
            byte[] raw = transform.TransformFinalBlock(encrypted.ToArray(), 0, encrypted.Length);
            plaintext = RemoveIso7816Padding(raw);
            return true;
        }
        catch (CryptographicException)
        {
            return false;
        }
    }

    public static byte[] Encrypt(ReadOnlySpan<byte> plaintext, ReadOnlySpan<byte> key)
    {
        if (key.Length != 8)
            throw new ArgumentException("DES key must be eight bytes.", nameof(key));

        byte[] padded = AddIso7816Padding(plaintext);
        using DES des = DES.Create();
        des.Mode = CipherMode.ECB;
        des.Padding = PaddingMode.None;
        des.Key = key.ToArray();
        using ICryptoTransform transform = des.CreateEncryptor();
        return transform.TransformFinalBlock(padded, 0, padded.Length);
    }

    private static byte[] AddIso7816Padding(ReadOnlySpan<byte> data)
    {
        int paddedLength = checked(((data.Length / 8) + 1) * 8);
        byte[] result = new byte[paddedLength];
        data.CopyTo(result);
        result[data.Length] = 0x80;
        return result;
    }

    private static byte[] RemoveIso7816Padding(byte[] data)
    {
        int index = data.Length - 1;
        int zeroCount = 0;
        while (index >= 0 && data[index] == 0)
        {
            index--;
            zeroCount++;
        }

        if (index >= 0 && data[index] == 0x80 && zeroCount <= 7)
            return data.AsSpan(0, index).ToArray();

        return data;
    }
}
