namespace Morimens.Server.Protocol.Crypto;

public sealed class MorimensRc4Stream
{
    private readonly byte[] _state = new byte[256];
    private int _x;
    private int _y;

    public MorimensRc4Stream(ReadOnlySpan<byte> key)
    {
        if (key.IsEmpty)
            throw new ArgumentException("RC4 key must not be empty.", nameof(key));

        for (int i = 0; i < _state.Length; i++)
            _state[i] = (byte)i;

        int j = 0;
        for (int i = 0; i < _state.Length; i++)
        {
            j = (j + _state[i] + key[i % key.Length]) & 0xFF;
            (_state[i], _state[j]) = (_state[j], _state[i]);
        }
    }

    public byte[] Transform(ReadOnlySpan<byte> input)
    {
        byte[] output = new byte[input.Length];

        for (int offset = 0; offset < input.Length; offset++)
        {
            _x = (_x + 1) & 0xFF;
            _y = (_y + _state[_x]) & 0xFF;
            (_state[_x], _state[_y]) = (_state[_y], _state[_x]);

            byte keyByte = _state[(_state[_x] + _state[_y]) & 0xFF];
            output[offset] = (byte)(input[offset] ^ keyByte);
        }

        return output;
    }
}
