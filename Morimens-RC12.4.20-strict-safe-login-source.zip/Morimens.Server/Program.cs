using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Morimens.Server.Data;
using Morimens.Server.Features.Economy;
using Morimens.Server.GameConfig;
using Morimens.Server.Networking;
using Morimens.Server.Networking.Sessions;
using Morimens.Server.Protocol.Rpc;
using Morimens.Server.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Morimens.Server API",
        Version = "v1",
        Description = "Development API for the Morimens private-server project."
    });

    var bearerScheme = new OpenApiSecurityScheme
    {
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        Reference = new OpenApiReference
        {
            Type = ReferenceType.SecurityScheme,
            Id = JwtBearerDefaults.AuthenticationScheme
        }
    };

    options.AddSecurityDefinition(bearerScheme.Reference.Id, bearerScheme);
    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        [bearerScheme] = Array.Empty<string>()
    });
});

builder.Services.AddCors(options =>
{
    options.AddPolicy("DevelopmentClient", policy =>
        policy.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
});

var persistentDataDirectory = Path.Combine(
    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
    "MorimensPrivateServer");
Directory.CreateDirectory(persistentDataDirectory);

var persistentDatabasePath = Path.Combine(persistentDataDirectory, "morimens-admin-v1.db");
var legacyDatabasePath = Path.Combine(AppContext.BaseDirectory, "morimens-admin-v1.db");
if (!File.Exists(persistentDatabasePath) && File.Exists(legacyDatabasePath))
{
    File.Copy(legacyDatabasePath, persistentDatabasePath);
}

builder.Services.AddDbContext<GameDbContext>(options =>
    options.UseSqlite($"Data Source={persistentDatabasePath}"));

builder.Services.AddScoped<TokenService>();
builder.Services.AddScoped<AccountService>();
builder.Services.AddScoped<GameBootstrapService>();
builder.Services.AddScoped<GameEconomyService>();

builder.Services.AddSingleton<PasswordService>();
builder.Services.AddSingleton<ActiveLocalAccountRegistry>();
builder.Services.AddSingleton<GameConfigCatalog>();
builder.Services.AddSingleton<EconomyCatalog>();

builder.Services.Configure<GameTcpOptions>(
    builder.Configuration.GetSection(GameTcpOptions.SectionName));

builder.Services.AddSingleton<GameSessionRegistry>();
builder.Services.AddSingleton<IRpcDispatcher, DevelopmentRpcDispatcher>();
builder.Services.AddHostedService<GameTcpHostedService>();

var jwtKey = builder.Configuration["Jwt:Key"]
    ?? throw new InvalidOperationException("Jwt:Key is missing.");

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(jwtKey)),
            ClockSkew = TimeSpan.FromSeconds(15)
        };
    });

builder.Services.AddAuthorization();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<GameDbContext>();
    await LocalAccountSchema.EnsureAsync(db);
}

app.UseSwagger();
app.UseSwaggerUI();
app.UseDefaultFiles();
app.UseStaticFiles();
app.UseCors("DevelopmentClient");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

app.MapGet("/health", () => Results.Ok(new
{
    ok = true,
    service = "Morimens.Server",
    utc = DateTimeOffset.UtcNow
}));

app.MapGet("/admin", () => Results.Redirect("/admin/index.html"));

await app.RunAsync();

