$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$program = Join-Path $root 'Morimens.Server\Program.cs'

if (-not (Test-Path $program)) { throw "Program.cs not found: $program" }

$text = Get-Content $program -Raw
$marker = 'await LocalAccountSchema.EnsureAsync(db);'
$insert = @'
await LocalAccountSchema.EnsureAsync(db);
}

await OwnerAccountSeeder.EnsureAsync(app.Services);

// OWNER_ACCOUNT_SEED_APPLIED
using (var unusedOwnerSeedMarker = app.Services.CreateScope())
{
'@

if ($text -notmatch 'OWNER_ACCOUNT_SEED_APPLIED') {
    if (-not $text.Contains($marker)) { throw "Marker not found in Program.cs" }
    $text = $text.Replace($marker + "`r`n}", $insert)
    Set-Content $program $text -Encoding UTF8
}

Write-Host 'Owner account startup seed applied.' -ForegroundColor Green
