import json
import re
from pathlib import Path

INPUT_FILE = Path("research/private/stringliteral.json")
OUTPUT_FILE = Path("research/network_strings.txt")

KEYWORDS = (
    "http", "https", "api", "login", "auth", "token",
    "server", "request", "response", "player", "account",
    "version", "config", "gateway", "json", "sign"
)

URL_PATTERN = re.compile(
    r"https?://[^\s\"'<>\\]+",
    re.IGNORECASE,
)


def collect_strings(value):
    """Рекурсивно извлекает все строки из JSON."""
    if isinstance(value, str):
        yield value
    elif isinstance(value, list):
        for item in value:
            yield from collect_strings(item)
    elif isinstance(value, dict):
        for key, item in value.items():
            yield from collect_strings(key)
            yield from collect_strings(item)


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Файл не найден: {INPUT_FILE.resolve()}"
        )

    with INPUT_FILE.open("r", encoding="utf-8-sig") as file:
        data = json.load(file)

    results = set()

    for text in collect_strings(data):
        normalized = text.strip()
        lower = normalized.lower()

        if URL_PATTERN.search(normalized):
            results.add(normalized)
            continue

        if any(keyword in lower for keyword in KEYWORDS):
            results.add(normalized)

    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_FILE.write_text(
        "\n".join(sorted(results, key=str.lower)),
        encoding="utf-8",
    )

    print(f"Найдено строк: {len(results)}")
    print(f"Результат: {OUTPUT_FILE.resolve()}")


if __name__ == "__main__":
    main()