#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import struct
from pathlib import Path

import lz4.frame
import msgpack

ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / "Morimens.Server"
FIXTURES = SERVER / "Protocol" / "Fixtures"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def sproto_pack(source: bytes) -> bytes:
    output = bytearray()
    offset = 0
    while offset < len(source):
        chunk = source[offset:offset + 8].ljust(8, b"\0")
        mask = sum((1 << i) for i, value in enumerate(chunk) if value)
        if mask == 0xFF:
            run_chunks = 1
            while run_chunks < 256:
                next_offset = offset + run_chunks * 8
                if next_offset + 8 > len(source):
                    break
                next_chunk = source[next_offset:next_offset + 8]
                next_mask = sum((1 << i) for i, value in enumerate(next_chunk) if value)
                if next_mask != 0xFF:
                    break
                run_chunks += 1
            output.extend((0xFF, run_chunks - 1))
            output.extend(source[offset:offset + run_chunks * 8])
            offset += run_chunks * 8
            continue
        output.append(mask)
        output.extend(chunk[i] for i in range(8) if mask & (1 << i))
        offset += min(8, len(source) - offset)
    return bytes(output)


def sproto_unpack(packed: bytes) -> bytes:
    output = bytearray()
    offset = 0
    while offset < len(packed):
        header = packed[offset]
        offset += 1
        if header == 0xFF:
            require(offset < len(packed), "truncated sproto run")
            chunks = packed[offset] + 1
            offset += 1
            size = chunks * 8
            require(offset + size <= len(packed), "truncated sproto run data")
            output.extend(packed[offset:offset + size])
            offset += size
            continue
        chunk = bytearray(8)
        for index in range(8):
            if header & (1 << index):
                require(offset < len(packed), "truncated sproto sparse data")
                chunk[index] = packed[offset]
                offset += 1
        output.extend(chunk)
    return bytes(output)


def lz4_uncompressed_frame(payload: bytes) -> bytes:
    return (
        b"\x04\x22\x4d\x18\x60\x40\x82"
        + struct.pack("<I", 0x80000000 | len(payload))
        + payload
        + b"\0\0\0\0"
    )


def frame_packed(packed: bytes) -> bytes:
    require(len(packed) <= 0xFFFF, f"packed record too large: {len(packed)}")
    return struct.pack(">H", len(packed)) + packed


def build_direct(sequence: int, payload: bytes) -> bytes:
    frame = lz4_uncompressed_frame(payload)
    raw = struct.pack("<HHHHHHI", 2, 1, sequence, 2, 2, 0, len(frame)) + frame
    return frame_packed(sproto_pack(raw))


def build_notification(method: str, payload: bytes) -> bytes:
    method_bytes = method.encode("ascii")
    frame = lz4_uncompressed_frame(payload)
    raw = (
        struct.pack("<HHHII", 1, 6, 2, 0, len(method_bytes))
        + method_bytes
        + struct.pack("<I", len(frame))
        + frame
    )
    return frame_packed(sproto_pack(raw))


def decode_complete_direct(record: bytes) -> tuple[int, bytes]:
    require(len(record) >= 3, "direct record too short")
    packed_length = struct.unpack_from(">H", record, 0)[0]
    require(packed_length + 2 == len(record), "direct record length mismatch")
    raw = sproto_unpack(record[2:])
    require(struct.unpack_from("<HH", raw, 0) == (2, 1), "not a direct response")
    sequence = struct.unpack_from("<H", raw, 4)[0]
    frame_length = struct.unpack_from("<I", raw, 12)[0]
    frame = raw[16:16 + frame_length]
    require(len(frame) == frame_length, "truncated direct lz4 frame")
    return sequence, lz4.frame.decompress(frame)


def decode_complete_notification(record: bytes) -> tuple[str, bytes]:
    packed_length = struct.unpack_from(">H", record, 0)[0]
    require(packed_length + 2 == len(record), "notification record length mismatch")
    raw = sproto_unpack(record[2:])
    require(struct.unpack_from("<HHH", raw, 0) == (1, 6, 2), "not a notification")
    method_length = struct.unpack_from("<I", raw, 10)[0]
    method = raw[14:14 + method_length].decode("ascii")
    frame_offset = 14 + method_length
    frame_length = struct.unpack_from("<I", raw, frame_offset)[0]
    frame = raw[frame_offset + 4:frame_offset + 4 + frame_length]
    require(len(frame) == frame_length, "truncated notification lz4 frame")
    return method, lz4.frame.decompress(frame)


def strip_csharp_literals_and_comments(text: str) -> str:
    # Lightweight delimiter check, not a compiler. It removes comments and the
    # common C# string/character forms used by the changed files.
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = re.sub(r"//[^\n]*", "", text)
    text = re.sub(r'@"(?:""|[^"])*"', '""', text)
    text = re.sub(r'\$?"(?:\\.|[^"\\])*"', '""', text)
    text = re.sub(r"'(?:\\.|[^'\\])'", "''", text)
    return text


def validate_balanced_source(path: Path) -> None:
    clean = strip_csharp_literals_and_comments(path.read_text(encoding="utf-8"))
    pairs = {"}": "{", ")": "(", "]": "["}
    stack: list[tuple[str, int]] = []
    for index, char in enumerate(clean):
        if char in "{([":
            stack.append((char, index))
        elif char in pairs:
            require(stack and stack[-1][0] == pairs[char], f"delimiter mismatch in {path} at {index}")
            stack.pop()
    require(not stack, f"unclosed delimiter in {path}: {stack[-1] if stack else ''}")


def main() -> None:
    checks: list[str] = []

    items = json.loads((SERVER / "GameConfig/Data/items.json").read_text(encoding="utf-8"))
    ids = [int(item["id"]) for item in items]
    require(len(ids) == 213, f"expected 213 IDs, got {len(ids)}")
    require(len(set(ids)) == len(ids), "duplicate IDs in items.json")
    for needed in (1, 2, 9567, 9597, 9802, 21775, 34699, 9745, 9901, 145290, 145294, 145300):
        require(needed in ids, f"required ID {needed} missing")
    checks.append("213 unique captured item/currency IDs")

    cs_ids_text = (SERVER / "Features/Economy/CapturedEconomyIds.cs").read_text(encoding="utf-8")
    list_body = cs_ids_text.split("[", 1)[1].rsplit("]", 1)[0]
    cs_ids = [int(value) for value in re.findall(r"\b\d+\b", list_body)]
    # The first parsed number may come from SeedQuantity if the split strategy is changed;
    # compare by set and exact count to make drift visible.
    require(cs_ids == ids, "CapturedEconomyIds.cs and items.json differ")
    require("SeedQuantity = 999" in cs_ids_text, "seed quantity is not 999")
    checks.append("C# and JSON ID catalogs match; seed quantity 999")

    seed_payload = (FIXTURES / "inventory-all-999.msgpack").read_bytes()
    seed = msgpack.unpackb(seed_payload, raw=False, strict_map_key=False)
    seed_items = seed[1]
    require(seed.get("n") == 1, "inventory notification n flag mismatch")
    require(len(seed_items) == 213, f"expected 213 seed entries, got {len(seed_items)}")
    require([item["tid"] for item in seed_items] == ids, "seed item order/IDs differ")
    require(all(item["num"] == 999 and item["changedNum"] == 999 for item in seed_items), "not all seed quantities are 999")
    checks.append("Role.OnSyncItems payload has all 213 IDs at 999")

    genesis_payload = (FIXTURES / "genesis-five-pull.msgpack").read_bytes()
    genesis = msgpack.unpackb(genesis_payload, raw=False, strict_map_key=False)
    pulls = genesis[0]["items"]
    require(len(pulls) == 5, "Genesis pull does not contain five slots")
    require(all(item["tid"] == 145294 for item in pulls), "non-Genesis item in five-pull")
    require(all(item["extraItems"][0]["tid"] == 145294 for item in pulls), "Genesis extraItems mismatch")
    checks.append("five-pull contains five Genesis Lotan (145294)")

    shop_buy = msgpack.unpackb((FIXTURES / "shop-buy-ticket.msgpack").read_bytes(), raw=False, strict_map_key=False)
    offer = shop_buy[0]["uids"][0]
    require(shop_buy[0]["shopType"] == 18652, "shop type mismatch")
    require((offer["uid"], offer["itemTid"], offer["price"]) == (17627, 9802, 200), "shop purchase fixture mismatch")
    checks.append("shop purchase 17627 -> item 9802 for 200")

    reward_expectations = {
        "item-use-event-signature.msgpack": {145300},
        "item-use-event-hero.msgpack": {145290},
        "item-use-normal-hero.msgpack": {9745, 9901},
    }
    for name, expected in reward_expectations.items():
        value = msgpack.unpackb((FIXTURES / name).read_bytes(), raw=False, strict_map_key=False)
        actual = {int(item["tid"]) for item in value[0]}
        require(actual == expected, f"{name}: expected {expected}, got {actual}")
    checks.append("all three choice-item reward fixtures match trace IDs")

    shop_record = (FIXTURES / "shop-open-full-catalog.bin").read_bytes()
    shop_sequence, shop_payload = decode_complete_direct(shop_record)
    require(shop_sequence == 258, f"unexpected captured shop sequence {shop_sequence}")
    shop_catalog = msgpack.unpackb(shop_payload, raw=False, strict_map_key=False)
    require(isinstance(shop_catalog, list) and len(shop_catalog) == 2, "shop catalog top-level shape mismatch")
    shops = shop_catalog[0]
    require(18652 in shops, "shop 18652 missing from full catalog")
    catalog_offers = shops[18652].get("goodsList", [])
    require(any(row.get("uid") == 17627 and row.get("itemTid") == 9802 for row in catalog_offers), "offer 17627 missing from full catalog")
    checks.append(f"full shop catalog decodes ({len(shops)} tabs/types, {len(shop_payload)} MessagePack bytes)")

    for sequence in (1, 255, 258, 65535):
        record = build_direct(sequence, genesis_payload)
        parsed_sequence, parsed_payload = decode_complete_direct(record)
        require(parsed_sequence == sequence and parsed_payload == genesis_payload, f"direct roundtrip failed for sequence {sequence}")
    checks.append("generated direct RPC responses roundtrip for 8/16-bit sequences")

    notification = build_notification("Role.OnSyncItems", seed_payload)
    method, parsed_seed = decode_complete_notification(notification)
    require(method == "Role.OnSyncItems" and parsed_seed == seed_payload, "notification roundtrip failed")
    require(len(notification) < 65538, "inventory notification exceeds uint16 record limit")
    checks.append(f"generated 999 sync notification roundtrips ({len(notification)} bytes)")

    rewritten_shop = bytearray(sproto_unpack(shop_record[2:]))
    struct.pack_into("<H", rewritten_shop, 4, 65535)
    rewritten_complete = frame_packed(sproto_pack(bytes(rewritten_shop)))
    rewritten_sequence, rewritten_payload = decode_complete_direct(rewritten_complete)
    require(rewritten_sequence == 65535 and rewritten_payload == shop_payload, "shop sequence rewrite roundtrip failed")
    checks.append("full shop response can be rewritten to any 16-bit sequence")

    initial = (FIXTURES / "game-login-initial-stream.bin").read_bytes()
    require(len(initial) == 122_046, f"initial stream length changed: {len(initial)}")
    checks.append("base captured initial stream length is intact")

    csproj = (SERVER / "Morimens.Server.csproj").read_text(encoding="utf-8")
    resource_names = re.findall(r'<EmbeddedResource Include="([^"]+)"', csproj)
    for resource in resource_names:
        require((SERVER / resource.replace("\\", "/")).is_file(), f"embedded resource missing: {resource}")
    for required in (
        "shop-open-full-catalog.bin", "genesis-five-pull.msgpack", "shop-buy-ticket.msgpack",
        "item-use-event-signature.msgpack", "item-use-event-hero.msgpack",
        "item-use-normal-hero.msgpack", "inventory-all-999.msgpack",
    ):
        require(required in csproj, f"resource not embedded: {required}")
    checks.append("all new fixture resources are embedded and present")

    dispatcher = (SERVER / "Protocol/Rpc/DevelopmentRpcDispatcher.cs").read_text(encoding="utf-8")
    require('"Captured post-login stream prepared;' in dispatcher, "post-login transport routing prefix missing")
    require("BuildInventorySeedNotification" in dispatcher, "login inventory seed missing")
    checks.append("dispatcher routes reconstructed streams through raw game transport")

    parser = (SERVER / "Protocol/Rpc/GameRpcStreamParser.cs").read_text(encoding="utf-8")
    for mask in ("0x45", "0x55", "0x65", "0x75"):
        require(mask in parser, f"request sequence mask {mask} missing")
    require("BuildInspectionFrame" in parser and "Lz4FrameDecoder.Decode" in parser,
            "request payload inspection/decompression missing")
    checks.append("request parser handles zero/8-bit/16-bit sequence masks and decoded payload inspection")

    changed_sources = [
        SERVER / "Protocol/Sproto/SprotoPackCodec.cs",
        SERVER / "Protocol/Rpc/MorimensRpcRecordBuilder.cs",
        SERVER / "Protocol/Rpc/CapturedActionResponseBuilder.cs",
        SERVER / "Protocol/Rpc/GameRpcStreamParser.cs",
        SERVER / "Protocol/Rpc/CapturedPostLoginResponseBuilder.cs",
        SERVER / "Protocol/Rpc/DevelopmentRpcDispatcher.cs",
        SERVER / "Networking/GameTcpHostedService.cs",
        SERVER / "Protocol/Sconn/SconnTransportEncoder.cs",
        SERVER / "Features/Gateway/AccountService.cs",
        SERVER / "Features/Gateway/ActiveLocalAccountRegistry.cs",
        SERVER / "Infrastructure/Persistence/PlayerProfile.cs",
        SERVER / "Protocol/Rpc/CapturedInitialGameStreamBuilder.cs",
        SERVER / "Features/Economy/CapturedEconomyIds.cs",
    ]
    for source in changed_sources:
        validate_balanced_source(source)
    checks.append(f"delimiter/static structure check passed for {len(changed_sources)} changed C# files")

    print("RC12.4.17 validation: PASS")
    for index, check in enumerate(checks, 1):
        print(f"{index:02d}. PASS - {check}")
    print("NOTE: this validator checks protocol fixtures and source structure; it is not a .NET compilation.")


if __name__ == "__main__":
    main()
