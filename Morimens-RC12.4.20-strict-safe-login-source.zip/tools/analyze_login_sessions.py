#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import csv
import json
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

CLIENT = "client-to-server"
SERVER = "server-to-client"

@dataclass
class Handshake:
    frame_len: int
    payload: bytes
    lines: list[str]
    public_key: bytes | None


def read_be_frame(data: bytes, offset: int = 0) -> tuple[bytes, int]:
    if offset + 2 > len(data):
        raise ValueError("missing 2-byte big-endian frame length")
    size = int.from_bytes(data[offset:offset+2], "big")
    end = offset + 2 + size
    if end > len(data):
        raise ValueError(f"truncated frame: need {size}, available {len(data)-offset-2}")
    return data[offset+2:end], end


def parse_handshake(data: bytes, side: str) -> Handshake:
    payload, end = read_be_frame(data)
    text = payload.decode("utf-8", errors="replace")
    lines = text.split("\n")
    key = None
    key_line = 1 if side in (CLIENT, SERVER) else -1
    if len(lines) > key_line:
        try:
            decoded = base64.b64decode(lines[key_line], validate=True)
            if len(decoded) == 8:
                key = decoded
        except Exception:
            pass
    return Handshake(end, payload, lines, key)


def iter_events(path: Path) -> Iterable[dict]:
    if not path.exists():
        return
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def session_dirs(root: Path) -> list[Path]:
    return sorted({p.parent for p in root.rglob("traffic.jsonl")})


def hex_or_blank(value: bytes | None) -> str:
    return value.hex() if value else ""


def first_post_handshake_event(events: list[dict], side: str, handshake_bytes: int) -> dict | None:
    for e in events:
        if e.get("direction") == side and int(e.get("offset", -1)) >= handshake_bytes:
            return e
    return None


def analyze(root: Path, out: Path) -> int:
    sessions = session_dirs(root)
    out.mkdir(parents=True, exist_ok=True)
    rows: list[dict] = []
    usable = 0

    for d in sessions:
        cpath = d / "client-to-server.bin"
        spath = d / "server-to-client.bin"
        if not cpath.exists() or not spath.exists():
            continue
        c = cpath.read_bytes()
        s = spath.read_bytes()
        if not c or not s:
            continue
        try:
            ch = parse_handshake(c, CLIENT)
            sh = parse_handshake(s, SERVER)
        except Exception as ex:
            rows.append({"session": str(d.relative_to(root)), "error": str(ex)})
            continue

        events = list(iter_events(d / "traffic.jsonl"))
        cfirst = first_post_handshake_event(events, CLIENT, ch.frame_len)
        sfirst = first_post_handshake_event(events, SERVER, sh.frame_len)
        usable += 1

        rows.append({
            "session": str(d.relative_to(root)),
            "client_bytes": len(c),
            "server_bytes": len(s),
            "events": len(events),
            "client_handshake_bytes": ch.frame_len,
            "server_handshake_bytes": sh.frame_len,
            "client_public_le_hex": hex_or_blank(ch.public_key),
            "server_public_le_hex": hex_or_blank(sh.public_key),
            "challenge": sh.lines[0] if sh.lines else "",
            "compression": sh.lines[2] if len(sh.lines) > 2 else "",
            "first_c2s_offset": cfirst.get("offset", "") if cfirst else "",
            "first_c2s_length": cfirst.get("length", "") if cfirst else "",
            "first_s2c_offset": sfirst.get("offset", "") if sfirst else "",
            "first_s2c_length": sfirst.get("length", "") if sfirst else "",
            "error": "",
        })

    fields = [
        "session", "client_bytes", "server_bytes", "events",
        "client_handshake_bytes", "server_handshake_bytes",
        "client_public_le_hex", "server_public_le_hex", "challenge", "compression",
        "first_c2s_offset", "first_c2s_length", "first_s2c_offset", "first_s2c_length", "error"
    ]
    with (out / "login_sessions.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow(r)

    report = f"""# Login session audit

Scanned root: `{root}`

- traffic sessions found: {len(sessions)}
- non-empty sessions with valid open handshake: {usable}
- output table: `login_sessions.csv`

## Confirmed format

Each direction starts with one plaintext frame using a 2-byte big-endian length.
The client handshake contains protocol version, 8-byte DH public key (Base64), server name, flags and `>lz4`.
The server handshake contains challenge, 8-byte DH public key (Base64) and `>lz4`.

## Critical cryptographic result

The old proxy captures both DH **public** keys, but it does not store either endpoint's DH **private** key or the derived shared secret/hashkey.
Therefore historical encrypted payloads cannot be deterministically decrypted from these files alone without solving a discrete-log problem in the 64-bit DH group.

The sessions remain highly useful for:

- exact timing and packet-boundary comparisons;
- identifying baseline versus profile/inventory actions;
- validating a decoder after a key is captured;
- replay-shape and required-response ordering;
- checking sizes and cadence of the post-login RPC sequence.

For plaintext LoginRequest/LoginResponse, the next capture must record the derived 8-byte hashkey (or plaintext immediately before DES encode / after DES decode) from the live client. This can be done with a small crypto-only hook and does not require Lua dumping.
"""
    (out / "REPORT.md").write_text(report, encoding="utf-8")
    print(report)
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("dumps", type=Path)
    ap.add_argument("--out", type=Path, default=Path("LoginSessionAudit"))
    ns = ap.parse_args()
    return analyze(ns.dumps.resolve(), ns.out.resolve())

if __name__ == "__main__":
    raise SystemExit(main())
