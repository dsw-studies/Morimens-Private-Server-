@echo off
setlocal
cd /d "%~dp0"
start "Morimens Server" cmd /k dotnet run --project Morimens.Server\Morimens.Server.csproj --urls http://localhost:5000
timeout /t 3 /nobreak >nul
dotnet run --project Morimens.Launcher\Morimens.Launcher.csproj
