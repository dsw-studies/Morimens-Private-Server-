Исправление видимости полей аккаунта.

Распаковать содержимое папки morimens_credentials_launcher_fix3 в корень проекта
D:\Morimens-ReServer с заменой файлов.

Затем выполнить:
cd D:\Morimens-ReServer
Remove-Item .\Morimens.Launcher\bin -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item .\Morimens.Launcher\obj -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item .\publish -Recurse -Force -ErrorAction SilentlyContinue
.\build-portable.cmd
