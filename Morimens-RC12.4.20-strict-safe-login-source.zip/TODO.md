# TODO

## Phase 1 — Research

- [ ] Create project structure
- [ ] Configure development environment
- [ ] Analyze `stringliteral.json`
- [ ] Find networking classes
- [ ] Identify server URL
- [ ] Identify login request
- [ ] Identify request/response format

---

## Phase 2 — Server

- [ ] Create FastAPI project
- [ ] Run local server
- [ ] Implement `/login`
- [ ] Implement `/heartbeat`
- [ ] Implement `/player/info`

---

## Phase 3 — Client Connection

- [ ] Redirect client to local server
- [ ] Receive first request
- [ ] Return first valid response
- [ ] Reach main menu

---

## Phase 4 — Game Systems

- [ ] Player profile
- [ ] Inventory
- [ ] Character list
- [ ] Gacha
- [ ] Story progression
- [ ] Save system

---

## Future

- [ ] Database migration
- [ ] Docker support
- [ ] Admin panel
- [ ] Web API documentation