# Morimens Portable Launcher

## Что получает пользователь

Одна переносимая папка или ZIP:

```text
MorimensPortable/
├─ Morimens.Launcher.exe
└─ Runtime/
   └─ Server/
      └─ Morimens.Server.exe
```

.NET, Visual Studio и исходники на целевом компьютере не нужны.

## Сборка

На компьютере разработчика должен быть установлен .NET 8 SDK.

```bat
build-portable.cmd
```

Готовый архив появится здесь:

```text
publish\MorimensPortable-win-x64.zip
```

## Использование на чистой Windows

1. Распаковать ZIP.
2. Запустить `Morimens.Launcher.exe` от имени администратора.
3. Указать путь к установленной игре.
4. Выбрать «Официальный сервер» или «Приватный сервер».
5. Для приватного режима ввести ник.
6. Нажать «Играть».

Лаунчер сам запускает backend, ждёт его готовности и переключает подключение. Настройки сохраняются в `%LOCALAPPDATA%\MorimensPrivateLauncher`.

## Важно

Сам клиент игры в portable-пакет не входит. Пользователь указывает путь к своей установленной копии Morimens.
