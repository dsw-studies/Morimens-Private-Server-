Скопируйте содержимое этой папки в корень Morimens-ReServer с заменой файлов.
Затем удалите Morimens.Launcher/bin и Morimens.Launcher/obj и запустите build-portable.cmd.
