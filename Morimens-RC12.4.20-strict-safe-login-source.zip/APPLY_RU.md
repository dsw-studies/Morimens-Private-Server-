# Morimens Server Pipeline v1

Это обновлённый серверный каркас из проекта `111.zip`.

## Что добавлено

- правильный 2-байтовый big-endian framing;
- настоящий DH handshake (`g=5`, `p=2^64-59`);
- вычисление shared secret и `hashkey`;
- DES-ECB с ISO 7816-4 padding;
- отдельный объект TCP-сессии;
- журнал и бинарные captures каждой стадии;
- граница `IRpcDispatcher` для будущего Login/RPC/sproto;
- диагностический endpoint `GET /api/tcp/sessions`;
- режим `GameTcp:Mode = Server` включён по умолчанию.

## Как применить

Сделай резервную копию текущей папки проекта, затем замени в ней папки:

```text
Morimens.Server
Morimens.Common
Morimens.Protocol
```

на папки из архива.

Запуск из корня проекта:

```powershell
dotnet restore
dotnet run --project .\Morimens.Server\Morimens.Server.csproj
```

TCP-сервер слушает порт `8443`.

## Что пока специально не выдумано

- точная post-handshake обёртка;
- место LZ4;
- RPC/sconn заголовок;
- sproto-схемы LoginRequest/LoginResponse.

Когда появится удачный CryptoTrace, эти части подключаются внутри `IRpcDispatcher`,
не меняя listener, handshake, сессии, captures и базу.
