# Morimens.Protocol

Future protocol compatibility layer for HTTP, TCP and sproto messages recovered from the original client.
