namespace Morimens.Protocol.Packets;

public sealed record PacketEnvelope(string Route, byte[] Payload);
