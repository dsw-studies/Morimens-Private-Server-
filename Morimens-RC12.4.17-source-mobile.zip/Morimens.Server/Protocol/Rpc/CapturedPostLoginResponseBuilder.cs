using System.Buffers.Binary;
using System.Reflection;

namespace Morimens.Server.Protocol.Rpc;

public static class CapturedPostLoginResponseBuilder
{
    private const string ResourceName =
        "Morimens.Server.Protocol.Fixtures.post-login-response-bank.bin";
    private const string FullShopResourceName =
        "Morimens.Server.Protocol.Fixtures.shop-open-full-catalog.bin";

    private static readonly Lazy<IReadOnlyDictionary<byte, byte[]>> Templates =
        new(LoadTemplates);
    private static readonly Lazy<byte[]> FullShopTemplate =
        new(() => LoadResource(FullShopResourceName));

    public static byte[] Build(
        IReadOnlyList<GameRpcRequest> requests,
        out int responseCount,
        out string responseSummary)
    {
        ArgumentNullException.ThrowIfNull(requests);

        using var output = new MemoryStream();
        var respondedSequences = new HashSet<ushort>();
        var emitted = new List<string>();
        int talentOccurrence = 0;

        foreach (GameRpcRequest request in requests)
        {
            byte? templateSequence = ResolveTemplateSequence(
                request,
                talentOccurrence);

            if (request.Method == "Talents.OnTalent")
                talentOccurrence++;

            if (!respondedSequences.Add(request.Sequence))
                continue;

            byte[]? template = null;
            if (request.Method == "Shop.Open")
            {
                template = FullShopTemplate.Value;
            }
            else if (templateSequence is byte sequence &&
                     Templates.Value.TryGetValue(sequence, out byte[]? captured))
            {
                template = captured;
            }

            if (template is null)
                continue;

            byte[] response = MorimensRpcRecordBuilder
                .RewriteDirectResponseSequence(
                    template,
                    request.Sequence);
            output.Write(response);

            emitted.Add(
                request.Method == "Shop.Open"
                    ? $"{request.Sequence}:{request.Method}<=full-shop"
                    : $"{request.Sequence}:{request.Method}<={templateSequence}");
        }

        responseCount = emitted.Count;
        responseSummary = emitted.Count == 0
            ? "none"
            : string.Join(", ", emitted);

        return output.ToArray();
    }

    private static byte? ResolveTemplateSequence(
        GameRpcRequest request,
        int talentOccurrence)
    {
        if (request.Sequence <= byte.MaxValue &&
            Templates.Value.ContainsKey(checked((byte)request.Sequence)))
        {
            return checked((byte)request.Sequence);
        }

        if (request.Method == "Teams.ShowTeam")
            return 6;

        return request.Method switch
        {
            "Pvp.OnOpGen" => 72,
            "Talents.OnTalent" => talentOccurrence switch
            {
                0 => 82,
                1 => 84,
                2 => 86,
                3 => 88,
                _ => 90
            },
            "Login.Heartbeat" => 92,
            "SchoolTowerMgr.OnOpenSchoolTower" => 96,
            "Produce.OnOpen" => 100,
            "Base.OpenClientData" => 160,
            "Item.OnShowWeapon" => 166,
            "Summon.OnOpen" => 20,
            "Shop.Open" => 156,
            _ => null
        };
    }

    private static IReadOnlyDictionary<byte, byte[]> LoadTemplates()
    {
        byte[] bank = LoadResource(ResourceName);
        var result = new Dictionary<byte, byte[]>();
        int offset = 0;

        while (offset < bank.Length)
        {
            if (offset + 2 > bank.Length)
                throw new InvalidDataException("Truncated response-bank header.");

            int frameLength = BinaryPrimitives.ReadUInt16BigEndian(
                bank.AsSpan(offset, 2));

            int recordLength = checked(2 + frameLength);
            if (frameLength <= 0 || offset + recordLength > bank.Length)
                throw new InvalidDataException("Truncated response-bank record.");

            byte[] record = bank.AsSpan(offset, recordLength).ToArray();
            byte[] unpacked = Morimens.Server.Protocol.Sproto.SprotoPackCodec.Unpack(
                record.AsSpan(2));
            if (unpacked.Length < 6)
            {
                throw new InvalidDataException(
                    $"Invalid response-bank record at offset {offset}.");
            }

            ushort sequence = BinaryPrimitives.ReadUInt16LittleEndian(
                unpacked.AsSpan(4, 2));
            if (sequence <= byte.MaxValue)
                result.TryAdd(checked((byte)sequence), record);

            offset += recordLength;
        }

        return result;
    }

    private static byte[] LoadResource(string resourceName)
    {
        Assembly assembly = typeof(CapturedPostLoginResponseBuilder).Assembly;
        using Stream stream = assembly.GetManifestResourceStream(resourceName)
            ?? throw new InvalidOperationException(
                $"Embedded resource {resourceName} was not found.");

        using var memory = new MemoryStream();
        stream.CopyTo(memory);
        return memory.ToArray();
    }
}
