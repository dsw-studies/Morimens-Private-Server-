using System.Buffers.Binary;
using System.Reflection;
using System.Text;

namespace Morimens.Server.Protocol.Rpc;

public static class CapturedActionResponseBuilder
{
    private const string ResourcePrefix =
        "Morimens.Server.Protocol.Fixtures.";

    private static readonly Lazy<byte[]> GenesisFivePull =
        new(() => Load("genesis-five-pull.msgpack"));
    private static readonly Lazy<byte[]> ShopBuyTicket =
        new(() => Load("shop-buy-ticket.msgpack"));
    private static readonly Lazy<byte[]> EventSignature =
        new(() => Load("item-use-event-signature.msgpack"));
    private static readonly Lazy<byte[]> EventHero =
        new(() => Load("item-use-event-hero.msgpack"));
    private static readonly Lazy<byte[]> NormalHero =
        new(() => Load("item-use-normal-hero.msgpack"));
    private static readonly Lazy<byte[]> InventoryAll999 =
        new(() => Load("inventory-all-999.msgpack"));

    public static byte[] BuildInventorySeedNotification() =>
        MorimensRpcRecordBuilder.BuildNotification(
            "Role.OnSyncItems",
            InventoryAll999.Value);

    public static bool TryBuild(
        GameRpcRequest request,
        int itemUseFallbackIndex,
        out byte[] response,
        out string action)
    {
        ArgumentNullException.ThrowIfNull(request);

        if (IsGachaPull(request))
        {
            response = BuildAction(
                request.Sequence,
                GenesisFivePull.Value);
            action = "gacha-five-genesis";
            return true;
        }

        if (IsShopPurchase(request))
        {
            response = BuildAction(
                request.Sequence,
                ShopBuyTicket.Value);
            action = "shop-buy-ticket";
            return true;
        }

        if (IsChooseItemUse(request))
        {
            byte[] payload;
            if (ContainsInteger(request.Frame, 34699) ||
                ContainsInteger(request.Frame, 145300))
            {
                payload = EventSignature.Value;
                action = "use-event-signature-choice";
            }
            else if (ContainsInteger(request.Frame, 9597) ||
                     ContainsInteger(request.Frame, 145290))
            {
                payload = EventHero.Value;
                action = "use-event-hero-choice";
            }
            else if (ContainsInteger(request.Frame, 21775) ||
                     ContainsInteger(request.Frame, 9745) ||
                     ContainsInteger(request.Frame, 9901))
            {
                payload = NormalHero.Value;
                action = "use-normal-hero-choice";
            }
            else
            {
                int normalized = (itemUseFallbackIndex & int.MaxValue) % 3;
                payload = normalized switch
                {
                    0 => EventSignature.Value,
                    1 => EventHero.Value,
                    _ => NormalHero.Value
                };
                action = normalized switch
                {
                    0 => "use-event-signature-choice-fallback",
                    1 => "use-event-hero-choice-fallback",
                    _ => "use-normal-hero-choice-fallback"
                };
            }

            response = BuildAction(request.Sequence, payload);
            return true;
        }

        response = [];
        action = string.Empty;
        return false;
    }

    private static byte[] BuildAction(
        ushort sequence,
        ReadOnlySpan<byte> directPayload) =>
        MorimensRpcRecordBuilder.Combine(
            MorimensRpcRecordBuilder.BuildDirectResponse(
                sequence,
                directPayload),
            BuildInventorySeedNotification());

    private static bool IsGachaPull(GameRpcRequest request)
    {
        bool knownPullMethod = request.Method is
            "Summon.SummonFive" or
            "Summon.DoSummon" or
            "Summon.OnSummon" or
            "Summon.Summon" or
            "Summon.Draw" or
            "Summon.Pull";

        if (knownPullMethod)
            return true;

        // Unknown/new client builds are accepted only when the request itself
        // carries banner or pull-count fields. This avoids treating history and
        // panel-opening RPCs as a summon.
        return request.Method.StartsWith("Summon.", StringComparison.Ordinal) &&
               (ContainsInteger(request.Frame, 145237) ||
                ContainsAscii(request.Frame, "summonType") ||
                ContainsAscii(request.Frame, "summonTimes"));
    }

    private static bool IsShopPurchase(GameRpcRequest request)
    {
        if (request.Method.Equals("Shop.Open", StringComparison.Ordinal))
            return false;

        return request.Method.Contains("Shop", StringComparison.Ordinal) &&
                   (request.Method.Contains("Buy", StringComparison.OrdinalIgnoreCase) ||
                    request.Method.Contains("Purchase", StringComparison.OrdinalIgnoreCase)) ||
               ContainsInteger(request.Frame, 17627) ||
               ContainsInteger(request.Frame, 18652) &&
               ContainsInteger(request.Frame, 9802);
    }

    private static bool IsChooseItemUse(GameRpcRequest request) =>
        request.Method.Contains("UseChooseItem", StringComparison.OrdinalIgnoreCase) ||
        request.Method.StartsWith("Item.", StringComparison.Ordinal) &&
            (request.Method.Contains("Use", StringComparison.OrdinalIgnoreCase) ||
             request.Method.Contains("Choose", StringComparison.OrdinalIgnoreCase)) ||
        ContainsInteger(request.Frame, 34699) ||
        ContainsInteger(request.Frame, 9597) ||
        ContainsInteger(request.Frame, 21775);

    private static bool ContainsAscii(ReadOnlySpan<byte> source, string value) =>
        source.IndexOf(Encoding.ASCII.GetBytes(value)) >= 0;

    private static bool ContainsInteger(ReadOnlySpan<byte> source, int value)
    {
        Span<byte> bytes = stackalloc byte[5];

        if (value is >= 0 and <= ushort.MaxValue)
        {
            BinaryPrimitives.WriteUInt16LittleEndian(bytes, checked((ushort)value));
            if (source.IndexOf(bytes[..2]) >= 0)
                return true;

            BinaryPrimitives.WriteUInt16BigEndian(bytes, checked((ushort)value));
            if (source.IndexOf(bytes[..2]) >= 0)
                return true;

            bytes[0] = 0xCD;
            BinaryPrimitives.WriteUInt16BigEndian(
                bytes[1..],
                checked((ushort)value));
            if (source.IndexOf(bytes[..3]) >= 0)
                return true;
        }

        BinaryPrimitives.WriteInt32LittleEndian(bytes, value);
        if (source.IndexOf(bytes[..4]) >= 0)
            return true;

        BinaryPrimitives.WriteInt32BigEndian(bytes, value);
        if (source.IndexOf(bytes[..4]) >= 0)
            return true;

        bytes[0] = 0xCE;
        BinaryPrimitives.WriteInt32BigEndian(bytes[1..], value);
        return source.IndexOf(bytes) >= 0;
    }

    private static byte[] Load(string fileName)
    {
        string resourceName = ResourcePrefix + fileName;
        Assembly assembly = typeof(CapturedActionResponseBuilder).Assembly;
        using Stream stream = assembly.GetManifestResourceStream(resourceName)
            ?? throw new InvalidOperationException(
                $"Embedded resource {resourceName} was not found.");
        using var memory = new MemoryStream();
        stream.CopyTo(memory);
        return memory.ToArray();
    }
}
