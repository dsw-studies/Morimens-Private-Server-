using System.Buffers.Binary;
using System.Reflection;
using System.Text;

namespace Morimens.Server.Protocol.Rpc;

public static class CapturedInitialGameStreamBuilder
{
    public const uint ProtocolReplayUid = 100_000_001;
    private const ushort TemplateStamina = 3_000;
    private const int TemplateGold = 9_244_013;
    private const string TemplateDisplayName = "mr caecuslover";
    private const int DisplayNameByteWidth = 14;

    private const string ResourceName =
        "Morimens.Server.Protocol.Fixtures.game-login-initial-stream.bin";

    private static readonly Lazy<byte[]> Template = new(LoadTemplate);

    public static byte[] Build(
        long localUid,
        string displayName,
        int stamina,
        long gold,
        byte requestSequence)
    {
        if (requestSequence != 4)
            throw new InvalidDataException($"Captured initial game stream supports sequence 4, got {requestSequence}.");
        if (localUid is <= 0 or > uint.MaxValue)
            throw new ArgumentOutOfRangeException(nameof(localUid));
        if (stamina is < 0 or > ushort.MaxValue)
            throw new ArgumentOutOfRangeException(nameof(stamina));
        if (gold is < 0 or > 0xFF_FFFF)
            throw new ArgumentOutOfRangeException(nameof(gold));

        byte[] result = Template.Value.ToArray();
        ReplaceUid(result, checked((uint)localUid));
        ReplaceDisplayName(result, displayName);
        // The client renders the current energy from this exact profile field.
        // Use the requested MVP current value. The separate visible cap is handled by the captured profile fields when available.
        ReplaceStamina(result, checked((ushort)stamina));
        ReplaceTopMenuCurrencies(result, 999, 999);
        ReplacePurpleStat(result, 999);
        ReplaceThreeByteGold(result, checked((int)gold));
        return result;
    }

    private static void ReplaceDisplayName(Span<byte> result, string displayName)
    {
        string normalized = string.IsNullOrWhiteSpace(displayName) ? "Dusha" : displayName.Trim();
        string selected = SelectDisplayName(normalized, DisplayNameByteWidth);
        byte[] nicknameBytes = EncodeUtf8WithinWidth(selected, DisplayNameByteWidth);

        byte[] source = Encoding.ASCII.GetBytes(TemplateDisplayName);
        byte[] target = new byte[DisplayNameByteWidth];
        nicknameBytes.CopyTo(target, 0);

        int replacements = ReplaceAll(result, source, target);
        if (replacements != 1)
            throw new InvalidDataException($"Expected one profile nickname field, found {replacements}.");

        if (result.IndexOf(source) >= 0)
            throw new InvalidDataException("Template profile nickname remained in the initial stream.");
        if (result.IndexOf(target) < 0)
            throw new InvalidDataException("Selected profile nickname was not written to the initial stream.");
    }

    private static string SelectDisplayName(string value, int maximumBytes)
    {
        if (Encoding.UTF8.GetByteCount(value) <= maximumBytes)
            return value;

        string[] words = value.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        for (int i = words.Length - 1; i >= 0; i--)
        {
            if (Encoding.UTF8.GetByteCount(words[i]) <= maximumBytes)
                return words[i];
        }
        return "Dusha";
    }

    private static byte[] EncodeUtf8WithinWidth(string value, int maximumBytes)
    {
        using var memory = new MemoryStream(maximumBytes);
        foreach (Rune rune in value.EnumerateRunes())
        {
            Span<byte> encoded = stackalloc byte[4];
            int count = rune.EncodeToUtf8(encoded);
            if (memory.Length + count > maximumBytes)
                break;
            memory.Write(encoded[..count]);
        }
        return memory.ToArray();
    }

    private static void ReplaceUid(Span<byte> result, uint localUid)
    {
        Span<byte> source = stackalloc byte[5];
        source[0] = 0xCE;
        BinaryPrimitives.WriteUInt32BigEndian(source[1..], ProtocolReplayUid);
        Span<byte> target = stackalloc byte[5];
        target[0] = 0xCE;
        BinaryPrimitives.WriteUInt32BigEndian(target[1..], localUid);
        int replacements = ReplaceAll(result, source, target);
        if (replacements < 2)
            throw new InvalidDataException($"Expected at least two UID fields, found {replacements}.");
    }

    private static void ReplaceStamina(Span<byte> result, ushort stamina)
    {
        Span<byte> source = stackalloc byte[3];
        source[0] = 0xCD;
        BinaryPrimitives.WriteUInt16BigEndian(source[1..], TemplateStamina);
        Span<byte> target = stackalloc byte[3];
        target[0] = 0xCD;
        BinaryPrimitives.WriteUInt16BigEndian(target[1..], stamina);
        int replacements = ReplaceAll(result, source, target);
        if (replacements != 1)
            throw new InvalidDataException($"Expected one stamina field, found {replacements}.");

        Span<byte> semanticEnergy = stackalloc byte[9]
        {
            (byte)'e', (byte)'n', (byte)'e', (byte)'r', (byte)'g', (byte)'y',
            0xCD, target[1], target[2]
        };
        if (result.IndexOf(semanticEnergy) < 0)
            throw new InvalidDataException("Patched semantic energy field was not found in the initial stream.");
    }


    private static void ReplaceTopMenuCurrencies(Span<byte> result, ushort firstValue, ushort secondValue)
    {
        // These are narrow, context-anchored fields from the current 122046-byte
        // login fixture. Do not replace every occurrence of 270/289: those values
        // also occur in unrelated records and corrupt the profile when changed globally.
        Span<byte> firstValueBytes = stackalloc byte[2];
        BinaryPrimitives.WriteUInt16BigEndian(firstValueBytes, firstValue);
        Span<byte> secondValueBytes = stackalloc byte[2];
        BinaryPrimitives.WriteUInt16BigEndian(secondValueBytes, secondValue);

        Span<byte> firstSource = stackalloc byte[]
        {
            0x63, 0xCD, 0x01, 0x0E, 0xCD, 0x01, 0x86
        };
        Span<byte> firstTarget = stackalloc byte[]
        {
            0x63, 0xCD, firstValueBytes[0], firstValueBytes[1], 0xCD, 0x01, 0x86
        };

        Span<byte> secondSource = stackalloc byte[]
        {
            0x51, 0x01, 0x21, 0xCD, 0x01, 0x41, 0x19, 0x00, 0x44
        };
        Span<byte> secondTarget = stackalloc byte[]
        {
            0x51, secondValueBytes[0], secondValueBytes[1], 0xCD, 0x01, 0x41, 0x19, 0x00, 0x44
        };

        int first = ReplaceAll(result, firstSource, firstTarget);
        int second = ReplaceAll(result, secondSource, secondTarget);
        if (first != 1 || second != 1)
        {
            throw new InvalidDataException(
                $"Expected one contextual field for each top-menu currency, found {first} and {second}.");
        }
    }

    private static void ReplacePurpleStat(Span<byte> result, ushort value)
    {
        // Experimental, length-preserving patch. In the captured initial profile
        // the semantic key "Purple" is followed by one MessagePack uint16 value:
        // 0xCD 0x04 0x9C (1180). Keep the uint16 representation and change only
        // those two value bytes, so record and stream lengths remain untouched.
        byte[] key = Encoding.ASCII.GetBytes("Purple");
        Span<byte> source = stackalloc byte[key.Length + 3];
        key.CopyTo(source);
        source[key.Length] = 0xCD;
        BinaryPrimitives.WriteUInt16BigEndian(source[(key.Length + 1)..], 1_180);

        Span<byte> target = stackalloc byte[key.Length + 3];
        key.CopyTo(target);
        target[key.Length] = 0xCD;
        BinaryPrimitives.WriteUInt16BigEndian(target[(key.Length + 1)..], value);

        int replacements = ReplaceAll(result, source, target);
        if (replacements != 1)
        {
            throw new InvalidDataException(
                $"Expected one Purple stat field, found {replacements}.");
        }
    }

    private static void ReplaceThreeByteGold(Span<byte> result, int gold)
    {
        Span<byte> source = stackalloc byte[3]
        {
            (byte)((TemplateGold >> 16) & 0xFF),
            (byte)((TemplateGold >> 8) & 0xFF),
            (byte)(TemplateGold & 0xFF)
        };
        Span<byte> target = stackalloc byte[3]
        {
            (byte)((gold >> 16) & 0xFF),
            (byte)((gold >> 8) & 0xFF),
            (byte)(gold & 0xFF)
        };
        int replacements = ReplaceAll(result, source, target);
        if (replacements != 1)
            throw new InvalidDataException($"Expected one soft-currency field, found {replacements}.");
    }

    private static int ReplaceAll(Span<byte> buffer, ReadOnlySpan<byte> source, ReadOnlySpan<byte> replacement)
    {
        if (source.Length != replacement.Length)
            throw new ArgumentException("Replacement must preserve binary length.");
        int count = 0;
        int offset = 0;
        while (offset <= buffer.Length - source.Length)
        {
            int relative = buffer[offset..].IndexOf(source);
            if (relative < 0) break;
            int index = offset + relative;
            replacement.CopyTo(buffer[index..]);
            count++;
            offset = index + replacement.Length;
        }
        return count;
    }

    private static byte[] LoadTemplate()
    {
        Assembly assembly = typeof(CapturedInitialGameStreamBuilder).Assembly;
        using Stream stream = assembly.GetManifestResourceStream(ResourceName)
            ?? throw new InvalidOperationException($"Embedded resource {ResourceName} was not found.");
        using var memory = new MemoryStream();
        stream.CopyTo(memory);
        byte[] result = memory.ToArray();
        if (result.Length != 122_046)
            throw new InvalidDataException($"Captured initial game stream has invalid length {result.Length}.");
        return result;
    }
}
