using System.Collections.Concurrent;
using Morimens.Server.Networking.Sessions;
using Morimens.Server.Services;

namespace Morimens.Server.Protocol.Rpc;

public sealed class DevelopmentRpcDispatcher(
    ILogger<DevelopmentRpcDispatcher> logger,
    ActiveLocalAccountRegistry activeAccounts) : IRpcDispatcher
{
    private readonly ConcurrentDictionary<Guid, int> _itemUseFallback = new();

    public ValueTask<RpcDispatchResult> DispatchAsync(
        GameSessionContext session,
        ReadOnlyMemory<byte> plaintext,
        CancellationToken cancellationToken)
    {
        ReadOnlySpan<byte> rpc = plaintext.Span;
        IReadOnlyList<GameRpcRequest> gameRequests =
            GameRpcStreamParser.Parse(plaintext);

        GameRpcRequest? gameLogin = gameRequests.FirstOrDefault(
            request => string.Equals(
                request.Method,
                "Login",
                StringComparison.Ordinal));

        if (gameLogin is not null && rpc.Length < 1200)
        {
            ActiveLocalAccount? selected = activeAccounts.Current;
            if (selected is null)
            {
                return ValueTask.FromResult(RpcDispatchResult.Unknown(
                    "Game Login received, but no local account is selected."));
            }

            if (gameLogin.Sequence > byte.MaxValue)
            {
                return ValueTask.FromResult(RpcDispatchResult.Unknown(
                    $"Unsupported GAME Login sequence {gameLogin.Sequence}."));
            }

            logger.LogInformation(
                "Session {SessionId}: GAME Login RPC recognized. sequence={Sequence}, " +
                "payload={PayloadLength}, localUser={Username}, uid={Uid}.",
                session.Id,
                gameLogin.Sequence,
                rpc.Length,
                selected.Username,
                selected.Uid);

            byte[] capturedStream =
                CapturedInitialGameStreamBuilder.Build(
                    selected.Uid,
                    selected.DisplayName,
                    selected.Stamina,
                    selected.Gold,
                    checked((byte)gameLogin.Sequence));

            byte[] seededStream = MorimensRpcRecordBuilder.Combine(
                capturedStream,
                CapturedActionResponseBuilder.BuildInventorySeedNotification());

            logger.LogInformation(
                "Session {SessionId}: initial GAME stream and 999 inventory seed prepared. " +
                "sequence={Sequence}, localUser={Username}, localUid={LocalUid}, " +
                "protocolUid={ProtocolUid}, displayName={DisplayName}, stamina={Stamina}, " +
                "gold={Gold}, stream={StreamLength}, records=10.",
                session.Id,
                gameLogin.Sequence,
                selected.Username,
                selected.Uid,
                selected.Uid,
                selected.DisplayName,
                selected.Stamina,
                selected.Gold,
                seededStream.Length);

            return ValueTask.FromResult(RpcDispatchResult.Success(
                seededStream,
                $"Captured initial game stream prepared for protocol uid=" +
                $"{selected.Uid}."));
        }

        if (gameRequests.Count > 0)
        {
            ActiveLocalAccount? selected = activeAccounts.Current;
            if (selected is null)
            {
                return ValueTask.FromResult(RpcDispatchResult.Unknown(
                    "Post-login RPC received, but no local account is selected."));
            }

            using var responseOutput = new MemoryStream();
            var handledActions = new List<string>();
            var replayRequests = new List<GameRpcRequest>();

            foreach (GameRpcRequest request in gameRequests)
            {
                int fallbackIndex = _itemUseFallback.GetOrAdd(session.Id, 0);
                if (!CapturedActionResponseBuilder.TryBuild(
                        request,
                        fallbackIndex,
                        out byte[] actionResponse,
                        out string action))
                {
                    replayRequests.Add(request);
                    continue;
                }

                responseOutput.Write(actionResponse);
                handledActions.Add(
                    $"{request.Sequence}:{request.Method}=>{action}");

                if (action.StartsWith("use-", StringComparison.Ordinal))
                {
                    _itemUseFallback.AddOrUpdate(
                        session.Id,
                        1,
                        static (_, current) => current + 1);
                }
            }

            byte[] replayStream = CapturedPostLoginResponseBuilder.Build(
                replayRequests,
                out int replayCount,
                out string replaySummary);
            responseOutput.Write(replayStream);

            string methods = string.Join(
                ", ",
                gameRequests.Select(
                    request => $"{request.Sequence}:{request.Method}"));
            string actionSummary = handledActions.Count == 0
                ? "none"
                : string.Join(", ", handledActions);

            logger.LogInformation(
                "Session {SessionId}: post-login RPC batch processed. " +
                "requests={RequestCount}, methods={Methods}, actions={Actions}, " +
                "replayResponses={ReplayCount}, responseMap={ResponseMap}, bytes={Length}.",
                session.Id,
                gameRequests.Count,
                methods,
                actionSummary,
                replayCount,
                replaySummary,
                responseOutput.Length);

            if (responseOutput.Length == 0)
            {
                return ValueTask.FromResult(RpcDispatchResult.Success(
                    null,
                    $"Post-login RPC batch observed; no response required. " +
                    $"requests={gameRequests.Count}."));
            }

            return ValueTask.FromResult(RpcDispatchResult.Success(
                responseOutput.ToArray(),
                $"Captured post-login stream prepared; actions={actionSummary}, " +
                $"replayResponses={replayCount}."));
        }

        LoginRequestInspection inspection = LoginRequestInspector.Inspect(rpc);
        if (!inspection.Recognized ||
            string.IsNullOrWhiteSpace(inspection.AccountId))
        {
            return ValueTask.FromResult(
                RpcDispatchResult.Unknown(inspection.Detail));
        }

        ActiveLocalAccount? local = activeAccounts.Current;
        if (local is null)
        {
            logger.LogWarning(
                "Session {SessionId}: gateway login rejected because no local " +
                "account is selected. Use POST /api/auth/login first.",
                session.Id);

            return ValueTask.FromResult(RpcDispatchResult.Unknown(
                "No local account selected. Login through the local API first."));
        }

        long protocolUid = local.Uid;
        byte[] response = MinimalLoginResponseBuilder.Build(protocolUid);

        logger.LogInformation(
            "Session {SessionId}: GATEWAY LoginRequest mapped to local user={Username}, " +
            "localUid={LocalUid}, protocolUid={ProtocolUid}. Payload={PayloadLength}, " +
            "header={HeaderHex}, protocolAccount={ProtocolAccount}, responseRpc={ResponseLength}.",
            session.Id,
            local.Username,
            local.Uid,
            protocolUid,
            inspection.PayloadLength,
            inspection.HeaderHex,
            inspection.AccountId,
            response.Length);

        return ValueTask.FromResult(RpcDispatchResult.Success(
            response,
            $"Gateway LoginResponse generated for replay protocol uid={protocolUid}."));
    }
}
