using System.Net;
using Morimens.Server.Protocol.Crypto;

namespace Morimens.Server.Networking.Sessions;

public sealed class GameSessionContext
{
    public Guid Id { get; } = Guid.NewGuid();
    public DateTimeOffset ConnectedAt { get; } = DateTimeOffset.UtcNow;
    public EndPoint? RemoteEndPoint { get; init; }
    public MorimensClientHandshake? ClientHandshake { get; set; }
    public MorimensSessionKeys? Keys { get; set; }
    public long ReceivedFrames { get; set; }
    public long SentFrames { get; set; }
    public long ReceivedBytes { get; set; }
    public long SentBytes { get; set; }
    public string State { get; set; } = "Connected";
}
